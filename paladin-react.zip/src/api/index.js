import axios from "axios";

export default axios.create({
  baseURL: "http://192.168.1.105:8000/api",
  headers: {
    "Content-Type": "application/json",
    Authorization: "Token 84240410ac4d4ae5a43e7eb1bbf7a1e2e11ef335",
  },
});
