import axiosInstance from './index'

export default axiosInstance.get(`api/products/`)
