import { combineReducers } from "redux";
import authReducer from "./redGAuth";
import productReducer from "./redProduct";

export default combineReducers({
  auth: authReducer,
  products: productReducer,
});
