/* eslint-disable import/no-anonymous-default-export */
import _ from "lodash";
import * as actionTypes from "../actions/actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case actionTypes.FETCH_PRODUCTS:
      console.log(action.payload);
      return {
        ...state,
        ..._.mapKeys(action.payload, "id"),
      };
    case actionTypes.FETCH_PRODUCT:
      return {
        ...state,
        [action.payload.id]: action.payload,
      };
    case actionTypes.CREATE_PRODUCT:
      return {
        ...state,
        [action.payload.id]: action.payload,
      };
    case actionTypes.EDIT_PRODUCT:
      return {
        ...state,
        [action.payload.id]: action.payload,
      };
    case actionTypes.DELETE_PRODUCT:
      return _.omit(state, action.payload);
    default:
      return state;
  }
};
