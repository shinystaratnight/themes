export const SIGN_START = "SIGN_START";
export const SIGN_IN = "SIGN_IN";
export const SIGN_OUT = "SIGN_OUT";
export const SIGN_SUCCESS = "SIGN_SUCCESS";
export const SIGN_FAIL = "SIGN_FAIL";

export const FETCH_PRODUCTS_REQUESTED = "products.FETCH_PRODUCTS_REQUESTED";
export const FETCH_PRODUCTS_ERROR = "products.FETCH_PRODUCTS_ERROR";
export const FETCH_PRODUCTS_DONE = "products.FETCH_PRODUCTS_DONE";
export const TOOGLE_PRODUCT_DESCRIPTION = "products.TOOGLE_PRODUCT_DESCRIPTION";
export const FETCH_PRODUCT_FILTER = "products.FETCH_PRODUCT_FILTER";

export const FETCH_PRODUCTS = "products.FETCH_PRODUCTS";
export const CREATE_PRODUCT = "product.CREATE_PRODUCT";
export const FETCH_PRODUCT = "product.FETCH_PRODUCT";
export const DELETE_PRODUCT = "product.DELETE_PRODUCT";
export const EDIT_PRODUCT = "product.EDIT_PRODUCT";

export const FETCH_CATEGORIES_REQUESTED =
  "categories.FETCH_CATEGORIES_REQUESTED";
export const FETCH_CATEGORIES_ERROR = "categories.FETCH_CATEGORIES_ERROR";
export const FETCH_CATEGORIES_DONE = "categories.FETCH_CATEGORIES_DONE";

export const FETCH_CATEGORIES = "categories.FETCH_CATEGORIES";
export const CREATE_CATEGORY = "category.CREATE_CATEGORY";
export const FETCH_CATEGORY = "category.FETCH_CATEGORY";
export const DELETE_CATEGORY = "categpry.DELETE_CATEGORY";
export const EDIT_CATEGORY = "category.EDIT_CATEGORY";
