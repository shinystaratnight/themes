import * as actionTypes from "./actionTypes";

export const authStart = () => {
  return {
    type: actionTypes.SIGN_START,
  };
};
export const authFail = (error) => {
  return {
    type: actionTypes.SIGN_FAIL,
    error: error,
  };
};
export const signIn = (userId, getName) => {
  return {
    type: actionTypes.SIGN_IN,
    userId: userId,
    getName: getName,
  };
};

export const signOut = () => {
  return {
    type: actionTypes.SIGN_OUT,
  };
};
