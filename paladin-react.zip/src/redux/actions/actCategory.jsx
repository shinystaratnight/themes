import altair from "../../api/altair";
import * as actionTypes from "./actionTypes";
import { createBrowserHistory } from "history";

var history = createBrowserHistory();

export const fetchCategory = (id) => async (dispatch) => {
  const response = await altair.get(`/category/${id}`);
  dispatch({
    type: actionTypes.FETCH_PRODUCT,
    payload: response.data,
  });
};
