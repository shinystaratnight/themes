import altair from "../../api/altair";
import * as actionTypes from "./actionTypes";
import { createBrowserHistory } from "history";

var history = createBrowserHistory();

export const fetchProducts = (category) => async (dispatch) => {
  const response = await altair.get("/products/");

  dispatch({
    type: actionTypes.FETCH_PRODUCTS,
    payload: response.data,
    category,
  });
};

export const fetchProduct = (id) => async (dispatch) => {
  const response = await altair.get(`/products/${id}`);
  dispatch({
    type: actionTypes.FETCH_PRODUCT,
    payload: response.data,
  });
};

export const createProduct = (formValues) => async (dispatch, getState) => {
  const { userId } = getState().auth;
  const response = await altair.post("/products", { ...formValues, userId });
  dispatch({
    type: actionTypes.CREATE_PRODUCT,
    payload: response.data,
  });
  history.push("/");
};

export const editProduct = (id, formValues) => async (dispatch) => {
  const response = await altair.patch(`/products/${id}`, formValues);

  dispatch({
    type: actionTypes.EDIT_PRODUCT,
    payload: response.data,
  });
  history.push("/");
};

export const deleteProduct = (id) => async (dispatch) => {
  await altair.put(`/products/${id}`);
  dispatch({
    type: actionTypes.DELETE_PRODUCT,
    payload: id,
  });
};
