const userDropDownMenuStyle = (theme) => ({
  root: {
    width: "auto"
  },
  menuTitle: {
    fontSize: "10px"
  },
  menuIcon: {
    marginRight: "35px"
  },
  menuWrapper: {
    backgroundColor: "#fff",
    color: "#000"
  },
  menuItem: {
    color: "#000",
    paddingTop: "16px",
    paddingBottom: "16px",
    borderBottom: "1px solid #000",
    width: "100%",
    minWidth: "200px",
    display: "flex",
    alignItems: "center",
    textDecoration: "none !important"
  },
  buttonGroup: {
    boxShadow: "none !important"
  },
  buttonItem: {
    backgroundColor: "#fff",
    color: "#000"
  },
  popperWrapper: {
    zIndex: "10"
  }
});

export default userDropDownMenuStyle;
