const carouselStyle = (theme) => ({
  root: {
    width: "100%",
		flexGrow: 1,
		'& .react-swipeable-view-container': {
			transition: "transform 1s cubic-bezier(0.15, 0.3, 0.25, 1) 0s !important"
		}
  },
  img: {
    display: 'block',
    overflow: 'hidden',
    width: '100%',
    minHeight: "200px"
	},
	dotsWrapper: {
		display: "flex",
		justifyContent: "center",
		marginTop: "20px",
		backgroundColor: "inherit",
		'& div div': {
			width: "25px",
			height: "25px",
			marginLeft: "15px",
			marginRight: "15px",
			backgroundColor: "#2D88FF",
			opacity: "0.5"
		},
		'& .MuiMobileStepper-dotActive': {
			opacity: "1"
		},
		[theme.breakpoints.down("sm")]: {
			'& .MuiMobileStepper-dot': {
				width: "15px !important",
				height: "15px !important"
			}
		}
  },
});

export default carouselStyle;
