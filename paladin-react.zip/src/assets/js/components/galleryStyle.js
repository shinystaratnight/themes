const galleryStyle = (theme) => ({
  galleryContainer: {
    '& .image-gallery-thumbnails-wrapper': {
      height: "400px !important",
      marginLeft: "30px !important",
    },
    '& .image-gallery-content': {
      display: "flex",
	    alignItems: "center"
    },
    '& .image-gallery-slide-wrapper': {
      width: "450px"
    },
    '& .image-gallery-slide-wrapper.left, .image-gallery-slide-wrapper.right': {
      display: "inline-block",
      width: "calc(100% - 140px)"
    },  
  },
  [theme.breakpoints.down("xs")]: {
    galleryContainer: {
      '& .image-gallery-thumbnails-wrapper': {
        display: "none !important"
      },
      '& .image-gallery-slide-wrapper': {
        width: "100% !important"
      }
    }
  }
})

export default galleryStyle;
