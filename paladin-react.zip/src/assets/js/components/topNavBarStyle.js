const topNavBarStyle = theme => ({
  root: {
		flexGrow: 1,
		paddingBottom: "50px",
		'& a': {
			textDecoration: "none !important"
		}
	},
	appBarWrapper: {
		boxShadow: "none !important",
		paddingRight: "0px",
		paddingLeft: "0px"
	},
	toolBarWrapper: {
		display: "block",
		paddingLeft: "16px",
		paddingRight: "0px",
		backgroundColor: "#fff",
	},
	menuButton: {
		marginRight: theme.spacing(4),
		backgroundColor: "#000",
		color: "white",
		'&:focus': {
			outline: "none !important",
		}
	},
	title: {
		flexGrow: 1,
	},
	buttonGroup: {
		boxShadow: "none !important", 
		marginLeft: "16px"
	},
	buttonItem: {
		backgroundColor: "#fff",
		color: "#000"
	},
	menuTitle: {
		fontSize: "10px"
	},
	menuGroup: {
		display: "flex",
		marginRight: "-16px",
		float: "right",
		justifyContent: "flex-end"
	},
	logoImgWrapper: {
		float: "left",
		display: "flex",
		alignItems: "center"
	},
	searchFormWrapper: {
		display: "flex",
		alignItems: "center"
	}
})

export default topNavBarStyle;
