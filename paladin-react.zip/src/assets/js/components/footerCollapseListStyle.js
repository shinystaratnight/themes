const footerCollapseListStyle = (theme) => ({
  root: {
    width: '100%',
    maxWidth: 360,
  },
  nested: {
    paddingLeft: theme.spacing(2),
  },
  listItemText: {
    color: "#000"
  },
  listTitle: {
    '& span': {
        color: "#000",
        fontWeight: "bold"
    }
  }
});

export default footerCollapseListStyle;
