const feedbackItemStyle = (theme) => ({
	feedbackItem: {
		display: "flex"
	},
	feedbackContent: {
		width: "100%"
	},
	avatarLarge: {
		width: theme.spacing(7),
    height: theme.spacing(7),
	},
	feedbackAvatar: {
		marginRight: theme.spacing(3)
	},
	usernameWrapper: {
		marginBottom: theme.spacing(1)
	},
	username: {
		fontWeight: "bold",
		fontSize: "1rem",
		marginRight: theme.spacing(7)
	},
	content: {
		marginTop: theme.spacing(2),
		marginBottom: theme.spacing(7),
		maxWidth: "380px"
	},
	actionWrapper: {
		display: "flex",
		justifyContent: "space-between"
	},
	actionBtn: {
		color: "#2D88FF",
		textDecoration: "none !important",
		fontSize: "1rem",
	},
	spaceLeft: {
		marginLeft: theme.spacing(2)
	},
	thumbWrapper: {
		display: "flex",
	},
	thumbItem: {
		display: "flex",
		alignItems: "center"
	},
	spaceBottom: {
		marginBottom: theme.spacing(7)
	}
})


export default feedbackItemStyle;
