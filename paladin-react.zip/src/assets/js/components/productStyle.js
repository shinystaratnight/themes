const productStyle = () => ({
	cardContent: {
		padding: "5px"
	},
	cardMedia: {
		width: "100%"
	},
	cardActions: {
		padding: "5px",
		display: "flex",
		justifyContent: "space-between",
	},
	manuInfoWrapper: {
		display: "flex",
		alignItems: "baseline",
		marginTop: "10px"
	},
	manuInfo: {
		wordBreak: "break-all",
		marginLeft: "10px"
	},
	favoriteIcon: {
		marginLeft: "0px !important",
		cursor: "pointer"
	},
	btnWrapper: {
		marginLeft: "0px !important",
		textDecoration: "none !important",
		width: "40%"
	},
	linkBtn: {
		overflow: "hidden",
		wordSpace: "nowrap",
		textOverflow: "ellipsis"
	}
})

export default productStyle;
