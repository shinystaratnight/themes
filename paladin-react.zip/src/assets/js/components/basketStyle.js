const basketStyle = (theme) => ({
    contentTitle: {
        fontSize: "34px"
    },
    contentContainer: {
        justifyContent: "space-between",
    },
    productListWrapper: {
        borderBottom: "1px solid #000"
    },
    itemListWrapper: {
        borderBottom: "1px solid",
        height: "fit-content"
    },
    fieldWrapper: {
        marginBottom: "1.5rem"
    },
    fieldTitle: {
        paddingBottom: "12px",
        borderBottom: "1px solid"
    },
    itemWrapper: {
        backgroundColor: "white",
        marginBottom: "1.5rem"
    },
    fieldContent: {
        display: "flex",
        alignItems: "center",
        paddingRight: "10px",
        wordBreak: "break-word"
    },
    countWrapper: {
        '& button:first-child': {
            borderTopLeftRadius: "100px",
            borderBottomLeftRadius: "100px"
        },
        '& button:last-child': {
            borderTopRightRadius: "100px",
            borderBottomRightRadius: "100px"
        }
    },
    orderWrapper: {
        backgroundColor: "white",
        padding: "20px",
        height: "fit-content"
    },
    totalText: {
        fontSize: "24px",
        marginBottom: "10px"
    },
    quantityText: {
        fontSize: "18px",
        marginTop: "10px",
        marginBottom: "30px"
    },
    orderBtn: {
        width: "100%",
        marginBottom: "20px",
        marginTop: "20px",
        fontWeight: "bold",
        fontSize: "24px",
        backgroundColor: "#2D88FF"
    }
});

export default basketStyle;
