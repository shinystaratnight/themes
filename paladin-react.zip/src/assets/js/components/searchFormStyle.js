const searchFormStyle = (theme) => ({
  root: {
    flexGrow: 1,     
  },
  searchFormWrapper: {
    borderRadius: "150px",
    backgroundColor: "#F0F2F5",
    color: "#000",
    paddingLeft: "24px",
    paddingRight: "24px",
    border: "none"
  },
  searchIcon: {
    marginRight: ".5rem"
  }
});

export default searchFormStyle;
