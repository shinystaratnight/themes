const styles = (theme) => ({
  loginContainer: {
    justifyContent: "center"
  },
  loginFormWrapper: {
    backgroundColor: "white",
    padding: "30px 50px",
    [theme.breakpoints.down("sm")]: {
			padding: "20px"
		}
  },
  pageTitle: {
    fontSize: "36px",
    fontWeight: "bold"
  },
  formWrapper: {
    marginTop: theme.spacing(3),
    width: "100% !important"
  },
  fullWidth: {
    width: "100% !important"
  },
  btnForm: {
    fontSize: "24px",
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(4)
  },
  checkboxWrapper: {
    display: "flex",
    alignItems: "baseline",
    '& .MuiFormControlLabel-label': {
      display: "flex",
      alignSelf: "flex-start"
    }
  },
  checkbox: {
    paddingTop: "0px"
  }
})

export default styles;
