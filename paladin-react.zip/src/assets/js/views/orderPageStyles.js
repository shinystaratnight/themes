const styles = (theme) => ({
	groupTitle: {
		fontSize: "36px",
		fontWeight: "bold"
	},
	formWrapper: {
		marginBottom: theme.spacing(5)
	},
	noteContent: {
		marginBottom: theme.spacing(2)
	},
	dataWrapperTitle: {
		display: "flex",
		justifyContent: "space-between",
		alignItems: "center"
	},
	pickLink: {
		color: "#2D88FF",
		textDecoration: "none !important"
	}
})

export default styles;
