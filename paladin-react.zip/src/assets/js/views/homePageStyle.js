const styles = () => ({
    slideImgItem: {
        width: "100%"
    },
    contentTitle: {
        fontSize: "36px",
        fontWeight: "bold",
        marginBottom: "50px",
        marginTop: "50px"
    },
    fruitBasketWrapper: {
        marginBottom: "50px",
        marginTop: "50px"
    },
    fruitBasketImg: {
        width: "100%"
    }
})

export default styles;
