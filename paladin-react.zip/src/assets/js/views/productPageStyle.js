const styles = (theme) => ({
  backBtn: {
    width: "150px",
    backgroundColor: "#2D88FF",
  },
  contentTitle: {
    fontSize: "36px",
    fontWeight: "bold",
    marginBottom: "20px",
    marginTop: "35px"
  },
  productGroup: {
    marginBottom: "50px"
  },
  groupTitle: {
    fontSize: "36px",
    fontWeight: "bold",
    marginBottom: "50px",
    marginTop: "0px"
  },
  feedbackWrapper: {
    marginTop: "50px",
  },
  feedbackWrapperTitle: {
    fontSize: "36px",
    fontWeight: "bold",
    marginBottom: "0px",
    marginTop: "0px"
  },
  reviewCountWrapper: {
    marginTop: "20px",
    marginBottom: "20px",
    display: "flex"
  },
  reviewCount: {
    marginRight: "16px"
  },
  buyersPhotoWrapper: {
    marginTop: "50px"
  },
  fullWidth: {
    width: "100%"
  },
  buyersWrapperTitle: {
    fontSize: "18px"
  },
  spaceTop: {
    marginTop: "50px"
  },
  spaceBottom: {
    marginBottom: "50px"
  },
  sortBtn: {
    color: "#000",
    fontWeight: "bold"
  },
  active: {
    color: "#2D88FF"
  },
  sortWrapper: {
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(3)
  },
  recentTitleWrapper: {
    display: "flex",
    alignItems: "baseline",
    marginBottom: theme.spacing(7)
  },
  recentTitle: {
    fontSize: "2rem",
    marginRight: theme.spacing(10),
    marginBottom: "0",
    marginTop: "0"
  },
  productTitle: {
    fontSize: "36px",
    marginTop: "0",
    marginBottom: "0",
    fontWeight: "bold"
  },
  productDescWrapper: {
    marginTop: theme.spacing(7)
  },
  productDetail: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    fontSize: "18px",
  },
  detailItem: {
    marginRight: theme.spacing(3)
  },
  galleryWrapper: {
    marginTop: theme.spacing(4),
    display: "flex",
    flexWrap: "wrap"
  },
  priceContent: {
    fontSize: "28px",
    fontWeight: "bold"
  },
  cardWrapper: {
    marginLeft: theme.spacing(4),
    marginTop: theme.spacing(4)
  },
  regionWrapper: {
    fontSize: "16px",
    marginTop: theme.spacing(2)
  }
})

export default styles;
