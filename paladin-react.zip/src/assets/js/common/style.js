const commonStyles = (theme) => ({
	contentWrapper: {
		padding: "50px",
		transition: "marginLeft .225s",
		backgroundColor: "#F0F2F5",
		[theme.breakpoints.down("sm")]: {
			padding: "20px"
		}
	}
})

export default commonStyles;
