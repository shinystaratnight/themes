import { createMuiTheme } from "@material-ui/core/styles";

export const dark = {
  palette: {
    type: "dark",
    primary: "#cccccc"
  }
}

export const main = {
  palette: {
    type: "main",
  }
}
