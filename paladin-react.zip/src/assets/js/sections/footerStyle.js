const footerStyle = (theme) => ({
  root: {
    paddingTop: "77px",
    backgroundColor: "#ffffff",
    paddingBottom: "150px",
    paddingLeft: "50px",
    paddingRight: "50px"
  },
  listWrapper: {
    width: '100%',
    maxWidth: '360px',
    backgroundColor: theme.palette.background.paper,
  },
  nested: {
    paddingLeft: theme.spacing(2),
  }
});

export default footerStyle;
