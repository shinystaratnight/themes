const headerSection = theme => ({
  root: {
		backgroundColor: "#fff",
		transitions: 'marginLeft .225s',
		paddingLeft: "50px",
		paddingRight: "50px",
		[theme.breakpoints.down("xs")]: {
			display: "none !important"
		}
	},
	topNavigationWrapper: {
		paddingTop: "20px",
		paddingBottom: "15px",
		fontSize: "14px",
		display: "flex",
		justifyContent: "space-between",
		color: "#000",
		'& .item': {
			color: "#000",
			textDecoration: "none !important",
			padding: "7px 37px"
		},
		'& .active': {
			backgroundColor: "rgba(196, 196, 196, 0.4)",
			borderRadius: "101px"
		},
	},
	changeLangWrapper: {
		display: "flex",
		justifyContent: "flex-end"
	},
	changeLangBtn: {
		color: "#000",
		padding: "0",
		fontWeight: "normal"
	},
	itemSpace: {
		marginRight: "1.5rem"
	},
	itemsWrapper: {
		display: "flex",
		alignItems: "center"
	}
});

export default headerSection;
