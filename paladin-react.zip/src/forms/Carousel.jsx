import React, { useState } from "react";
// react component for creating beautiful carousel
// import Carousel from "react-slick";
// nodejs library that concatenates classes
import classNames from "classnames";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// import List from "@material-ui/core/List";
// import ListItem from "@material-ui/core/ListItem";
// @material-ui/icons
// import Share from "@material-ui/icons/Share";
// import ShoppingCart from "@material-ui/icons/ShoppingCart";
// import LocationOn from "@material-ui/icons/LocationOn";
// core components
// import Button from "./Button";
// import GridContainer from "./Grid/GridContainer";
// import GridItem from "./Grid/GridItem";
// import Card from "./Card/Card";
import { red, blue, green } from "@material-ui/core/colors";
import { AutoRotatingCarousel, Slide } from "material-auto-rotating-carousel";
import useMediaQuery from "@material-ui/core/useMediaQuery";
//other
// import HeaderForm from "./Header/HeaderForm";
// import HeaderLinks from "./Header/HeaderLinks";
// import headerStyle from "../assets/jss/components/headerStyle";
import carouselStyle from "../assets/js/components/carouselStyle";

import image1 from "../assets/image/bg.jpg";
import image2 from "../assets/image/bg2.jpg";


const useStyles = makeStyles(carouselStyle);

const CarouselForm = () => {
  const [handleOpen, setHandleOpen] = useState({ open: false });
  const handleClick = () => {
    setHandleOpen({ open: true });
  };
  const matches = useMediaQuery("(max-width:600px)");
  const classes = useStyles();

  const settings = {
    dots: true,
    infinite: true,
    speed: 1000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
  };

  return (
    <React.Fragment>
      <div
        className={classNames(classes.main, classes.mainRaised)}
        id="main-panel"
      >
        {/* <div className={classes.section} id="carousel">
          <div className={classes.container}>
            <GridContainer>
              <GridItem xs={12} sm={10} md={8} className={classes.marginAuto}>
                <Card> */}
                  <AutoRotatingCarousel
                    label="Get started"
                    open={true}
                    // onClose={() => setHandleOpen({ open: false })}
                    // onStart={() => setHandleOpen({ open: false })}
                    autoplay={false}
                    mobile={matches}
                    style={{ position: "absolute" }}
                  >
                    <Slide
                      media={
                        <img src={image1} />
                      }
                      mediaBackgroundStyle={{ backgroundColor: red[400] }}
                      style={{ backgroundColor: red[600] }}
                      title="This is a very cool feature"
                      subtitle="Just using this will blow your mind."
                    />
                    <Slide
                      media={
                        <img src={image2} />
                      }
                      mediaBackgroundStyle={{ backgroundColor: blue[400] }}
                      style={{ backgroundColor: blue[600] }}
                      title="Ever wanted to be popular?"
                      subtitle="Well just mix two colors and your are good to go!"
                    />
                    <Slide
                      media={
                        <img src="http://www.icons101.com/icon_png/size_256/id_76704/Google_Settings.png" />
                      }
                      mediaBackgroundStyle={{ backgroundColor: green[400] }}
                      style={{ backgroundColor: green[600] }}
                      title="May the force be with you"
                      subtitle="The Force is a metaphysical and ubiquitous power in the Star Wars fictional universe."
                    />
                  </AutoRotatingCarousel>
                {/* </Card>
              </GridItem>
            </GridContainer>
          </div>
        </div> */}
      </div>
    </React.Fragment>
  );
};

export default CarouselForm;
