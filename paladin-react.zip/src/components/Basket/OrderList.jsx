import React, { useState } from 'react';

import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';

import styles from "../../assets/js/components/basketStyle";

import basketItem from "../../assets/image/basket-item.png";

const useStyles = makeStyles(styles);

export default function OrderList(props) {

	const classes = useStyles();
	const [count, setCount] = React.useState(1);
	const { orderItem } = props;

	return (    
		<Grid container className={classes.itemWrapper}>
			<Grid item xs={2} className={classes.fieldContent}>
					<img src={ basketItem } decoding="async" style={{width: "50%"}} />
			</Grid>
			<Grid item xs={2} className={classes.fieldContent}>{ orderItem.productName }</Grid>
			<Grid item xs={2} className={classes.fieldContent}>{ orderItem.seller }</Grid>
			<Grid item xs={2} className={classes.fieldContent}>{ orderItem.price }</Grid>
			<Grid item xs={2} className={classes.fieldContent}>
				<ButtonGroup size="small" className={classes.countWrapper}>
					<Button
						aria-label="reduce"
						onClick={() => {
						setCount(Math.max(count - 1, 0));
						}}
					>
						<RemoveIcon fontSize="small" />
					</Button>
					<Button>{count}</Button>
					<Button
						aria-label="increase"
						onClick={() => {
						setCount(count + 1);
						}}
					>
						<AddIcon fontSize="small" />
					</Button>
				</ButtonGroup>
			</Grid>
			<Grid item xs={2} className={classes.fieldContent}>{ count * orderItem.price }</Grid>
		</Grid>
	)
}
