import React, { useState } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

//material ui
import { createMuiTheme, ThemeProvider, makeStyles } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from '@material-ui/core/Container';
//other
import { createBrowserHistory } from "history";
import { Header, Footer } from "./common";
// import Drawer from "../forms/Drawer/Drawer"
import { dark, main } from "../assets/js/common/theme";
import styles from "../assets/js/common/style";
import Login from "./views/LoginPage";
import Home from "./views/HomePage";
import Order from "./views/OrderPage";
import Basket from "./views/BasketPage";
import Product from "./views/ProductPage";
import SwitchBtn from "./common/SwitchBtn";

var history = createBrowserHistory();

const useStyles = makeStyles(styles);

const App = () => {
	const classes = useStyles();
  const [darkMode, setDarkMode] = useState(false);
  // const theme = createMuiTheme({
  //   palette: {
	// 		type: "dark",
	// 		primary: {
	// 			main: "#cccccc"
	// 		}
	// 	},
		
	// });
	
	const handleSwitch = (value) => {
		setDarkMode(value)
	}

	// const appliedTheme = createMuiTheme(darkMode ? dark : main)

  return (
    <div className="body-wrapper">
		{/* <ThemeProvider theme={ appliedTheme }> */}
			<CssBaseline />
			<Router history={history}>
				<div>
					<SwitchBtn darkMode = { darkMode } handleSwitch = { handleSwitch } />
					<Header />
					{/* <Drawer /> */}
					<div className={ classes.contentWrapper }>
						<Switch>
							<Route path="/" exact component={ Home } />
							<Route path="/login" exact component={Login} />
							<Route path="/basket" component={ Basket } />
							<Route path="/product/:id" component={ Product } />
							<Route path="/order/:id" component={ Order } />
						</Switch>
					</div>
					<Footer />
				</div>
			</Router>
		{/* </ThemeProvider> */}
    </div>
  );
};

export default App;
