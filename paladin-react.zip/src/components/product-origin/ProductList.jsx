import React from "react";

// @material-ui/core components
import { makeStyles, Tooltip } from "@material-ui/core";

// @material-ui icons
import { Favorite } from "@material-ui/icons";

// core components
import Button from "../../forms/Button";
import GridItem from "../../forms/Grid/GridItem";
import Card from "../../forms/Card/Card";
import CardHeader from "../../forms/Card/CardHeader";
import CardBody from "../../forms/Card/CardBody";
import CardFooter from "../../forms/Card/CardFooter";

//redux
import { connect, useDispatch } from "react-redux";
import { fetchProducts } from "../../redux/actions/actProduct";

import styles from "../../assets/js/views/productsStyle.js";

const useStyles = makeStyles(styles);

const ProductList = ({ products }) => {
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const classes = useStyles();

  const renderProductList = () => {
    return (
      products &&
      products.map((product) => {
        return (
          <GridItem md={4} sm={4} key={product.id}>
            <Card plain product>
              <CardHeader noShadow image>
                <a href="#pablo">
                  <img src={product.image} alt=".." height="200 px" />
                </a>
              </CardHeader>
              <CardBody plain>
                <a href="#pablo">
                  <h4 className={classes.cardTitle}>{product.title}</h4>
                </a>
                <p className={classes.description}>{product.description}</p>
              </CardBody>
              <CardFooter plain className={classes.justifyContentBetween}>
                <div className={classes.priceContainer}>
                  <span className={classes.price}>{product.price}</span>
                </div>
                <Tooltip
                  id="tooltip-top"
                  title="Saved to Wishlist"
                  placement="left"
                  classes={{ tooltip: classes.tooltip }}
                >
                  <Button
                    justIcon
                    simple
                    color="rose"
                    className={classes.pullRight}
                  >
                    <Favorite />
                  </Button>
                </Tooltip>
              </CardFooter>
            </Card>
          </GridItem>
        );
      })
    );
  };

  return <React.Fragment>{renderProductList()}</React.Fragment>;
};

const mapStateToProps = (state) => {
  return {
    products: Object.values(state.products),
    currentUserId: state.auth.userId,
    isSignedIn: state.auth.isSignedIn,
  };
};

export default connect(mapStateToProps, null)(ProductList);
