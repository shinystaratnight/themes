/*eslint-disable*/
import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import { useHistory } from "react-router-dom";
// import { signIn, signOut } from "../redux/actions";
import * as actions from "../redux/actions/actGAuth";
import { Redirect, Link } from "react-router-dom";

// components
import Button from "../forms/Button";

const GoogleAuth = ({ dispatch, isSignedIn, classNames }) => {
  const [auth, setAuth] = useState(null);
  let history = useHistory();

  useEffect(() => {
    dispatch(actions.authStart());
    const params = {
      clientId:
        "797401886567-9cumct9mrt3v2va409rasa7fa6fq02hh.apps.googleusercontent.com",
      scope: "email",
    };
    window.gapi.load("client:auth2", () => {
      window.gapi.client.init(params).then(() => {
        setAuth(window.gapi.auth2.getAuthInstance());
        onAuthChange(window.gapi.auth2.getAuthInstance().isSignedIn.get());
        window.gapi.auth2.getAuthInstance().isSignedIn.listen(onAuthChange);
      });
      window.gapi.client.init(params).catch((err) => {
        dispatch(authFail(err));
      });
    });
  }, []);

  const onAuthChange = (isSignedIn) => {
    if (isSignedIn) {
      dispatch(
        actions.signIn(
          window.gapi.auth2.getAuthInstance().currentUser.get().getId(),
          window.gapi.auth2
            .getAuthInstance()
            .currentUser.get()
            .getBasicProfile()
            .getName()
        )
      );
    } else {
      dispatch(actions.signOut());
    }
  };

  const onSignInClick = () => {
    try {
      auth.signIn();
      // history.push("/");
    } catch (e) {
      alert(e.message);
    }
  };

  const onSignOutClick = () => {
    try {
      auth.signOut();
      history.push("/");
    } catch (e) {
      alert(e.message);
    }
  };

  const renderAuthButton = () => {
    if (isSignedIn === null) {
      return;
    } else if (isSignedIn) {
      return (
        <Button
          justIcon
          color="google"
          className={classNames}
          onClick={(e) => onSignOutClick()}
        >
          <i className="fab fa-google-plus-g" />
        </Button>
      );
    } else {
      return (
        <Button
          justIcon
          color="google"
          className={classNames}
          onClick={(e) => onSignInClick()}
        >
          <i className="fab fa-google-plus-g" />
        </Button>
      );
    }
  };

  return <React.Fragment>{renderAuthButton()}</React.Fragment>;
};

const mapStateToProps = (state) => {
  return {
    isSignedIn: state.auth.isSignedIn,
    userId: state.auth.userId,
    getName: state.auth.getName,
    loading: state.auth.loading,
    error: state.auth.error,
  };
};

export default connect(mapStateToProps)(GoogleAuth);
