import React from "react";
// @material-ui/core components
import {
  fade,
  ThemeProvider,
  withStyles,
  makeStyles,
  createMuiTheme,
} from '@material-ui/core/styles';

import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import InputBase from '@material-ui/core/InputBase';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import RegularButton from "../../forms/Button";

import styles from "../../assets/js/views/loginPageStyle";

const useStyles = makeStyles(styles);

const BootstrapInput = withStyles((theme) => ({
  root: {
    'label + &': {
      marginTop: theme.spacing(3),
    },
  },
  input: {
    borderRadius: 4,
    position: 'relative',
    backgroundColor: theme.palette.common.white,
    border: '1px solid #ced4da',
    fontSize: 16,
    width: '100%',
    padding: '10px 12px',
    transition: theme.transitions.create(['border-color', 'box-shadow']),
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
    '&:focus': {
      boxShadow: `${fade(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}))(InputBase);

export default function Login () {

  const [state, setState] = React.useState({
    agreeTerm: false,
  });

  const handleChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };

  const classes = useStyles();

  return (
    <React.Fragment>
      <Grid container className={classes.loginContainer}>
        <Grid item xs={12} lg={4} className={classes.loginFormWrapper}>
          <Typography variant="h2" className={classes.pageTitle}>
            Login or create <br/> a profile
          </Typography>
          <FormControl className={classes.formWrapper}>
            <InputLabel shrink htmlFor="telephone">
              Telephone number
            </InputLabel>
            <BootstrapInput id="telephone" fullWidth={true} className={classes.fullWidth} />
          </FormControl>
          <RegularButton variant="contained" round={true} color="custom2" fullWidth={true} className={classes.btnForm}>
            Get the code
          </RegularButton>
          <FormControlLabel
            control={
              <Checkbox
                checked={state.agreeTerm}
                onChange={handleChange}
                name="agreeTerm"
                color="primary"
                className={classes.checkbox}
              />
            }
            label="I agree with the terms of the Terms of use of the trading platform and the return rules"
            className={classes.checkboxWrapper}
          />
        </Grid>
      </Grid>
    </React.Fragment>
  )
}
