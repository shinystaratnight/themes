import React, { useState, useEffect } from "react";

import { makeStyles } from "@material-ui/core";
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';

import { ProductCard } from "../common"
import { Carousel } from "../common";

import styles from "../../assets/js/views/homePageStyle.js";

import image1 from "../../assets/image/fruit/fruitveg 2.png";
import image2 from "../../assets/image/fruit/fruitveg 2.png";
import image3 from "../../assets/image/fruit/fruitveg 2.png";
import image4 from "../../assets/image/fruit/fruitveg 2.png";
import image5 from "../../assets/image/fruit/fruitveg 2.png";
import daikonImg from "../../assets/image/fruit/daikon.png";
import gingerImg from "../../assets/image/fruit/ginger.png";
import radishImg from "../../assets/image/fruit/radish.png";
import spinachImg from "../../assets/image/fruit/spinach.png";
import potatoImg from "../../assets/image/fruit/potato.png";
import pepperImg from "../../assets/image/fruit/pepper.png";
import fruitBasket1 from "../../assets/image/fruit/fruit-basket1.png";
import fruitBasket2 from "../../assets/image/fruit/fruit-basket2.png";

const useStyles = makeStyles(styles);

const Home = () => {
  const classes = useStyles();

  const [products, setProducts] = useState([])

  const carouselImages = [
    { imgPath: image1 },
    { imgPath: image2 },
    { imgPath: image3 },
    { imgPath: image4 },
    { imgPath: image5 }
  ];

  useEffect(async () => {
    const productURL = 'http://127.0.0.1:8000/api/productlist/'
    // const products = await axios.get(productURL)

    const products = [
      { id: 1, productImg: daikonImg, productName: "Daikon", manuInfo: "manufacturer name", price: "5" },
      { id: 2, productImg: gingerImg, productName: "Ginger", manuInfo: "manufacturer name", price: "10" },
      { id: 3, productImg: radishImg, productName: "Radish", manuInfo: "manufacturer name", price: "7" },
      { id: 4, productImg: spinachImg, productName: "Spinach", manuInfo: "manufacturer name", price: "9" },
      { id: 5, productImg: potatoImg, productName: "Pottato", manuInfo: "manufacturer name", price: "3" },
      { id: 6, productImg: pepperImg, productName: "Pepper", manuInfo: "manufacturer name", price: "8" },
      { id: 7, productImg: daikonImg, productName: "Daikon", manuInfo: "manufacturer name", price: "5" },
      { id: 8, productImg: gingerImg, productName: "Ginger", manuInfo: "manufacturer name", price: "10" },
      { id: 9, productImg: radishImg, productName: "Radish", manuInfo: "manufacturer name", price: "7" },
      { id: 10, productImg: spinachImg, productName: "Spinach", manuInfo: "manufacturer name", price: "9" },
      { id: 11, productImg: potatoImg, productName: "Pottato", manuInfo: "manufacturer name", price: "3" },
      { id: 12, productImg: pepperImg, productName: "Pepper", manuInfo: "manufacturer name", price: "8" }
    ]

    setProducts(products)

  }, [])

  return (
    <React.Fragment>
      <Carousel carouselImages={ carouselImages } />
      <Typography variant="h1" gutterBottom className={classes.contentTitle}>
        Bestsellers
      </Typography>
      <Grid container spacing={1}>
        {
          products.map((productInfo, index) => 
            <Grid item xs={12} sm={6} md={4} lg={2} xl={2} key={ index }>
              <ProductCard productInfo={ productInfo } />
            </Grid>
          )
        }
      </Grid>
      <Grid container spacing={5} className={classes.fruitBasketWrapper}>
        <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
          <img src={fruitBasket1} decoding="async" className={classes.fruitBasketImg} />
        </Grid>
        <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
          <img src={fruitBasket2} decoding="async" className={classes.fruitBasketImg} />
        </Grid>
      </Grid>
      <Grid container spacing={1}>
        {
          products.map((productInfo, index) => 
            <Grid item xs={12} sm={6} md={4} lg={2} xl={2} key={ index }>
              <ProductCard productInfo={ productInfo } />
            </Grid>
          )
        }
      </Grid>
    </React.Fragment>
  );
};

export default Home;
