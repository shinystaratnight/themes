import React, { useState } from 'react';

import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Link from '@material-ui/core/Link';

import { OrderList } from "../Basket";

import styles from "../../assets/js/components/basketStyle";

const useStyles = makeStyles(styles);

export default function Basket() {

	const classes = useStyles();
	
	const orderList = [
		{
			productImg: "./src/assets/image/basket-item.png",
			productName: "Product name",
			seller: "Seller name",
			price: "3999"
		},
		{
			productImg: "./src/assets/image/basket-item.png",
			productName: "Product name",
			seller: "Seller name",
			price: "3999"
		},
		{
			productImg: "./src/assets/image/basket-item.png",
			productName: "Product name",
			seller: "Seller name",
			price: "3999"
		},
		{
			productImg: "./src/assets/image/basket-item.png",
			productName: "Product name",
			seller: "Seller name",
			price: "3999"
		},
		{
			productImg: "./src/assets/image/basket-item.png",
			productName: "Product name",
			seller: "Seller name",
			price: "3999"
		}
	]

	return (
			<React.Fragment>
				<h1 className={classes.contentTitle}>Shopping Cart</h1>
				<Grid container className={classes.contentContainer}>
					<Grid item xs={12} md={8} className={classes.itemListWrapper}>
						<Grid container className={classes.fieldWrapper}>
							<Grid item xs={2} className={classes.fieldTitle}></Grid>
							<Grid item xs={2} className={classes.fieldTitle}>Product</Grid>
							<Grid item xs={2} className={classes.fieldTitle}>Seller</Grid>
							<Grid item xs={2} className={classes.fieldTitle}>Price</Grid>
							<Grid item xs={2} className={classes.fieldTitle}>Number</Grid>
							<Grid item xs={2} className={classes.fieldTitle}>Total</Grid>
						</Grid>
						{
							orderList.map((orderItem, index) =>
									<OrderList orderItem={ orderItem } key={ index } />
							)
						}
					</Grid>
					<Grid item xs={12} md={3} className={classes.orderWrapper}>
						<Grid container >
							<Grid item xs={12}>
								<Grid container>
									<Grid item xs={6}>
										<h3 className={classes.totalText}>Total</h3>
									</Grid>
									<Grid item xs={6}>
										<h3 className={classes.totalText}>37dl.</h3>
									</Grid>
								</Grid>
								<Grid container>
									<Grid item xs={6}>
										<h4 className={classes.quantityText}>quantity of goods</h4>
									</Grid>
									<Grid item xs={6}>
										<h4 className={classes.quantityText}>5 pieces</h4>
									</Grid>
								</Grid>
								<Grid container>
									<Grid item xs={12}>
										<span>Delivery: </span>
										<Link href="#">Choose delivery address</Link>
									</Grid>
									<Grid item xs={12}>
										<Button variant="contained" color="primary" href="#contained-buttons" className={classes.orderBtn}>
											Order
										</Button>
									</Grid>
									<Grid item xs={12}>
										I agree with the terms of the Terms of Use trading platform and return policy
									</Grid>
								</Grid>
							</Grid>
					</Grid>
				</Grid>
			</Grid>
		</React.Fragment>
	)
}
