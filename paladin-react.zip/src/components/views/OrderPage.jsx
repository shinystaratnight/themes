import React from "react";

import { makeStyles } from "@material-ui/core";
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Link from '@material-ui/core/Link';

import RegularButton from "../../forms/Button";

import styles from "../../assets/js/views/orderPageStyles";

const useStyles = makeStyles(styles);

export default function Order () {

	const classes = useStyles();

	return (
		<React.Fragment>
			<Grid container className={classes.formWrapper}>
				<Grid item xs={12} sm={12} md={8} lg={8} xl={8}>
					<Typography variant="h1" gutterBottom className={classes.groupTitle}>
						Delivery method
					</Typography>
					<Grid container spacing={2}>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Point of issue"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Courier delivery"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
						<Grid item xs={12}>
							<Link href="#" className={classes.pickLink}>Select a pick-up point</Link>
						</Grid>
					</Grid>
				</Grid>
			</Grid>

			<Grid container className={classes.formWrapper}>
				<Grid item xs={12} sm={12} md={8} lg={8} xl={8}>
					<Typography variant="h1" gutterBottom className={classes.groupTitle}>
						Payment method
					</Typography>
					<Grid container spacing={2}>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Courier delivery"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
					</Grid>
				</Grid>
			</Grid>

			<Grid container className={classes.formWrapper}>
				<Grid item xs={12} sm={12} md={8} lg={6} xl={6}>
					<Grid container>
						<Grid item xs={12} className={classes.dataWrapperTitle}>
							<Typography variant="h1" gutterBottom className={classes.groupTitle}>
								Your data
							</Typography>
							<RegularButton variant="contained" color="custom2" >
								Login
							</RegularButton>
						</Grid>
					</Grid>
					<Typography variant="body1" className={classes.noteContent}>
						Registration is required to order goods. <br/>
						If you are already registered, please login to your account
					</Typography>
					<Grid container spacing={2}>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Name"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Surname"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Telephone number"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
						<Grid item xs={12} md={6} lg={6} xl={6}>
							<TextField
								label="Email"
								fullWidth
								margin="normal"
								InputLabelProps={{
									shrink: true,
								}}
								variant="outlined"
							/>
						</Grid>
					</Grid>
				</Grid>
			</Grid>
		</React.Fragment>
	)
}
