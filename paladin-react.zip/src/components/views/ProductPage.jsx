import React from "react";
import classNames from "classnames";

import { makeStyles } from "@material-ui/core";
import Button from '@material-ui/core/Button';
import Link from '@material-ui/core/Link';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Rating from '@material-ui/lab/Rating';
import StarBorderIcon from '@material-ui/icons/StarBorder';

import RegularButton from "../../forms/Button";
import { ProductCard, Gallery } from "../common"
import { Feedback } from "../Product";

import styles from "../../assets/js/views/productPageStyle";

import daikonImg from "../../assets/image/fruit/daikon.png";
import gingerImg from "../../assets/image/fruit/ginger.png";
import radishImg from "../../assets/image/fruit/radish.png";
import spinachImg from "../../assets/image/fruit/spinach.png";
import potatoImg from "../../assets/image/fruit/potato.png";
import pepperImg from "../../assets/image/fruit/pepper.png";
import buyerImg from "../../assets/image/buyer-img.png";
import userAvatar from "../../assets/image/user.png";
import galleryOriginal1 from "../../assets/image/fruit/galleryOriginal1.png";
import galleryThumbnail from "../../assets/image/fruit/galleryThumbnail1.png";

const useStyles = makeStyles(styles);

export default function Product () {

	const classes = useStyles();

	const productList = [
    { productImg: daikonImg, productName: "Daikon", manuInfo: "manufacturer name", price: "5" },
    { productImg: gingerImg, productName: "Ginger", manuInfo: "manufacturer name", price: "10" },
    { productImg: radishImg, productName: "Radish", manuInfo: "manufacturer name", price: "7" },
    { productImg: spinachImg, productName: "Spinach", manuInfo: "manufacturer name", price: "9" },
    { productImg: potatoImg, productName: "Pottato", manuInfo: "manufacturer name", price: "3" },
    { productImg: pepperImg, productName: "Pepper", manuInfo: "manufacturer name", price: "8" }
	]
	
	const buyersList = [
		{img: buyerImg}, {img: buyerImg}, {img: buyerImg}, {img: buyerImg}, {img: buyerImg}, {img: buyerImg}
	]

	const feedbackList = [
		{	
			id: 1,
			avatar: userAvatar,
			username: "Username",
			dataType: "Publication data",
			rating: 0,
			content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
			upCount: 0,
			downCount: 0
		},
		{
			id: 2,
			avatar: userAvatar,
			username: "Username",
			dataType: "Publication data",
			rating: 0,
			content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
			upCount: 0,
			downCount: 0
		},
		{
			id: 3,
			avatar: userAvatar,
			username: "Username",
			dataType: "Publication data",
			rating: 0,
			content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
			upCount: 0,
			downCount: 0
		}
	]

	const galleryImages = [
		{
			original: galleryOriginal1,
			thumbnail: galleryThumbnail,
		},
		{
			original: galleryOriginal1,
			thumbnail: galleryThumbnail,
		},
		{
			original: galleryOriginal1,
			thumbnail: galleryThumbnail,
		},
		{
			original: galleryOriginal1,
			thumbnail: galleryThumbnail,
		},
		{
			original: galleryOriginal1,
			thumbnail: galleryThumbnail,
		}
	];

	return(
		<React.Fragment>
			<div>
				{/* <Link> */}
					<Button variant="contained" color="primary" href="/" component={Link} className={classes.backBtn}>
							Back
					</Button>
				{/* </Link> */}
			</div>
			<Grid container className={classes.productDescWrapper}>
				<Grid item xs={12} lg={8} xl={8}>
					<Grid container>
						<Grid item xl={12}>
							<Typography variant="h1" gutterBottom className={classes.productTitle}>
								Ginger
							</Typography>
							<div className={classes.productDetail}>
								<div className={classes.detailItem}>
									<span>Article: &nbsp;</span>
									<span>2312342</span>
								</div>
								<div className={classes.detailItem}>
									<span>12</span>
									<span>&nbsp;Reviews</span>
								</div>
								<span className={classes.detailItem}>Have bought 178 times</span>
								<Rating
									name="customized-empty"
									defaultValue={2}
									precision={0.5}
									emptyIcon={<StarBorderIcon fontSize="inherit" />}
									className={classes.detailItem}
								/>
							</div>
							<div className={classes.galleryWrapper}>
								<Gallery images={ galleryImages } />
								<div className={classes.cardWrapper}>
									<Typography variant="h1" className={classes.priceContent}>
										10 dollars
									</Typography>
									<div className={classes.regionWrapper}>
										<span>Your region: &nbsp;</span>
										<Link>Nur-Sultan</Link>
									</div>
									<div className={classes.regionWrapper}>
										<span>Delivery: &nbsp;</span>
										<Link>Select delivery address</Link>
									</div>
									<RegularButton variant="contained" color="custom2" fullWidth={true} className={classes.regionWrapper}>
										Add to Card
									</RegularButton>
								</div>
							</div>
						</Grid>
					</Grid>
					<Grid container>
						<Grid item xs={12} lg={6} xl={6}>
							<Typography variant="h1" gutterBottom className={classes.contentTitle}>
								Description
							</Typography>
							<Typography variant="body1" gutterBottom>
								Most often, ginger is used in a ground form. Ground spice is a grayish-yellow powdery powder.
								If it has a strong and persistent aroma, then it is considered to be of higher quality. It is also widely used finely grated
								or finely chopped fresh ginger root. When rubbed, ginger gives off a lot of juice, in some recipes,
								where the fibrous structure of the mature root is undesirable, only ginger juice is used.
							</Typography>
						</Grid>
					</Grid>
				</Grid>
			</Grid>
			<div className={classNames(classes.productGroup, classes.spaceTop)}>
				<Typography variant="h1" gutterBottom className={classes.groupTitle}>
					Similar products
				</Typography>
				<Grid container spacing={1}>
					{
						productList.map((productInfo, index) => 
							<Grid item xs={12} sm={6} md={4} lg={2} xl={2} key={ index }>
								<ProductCard productInfo={ productInfo } />
							</Grid>
						)
					}
				</Grid>
			</div>
			<div className={classes.productGroup}>
				<Typography variant="h1" gutterBottom className={classes.groupTitle}>
					With this product buy
				</Typography>
				<Grid container spacing={1}>
					{
						productList.map((productInfo, index) => 
							<Grid item xs={12} sm={6} md={4} lg={2} xl={2} key={ index }>
								<ProductCard productInfo={ productInfo } />
							</Grid>
						)
					}
				</Grid>
			</div>
			<div className={classes.feedbackWrapper}>
				<Typography variant="h1" gutterBottom className={classes.feedbackWrapperTitle}>
					Feedback and questions
				</Typography>
				<div className={classes.reviewCountWrapper}>
					<div className={classes.reviewCount}>
						<span>Reviews &nbsp;</span>
						<span>3</span>
					</div>
					<div className={classes.questionCount}>
						<span>Questions &nbsp;</span>
						<span>0</span>
					</div>
				</div>
				<div>
					<RegularButton variant="contained" color="custom1">
						Write a feedback
					</RegularButton>
				</div>
				<div className={classNames(classes.buyersPhotoWrapper)}>
					<h6 className={classes.buyersWrapperTitle}>Photos of buyers</h6>
					<Grid container spacing={2}>
						{
							buyersList.map((buyerItem, index) => 
							<Grid item xs={12} md={4} lg={2} xl={2} key={ index }>
								<img src={buyerItem.img} decoding="async" className={classes.fullWidth} />
							</Grid>
							)
						}
					</Grid>
				</div>
				<div>
						<div className={classes.sortWrapper}>
							<span>Sort by:</span>
							<RegularButton variant="contained" simple={true} color="custom2" >
								Date
							</RegularButton>
							<RegularButton variant="contained" simple={true} color="custom3" >
								Rating
							</RegularButton>
							<RegularButton variant="contained" simple={true} color="custom3" >
								Usefulness
							</RegularButton>
						</div>
						{
							feedbackList.map((feedbackItem, index) => 
								<Feedback key={ index } feedbackData={ feedbackItem } />
							)
						}
				</div>
				<div className={classNames(classes.recentWrapper)}>
					<div className={classes.recentTitleWrapper}>
						<h6 className={classes.recentTitle}>You recently viewed</h6>
						<Link>View all</Link>
					</div>
					
					<Grid container spacing={2}>
						<Grid item xs={12} md={4} lg={2} xl={2}>
							<img src={buyersList[0].img} decoding="async" className={classes.fullWidth} />
						</Grid>
					</Grid>
				</div>
			</div>
		</React.Fragment>
	)
}
