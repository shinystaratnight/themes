import React from 'react';
import SwipeableViews from 'react-swipeable-views';
import { autoPlay } from 'react-swipeable-views-utils';

import { makeStyles, useTheme } from '@material-ui/core/styles';
import MobileStepper from '@material-ui/core/MobileStepper';

import styles from "../../../assets/js/components/carouselStyle";

const AutoPlaySwipeableViews = autoPlay(SwipeableViews);

const useStyles = makeStyles(styles);

function Carousel(props) {
  const classes = useStyles();
  const theme = useTheme();
	const [activeStep, setActiveStep] = React.useState(0);
	
	const { carouselImages } = props;
  const maxSteps = carouselImages.length;

  const handleStepChange = (step) => {
    setActiveStep(step);
  };

  return (
    <div className={classes.root}>
      <AutoPlaySwipeableViews
        axis={ theme.direction === 'rtl' ? 'x-reverse' : 'x' }
        index={ activeStep }
        onChangeIndex={ handleStepChange }
				enableMouseEvents={true}
				interval={5000}
      >
        {carouselImages.map((step, index) => (
          <div key={ index }>
            {Math.abs(activeStep - index) <= 2 ? (
              <img className={ classes.img } src={ step.imgPath } />
            ) : null}
          </div>
        ))}
      </AutoPlaySwipeableViews>
      <MobileStepper
        steps={maxSteps}
        position="static"
        variant="dots"
				activeStep={ activeStep }
				className={ classes.dotsWrapper }
				hysteresis="1.5"
      />
    </div>
  );
}

export default Carousel;
