import React, { useState } from "react";
import { connect, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
//other
// import classNames from "classnames";

import HeaderForm from "../../forms/Header/HeaderForm";
import HeaderLinks from "../../forms/Header/HeaderLinks";
import Button from "../../forms/Button";

import CustomDropdown from "../../forms/CustomDropdown";
import styles from "../../assets/js/components/headerLinksStyle";
//
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import {
  PersonSharp,
  ShoppingBasket,
  Person,
  MonetizationOn,
  AssignmentInd,
  Memory,
  Feedback,
  RssFeed,
} from "@material-ui/icons";

import { signIn, signOut } from "../../redux/actions/actGAuth";

const useStyles = makeStyles(styles);

const Header = ({ isSignedIn, currentUserId, getName }) => {
  const classes = useStyles();
  const dispatch = useDispatch();

  const onSignOutClick = () => {
    dispatch(signOut());
  };

  const renderHeader = () => {
    if (isSignedIn === null) {
      return (
        <HeaderForm
          color="dark"
          // brand="Nordal"
          links={<HeaderLinks dropdownHoverColor="dark" />}
          // fixed
          changeColorOnScroll={{
            height: 300,
            color: "dark",
          }}
        />
      );
    } else if (isSignedIn) {
      return (
        <HeaderForm
          color="dark"
          // brand={currentUserId}
          links={
            <div className={classes.collapse}>
              <List className={classes.list + " " + classes.mlAuto}>
                <ListItem className={classes.listItem}>
                  <CustomDropdown
                    noLiPadding
                    navDropdown
                    // hoverColor={dropdownHoverColor}
                    buttonText={getName}
                    buttonProps={{
                      className: classes.navLink,
                      color: "transparent",
                    }}
                    buttonIcon={PersonSharp}
                    dropdownList={[
                      <Link
                        to="/"
                        className={classes.dropdownLink}
                        onClick={() => onSignOutClick()}
                      >
                        <Person className={classes.dropdownIcons} />
                        Sign Out
                      </Link>,
                      <Link to="/account" className={classes.dropdownLink}>
                        <MonetizationOn className={classes.dropdownIcons} />
                        Account
                      </Link>,
                      <Link to="/report" className={classes.dropdownLink}>
                        <Feedback className={classes.dropdownIcons} />
                        Report
                      </Link>,
                      <Link to="/feedback" className={classes.dropdownLink}>
                        <RssFeed className={classes.dropdownIcons} />
                        Feedback
                      </Link>,
                    ]}
                  />
                </ListItem>
              </List>
            </div>
          }
          // fixed
          changeColorOnScroll={{
            height: 300,
            color: "dark",
          }}
        />
      );
    } else {
      return (
        <HeaderForm
          color="dark"
          // brand="Not signed in"
          links={<HeaderLinks dropdownHoverColor="dark" />}
          // fixed
          changeColorOnScroll={{
            height: 300,
            color: "dark",
          }}
        />
      );
    }
  };
  console.log(isSignedIn);
  return <div>{renderHeader()}</div>;
};
const mapStateToProps = (state) => {
  return {
    currentUserId: state.auth.userId,
    isSignedIn: state.auth.isSignedIn,
    getName: state.auth.getName,
  };
};

export default connect(mapStateToProps)(Header);
