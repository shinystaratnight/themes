import React, { useState } from "react";
import Switch from '@material-ui/core/Switch';

export default function SwitchBtn (props) {

  const handleSwitch =(event) => {
    props.handleSwitch(event.target.checked)
  }

  return(
    <div>
      <Switch
      checked={ props.darkMode }
      onChange={ handleSwitch }
      name="checkedA"
      inputProps={{ 'aria-label': 'secondary checkbox' }}
      />
    </div>
  )
}