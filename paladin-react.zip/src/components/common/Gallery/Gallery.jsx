import React from "react";
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";

import { makeStyles } from "@material-ui/core";

import styles from "../../../assets/js/components/galleryStyle";

const useStyles = makeStyles(styles);

export default function Gallery (props) {

  const { images } = props;

  const classes = useStyles();

  return(
    <div className={classes.galleryContainer}>
      <ImageGallery 
        items={images} 
        thumbnailPosition="right"
      />
    </div>
  )
}
