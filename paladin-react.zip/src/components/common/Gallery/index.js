import Gallery from "./Gallery";

export default Gallery;
