import React from "react";

const Drawer = () => {
  return <div>Drawer</div>;
};

export default Drawer;
