import React from 'react';

import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import Link from '@material-ui/core/Link';

import styles from "../../../assets/js/components/footerCollapseListStyle";

const useStyles = makeStyles(styles);

export default function FooterCollapseList(props) {
	const classes = useStyles();
	const [open, setOpen] = React.useState(true);

	const handleClick = () => {
			setOpen(!open);
	};

	return (
		<List
		component="nav"
		aria-labelledby="nested-list-subheader"
		className={classes.root}           
		>
			<ListItem button onClick={ handleClick }>
				<ListItemText primary={ props.titleText } className={ classes.listTitle } />
			</ListItem>
			<Collapse in={ open } timeout="auto" unmountOnExit>
				{ 
					props.itemList.map((listItem, index) => 
						<List component="div" disablePadding key={ index }>
							<ListItem button className={ classes.nested }>
								<ListItemText >
										<Link href={ listItem.link } className={ classes.listItemText }>{ listItem.text }</Link>
								</ListItemText>
							</ListItem>
						</List>
					)
				}
			</Collapse>
		</List>
    );
}
