import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';

import FooterCollapseList from "./FooterCollapseList";

import styles from "../../../assets/js/sections/footerStyle";

const useStyles = makeStyles(styles);

export default function Footer(props) {
    const classes = useStyles();
  
    const partnerList = [
        { link: "#", text: "For salers" },
        { link: "#", text: "Franchise" },
    ]

    const purchaserList = [
        { link: "#", text: "How make order" },
        { link: "#", text: "Payment methods" },
        { link: "#", text: "Delivery" },
        { link: "#", text: "Purchase returns" },
        { link: "#", text: "A refund" },
        { link: "#", text: "Proper use of the marketplace" },
        { link: "#", text: "Sale rules" },
        { link: "#", text: "Questions and answers" },
    ]

    const ourProjectList = [
        { link: "#", text: "Sport" },
        { link: "#", text: "For kids" }
    ]

    const companyList = [
        { link: "#", text: "About us" },
        { link: "#", text: "Requisites" },
        { link: "#", text: "Press center" },
        { link: "#", text: "Contacts" },
    ]

    const socialList = [
        { link: "#", text: "Vkontakte" },
        { link: "#", text: "Facebook" },
        { link: "#", text: "Odnoclassniki" },
        { link: "#", text: "Youtube" },
        { link: "#", text: "Instagram" },
        { link: "#", text: "Mail" },
    ]

    return (
        <div className={ classes.root }>
            <div style={{ marginLeft: props.open ? "230px" : "0px" }}>
                <Grid container spacing={ 3 }>
                    <Grid item xs={ 12 } sm={ 6 } md={ 4 } lg={ 3 } xl={ 3 } >
                        <FooterCollapseList titleText="For purchasers" itemList={ purchaserList } />
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 4 } lg={ 2 } xl={ 2 } >
                        <FooterCollapseList titleText="For partners" itemList={ partnerList } />
                        <FooterCollapseList titleText="Our projects" itemList={ ourProjectList } />
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 4 } lg={ 2 } xl={ 2 } >
                        <FooterCollapseList titleText="Company" itemList={ companyList } />
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 4 } lg={ 2 } xl={ 2 } >
                        <FooterCollapseList titleText="Social" itemList={ socialList } />
                    </Grid>
                    <Grid item xs={ 12 } sm={ 6 } md={ 4 } lg={ 3 } xl={ 3 } >
                        <FooterCollapseList titleText="Mobile devices" itemList={ [] } />
                    </Grid>
                </Grid>
            </div>
        </div>
    );
}
