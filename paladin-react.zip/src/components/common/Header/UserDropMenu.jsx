import React from 'react';

import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Grow from '@material-ui/core/Grow';
import Paper from '@material-ui/core/Paper';
import Popper from '@material-ui/core/Popper';
import MenuItem from '@material-ui/core/MenuItem';
import MenuList from '@material-ui/core/MenuList';
import Link from '@material-ui/core/Link';
import PersonIcon from '@material-ui/icons/Person';
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';
import MonetizationOnRoundedIcon from '@material-ui/icons/MonetizationOnRounded';
import FeedbackRoundedIcon from '@material-ui/icons/FeedbackRounded';
import RssFeedIcon from '@material-ui/icons/RssFeed';

import styles from "../../../assets/js/components/userDropDownMenuStyle";

const useStyles = makeStyles(styles);

export default function UserDropMenu() {
	const classes = useStyles();

	const [open, setOpen] = React.useState(false);
	const anchorRef = React.useRef(null);

	const handleToggle = () => {
			setOpen((prevOpen) => !prevOpen);
	};

	const handleClose = (event) => {
			if (anchorRef.current && anchorRef.current.contains(event.target)) {
			return;
			}

			setOpen(false);
	};

	return (
		<Grid container direction="column" alignItems="flex-end" className={ classes.root }>
			<Grid item xs={ 12 }>
				<ButtonGroup variant="contained" color="primary" ref={ anchorRef } aria-label="split button" className={ classes.buttonGroup }>
					<Button onClick={ handleToggle } className={ classes.buttonItem }>
						<div>
								<PersonIcon fontSize="large"/>
								<div className={ classes.menuTitle }>login</div>
						</div>
					</Button>
				</ButtonGroup>
				<Popper open={ open } anchorEl={ anchorRef.current } role={ undefined } transition disablePortal className={ classes.popperWrapper }>
					{({ TransitionProps, placement }) => (
						<Grow
						{...TransitionProps }
						style={{
								transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom',
						}}
						>
						<Paper>
							<ClickAwayListener onClickAway={ handleClose }>
							<MenuList id="split-button-menu" className="px-3" className={ classes.menuWrapper }>
								<MenuItem>
									<Link href="/login" className={ classes.menuItem }>
										<AccountCircleRoundedIcon fontSize="large" className={ classes.menuIcon } />
										<span>Authorization</span>
									</Link>
								</MenuItem>
								<MenuItem>
									<Link href="#" className={ classes.menuItem }>
											<MonetizationOnRoundedIcon fontSize="large" className={ classes.menuIcon } />
											<span>My wallet</span>
									</Link>
								</MenuItem>
								<MenuItem>
									<Link href="#" className={ classes.menuItem }>
										<RssFeedIcon fontSize="large" className={ classes.menuIcon } />
										<span>Feedback</span>
									</Link>
								</MenuItem>
								<MenuItem>
									<Link href="#" className={ classes.menuItem }>
										<FeedbackRoundedIcon fontSize="large" className={ classes.menuIcon } />
										<span>Report</span>
									</Link>
								</MenuItem>
							</MenuList>
							</ClickAwayListener>
						</Paper>
						</Grow>
					)}
				</Popper>
			</Grid>
		</Grid>
	);
}
