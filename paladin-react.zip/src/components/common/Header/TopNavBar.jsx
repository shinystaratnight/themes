import React from 'react';

import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Button from '@material-ui/core/Button';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Grid from '@material-ui/core/Grid';
import ShoppingCartOutlinedIcon from '@material-ui/icons/ShoppingCartOutlined';
import FavoriteBorderIcon from '@material-ui/icons/FavoriteBorder';
import Link from '@material-ui/core/Link';

import SearchForm from "./SearchForm";
import UserDropMenu from "./UserDropMenu";

import styles from "../../../assets/js/components/topNavBarStyle";

import logoIcon from "../../../assets/image/logo.svg";

const useStyles = makeStyles(styles);

export default function TopNavBar(props) {
	
	const classes = useStyles();
	
	return (
		<div className={classes.root}>
			<AppBar position="static" className={ classes.appBarWrapper }>
				<Toolbar className={ classes.toolBarWrapper } >
					<Grid container spacing={ 3 }>
						<Grid item xs className={ classes.logoImgWrapper }>
							<IconButton edge="start" className={ classes.menuButton } aria-label="menu" onClick={ props.handleSidebar }>
								<MenuIcon />
							</IconButton>
							<Link href="/">
								<img src={ logoIcon }></img>
							</Link>
							
						</Grid>
						<Grid item xs={ 6 } className={ classes.searchFormWrapper }>
							<SearchForm />
						</Grid>
						<Grid item xs className={ classes.menuGroup }>
							<ButtonGroup variant="contained" color="primary" aria-label="split button" className={ classes.buttonGroup } >
								<Button className={ classes.buttonItem }>
									<div>
										<FavoriteBorderIcon fontSize="large" />
										<div className={ classes.menuTitle }>Favorites</div>
									</div>
								</Button>
							</ButtonGroup>
							<UserDropMenu />
							<Link href="/basket">
								<ButtonGroup variant="contained" color="primary" aria-label="split button" className={ classes.buttonGroup } >
									<Button className={ classes.buttonItem }>
										<div>
											<ShoppingCartOutlinedIcon fontSize="large" />
											<div className={ classes.menuTitle }>Basket</div>
										</div>
									</Button>
								</ButtonGroup>
							</Link>
						</Grid>
					</Grid>
				</Toolbar>
			</AppBar>
		</div>
	);
}
