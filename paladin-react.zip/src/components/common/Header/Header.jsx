import React, { useState } from 'react';
import classNames from 'classnames';

import { makeStyles } from '@material-ui/core/styles';
import Link from '@material-ui/core/Link';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import PublicIcon from '@material-ui/icons/Public';

import TopNavBar from "./TopNavBar";

import styles from "../../../assets/js/sections/headersStyle";

const useStyles = makeStyles(styles);

export default function Header(props) {

	const [change_lang_el, setLangElement] = useState(null);

	const change_lang = (event) => {
		setLangElement(event.currentTarget);
	}
	const change_lang_close = () => {
		setLangElement(null);
	}
	
	const classes = useStyles();
	
	return(
		<div className={ classNames(classes.root) } style={{ marginLeft: props.open ? "230px" : "0px" }}>
			<div className={ classes.topNavigationWrapper }>
				<Grid container spacing={3}>
					<Grid item xs={ 12 } sm={ 12 } md={ 8 } lg={ 8 } xl={ 8 } className={classes.itemsWrapper}>
						<span className={ classes.itemSpace }>Kazakhstan</span>
						<Link href="#" className={ classNames(classes.itemSpace, 'item', 'active') }>Free shipping</Link>
						<Link href="#" className="item">FAQ</Link>
						<Link href="#" className="item">Change country</Link>
					</Grid>
					<Grid item xs={ 12 } sm={ 12 } md={ 4 } lg={ 4 } xl={ 4 } className={classNames(classes.changeLangWrapper, classes.itemsWrapper)}>
						<div className={ classes.itemSpace }>
							<Button aria-controls="simple-menu" aria-haspopup="true" onClick={ change_lang } className={ classes.changeLangBtn }>
								Change language
							</Button>
							<Menu
								id="simple-menu"
								anchorEl={ change_lang_el }
								keepMounted
								open={ Boolean(change_lang_el) }
								onClose={ change_lang_close}
							>
								<MenuItem onClick={ change_lang_close }>English</MenuItem>
								<MenuItem onClick={ change_lang_close }>Russian</MenuItem>
							</Menu>
						</div>
						<PublicIcon fontSize="large" />
					</Grid>
				</Grid>
			</div>
			<div className="">
				<TopNavBar />
			</div>
		</div>
	)
}
