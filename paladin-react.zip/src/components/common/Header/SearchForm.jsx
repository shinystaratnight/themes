import React from 'react';

import { makeStyles } from '@material-ui/core/styles';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import SearchIcon from '@material-ui/icons/Search';
import CameraAltOutlinedIcon from '@material-ui/icons/CameraAltOutlined';

import styles from "../../../assets/js/components/searchFormStyle";

const useStyles = makeStyles(styles);

export default function SearchForm() {
	
	const classes = useStyles();
	
	return (
		<FormControl className={ classes.root } variant="outlined">
			<OutlinedInput
				endAdornment={
					<InputAdornment position="end">
							<SearchIcon className={ classes.searchIcon } />
							<CameraAltOutlinedIcon />
					</InputAdornment>
				}
				aria-describedby="outlined-weight-helper-text"
				labelWidth={0}
				placeholder="I search..."
				className={ classes.searchFormWrapper }
				fullWidth={true}
			/>
		</FormControl>
	);
}
