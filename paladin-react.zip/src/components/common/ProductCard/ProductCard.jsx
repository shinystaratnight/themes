import React from "react";

import { makeStyles } from "@material-ui/core";
import Typography from '@material-ui/core/Typography';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Link from '@material-ui/core/Link';
import FavoriteBorderOutlinedIcon from '@material-ui/icons/FavoriteBorderOutlined';

import RegularButton from "../../../forms/Button";

import styles from "../../../assets/js/components/productStyle.js";

import heartImg from "../../../assets/image/heart.png";

const useStyles = makeStyles(styles);

const ProductCard = (props) => {
  const classes = useStyles();
  const { productInfo } = props;
  
  return (
    <Card>
      <CardActionArea>
        <CardContent className={classes.cardContent}>
        <img src={ productInfo.productImg } className={classes.cardMedia}/>
        <div className={classes.manuInfoWrapper}>
          <Typography gutterBottom variant="h5">
            { productInfo.productName }
          </Typography>
          <Typography variant="body1" className={classes.manuInfo}>
            { productInfo.manuInfo }
          </Typography>
        </div>
        <Typography gutterBottom variant="h5" className="productPrice">
            { `${ productInfo.price } dollars`}
        </Typography>
        </CardContent>
      </CardActionArea>
      <CardActions className={classes.cardActions}>
        <Link href={`/order/${ productInfo.id }`} className={classes.btnWrapper}>
          <RegularButton variant="contained" size="sm" round={true} color="custom2" fullWidth={true} className={classes.linkBtn} >
            Order
          </RegularButton>
        </Link>
        <Link href={`/product/${ productInfo.id }`} className={classes.btnWrapper}>
          <RegularButton variant="contained" size="sm" round={true} color="custom1" fullWidth={true} className={classes.linkBtn} >
            Load more
          </RegularButton>
        </Link>
        {/* <img src={heartImg} decoding="async" className={classes.favoriteIcon} /> */}
        <FavoriteBorderOutlinedIcon fontSize="large" />
      </CardActions>
    </Card>
  );
};

export default ProductCard;
