import Feedback from "./Feedback";

export { Feedback }
