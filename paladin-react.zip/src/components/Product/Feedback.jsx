import React, { useState } from "react";
import classNames from "classnames";

import { makeStyles } from "@material-ui/core";
import Link from '@material-ui/core/Link';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Avatar from '@material-ui/core/Avatar';
import Rating from '@material-ui/lab/Rating';
import StarBorderIcon from '@material-ui/icons/StarBorder';

import styles from "../../assets/js/components/feedbackStyle";

import ThumbUp from "../../assets/image/ThumbUp.svg";
import ThumbDown from "../../assets/image/ThumbDown.svg"

const useStyles = makeStyles(styles);

export default function Feedback (props) {

	const classes = useStyles();

	const [rating, setRating] = useState(3);

	const { feedbackData } = props;

	return(
		<Grid container className={classes.spaceBottom}>
			<Grid item xs={12} lg={6}>
				<div className={classes.feedbackItem}>
					<div className={classes.feedbackAvatar}>
							<Avatar alt="user" src={ feedbackData.avatar } className={classes.avatarLarge} />
					</div>
					<div className={classes.feedbackContent}>
						<div className={classes.usernameWrapper}>
							<span className={classes.username}>{ feedbackData.username }</span>
							<span>{ feedbackData.dataType }</span>
						</div>
						<div>
							<Rating
								name={`feedback-${ feedbackData.id }`}
								defaultValue={2}
								precision={0.5}
								value={rating}
								emptyIcon={ <StarBorderIcon fontSize="inherit" /> }
								onChange={ (event, newValue)=>setRating(newValue) }
							/>
						</div>
						<Typography variant="body1" gutterBottom className={classes.content}>
							{ feedbackData.content }
						</Typography>
						<div className={classes.actionWrapper}>
							<div>
								<Link component="button" className={classes.actionBtn}>Report</Link>
								<Link component="button" className={classNames(classes.actionBtn, classes.spaceLeft)}>Reply</Link>
							</div>
							<div className={classes.thumbWrapper}>
								<div className={classes.thumbItem}>
									<img src={ThumbUp} decoding="async" />
									<span className={classes.spaceLeft}>{ feedbackData.upCount }</span>
								</div>
								<div className={classNames(classes.thumbItem, classes.spaceLeft)}>
									<img src={ThumbDown} decoding="async" />
									<span className={classes.spaceLeft}>{ feedbackData.downCount }</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</Grid>
		</Grid>
	)
}
