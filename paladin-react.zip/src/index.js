import React from 'react';
import ReactDOM from 'react-dom';

// 3rd party
import { Provider} from 'react-redux';
import { createStore, compose, applyMiddleware } from 'redux';
import thunk from 'redux-thunk'

//comp  
import App from './components/App.jsx';
import reducers from './redux/reducers';

const composeEnhances = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose 
const store = createStore(reducers, composeEnhances(
  applyMiddleware(thunk)
));

const app = (
  <Provider store={store}>
    <App />
  </Provider>
)
ReactDOM.render( app , document.getElementById('root'));
