import React from 'react'

export function RTL() {
  return <>RTL</>
}
