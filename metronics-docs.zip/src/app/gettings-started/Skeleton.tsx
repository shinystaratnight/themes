import React from 'react'

export function Skeleton() {
  return <>Skeleton</>
}
