If you already installed these plugins by following the notification at the top of dashboard page, you don’t have to install it again. You can skip it.

goodlayers-lms.zip - is used for Learning Management System.
gdlr-portfolio.zip - is used for portfolio post type and portfolio pages.
gdlr-shortcode.zip - is used for calling all Goodlayers’ shortcodes.
goodlayers-importer - is used for importing as demo site. Note that to run the theme, 
‘goodlayers-lms.zip’,‘gdlr-portfolio.zip’ and ‘gdlr-shortcode.zip’ must be installed and activated.