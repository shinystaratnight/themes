This version is 2.2.4
============================================================

Theme’s instruction is in the folder ‘document/instruction’. Please open that folder and open the file ‘index.html’ with your browsers.

For using payment with Stripe, Authorized.net and PayMill. The system don’t collect any of user’s credit card information. Please note that we don’t take any responsibilities for any damages to credit card information caused by system’s vulnerability so please make sure that your hosting is secured and also your being used plugins are trustable.

============================================================

Log: https://support.goodlayers.com/document/changelog-clevercourse/