require('./src/main.js')
