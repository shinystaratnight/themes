export interface IconUserModel {
  name: string
  avatar?: string
  color?: string
  initials?: string
}
