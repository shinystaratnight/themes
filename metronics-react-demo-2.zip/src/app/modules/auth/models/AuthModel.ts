export interface AuthModel {
  accessToken: string
  refreshToken?: string
}
