export interface UserAddressModel {
  addressLine: string
  city: string
  state: string
  postCode: string
}
