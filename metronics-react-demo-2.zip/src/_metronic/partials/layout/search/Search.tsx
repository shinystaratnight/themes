import React, {FC} from 'react'

const Search: FC = () => {
  return <></>
}

export {Search}
