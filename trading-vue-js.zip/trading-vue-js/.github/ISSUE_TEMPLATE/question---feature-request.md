---
name: Question / Feature request
about: Freestyle issue (for bugs/problems use the templates above)
title: ''
labels: ''
assignees: ''

---

## (!Important) Freestyle issue. In case you're trying to describe some problem or bug, you need to start with a full template (Full Template / PlayGround), otherwise the issue is likely to be closed.

## (!important 2) Consider reading the [FAQ](https://github.com/tvjsx/trading-vue-js/tree/master/docs/faq) first, because it helps to solve 82% of issues.
