<template>
    <trading-vue
        :data="chart"
        :width="this.width"
        :height="this.height"
        :color-back="colors.colorBack"
        :color-grid="colors.colorGrid"
        :color-text="colors.colorText"
        :toolbar="true"
    >
    </trading-vue>
</template>

<script>
import TradingVue from './TradingVue.vue'
import Data from '../data/data.json'
import DataCube from '../src/helpers/datacube.js'

export default {
    name: 'app',
    components: {
        TradingVue
    },
    methods: {
        onResize() {
            this.width = window.innerWidth
            this.height = window.innerHeight
        }
    },
    mounted() {
        window.addEventListener('resize', this.onResize)
        window.dc = this.chart
        console.log(this.chart.get('onchart'))
        const testNewData = {
            "name": "EMA, 99",
            "type": "EMA",
            "data": [
                [
                    1558688400000,
                    7825.946243900578
                ],
                [
                    1558692000000,
                    7869.9000
                ]
            ]
        }
        // window.dc.add("onchart", testNewData)
        // const testNewData = [
        //     [
        //         1558692000000,
        //         7920.9000
        //     ],
        //     [
        //         1558695600000,
        //         7900.9000
        //     ]
        // ]
        // window.dc.merge("onchart.EMA, 43.data", testNewData)

        setTimeout(() => {
            console.log(this.chart.get('onchart'))
        }, 5000)
    },
    beforeDestroy() {
        window.removeEventListener('resize', this.onResize)
    },
    data() {
        return {
            chart: new DataCube(Data),
            width: window.innerWidth,
            height: window.innerHeight,
            colors: {
                colorBack: '#fff',
                colorGrid: '#eee',
                colorText: '#333',
            }
        };
    }
};
</script>

<style>
html,
body {
    background-color: #000;
    margin: 0;
    padding: 0;
    overflow: hidden;
}
</style>
