
// Skins controller. Can be used as a boilerplate
// for other skin packs

export default class Main {


}
