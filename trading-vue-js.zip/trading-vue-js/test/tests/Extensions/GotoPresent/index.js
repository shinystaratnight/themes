
// Index for the extentention

import Main from './main.js'
import Button from './Button.vue'
Main.__name__ = 'goto-present'

const widgets = { Button }
const components = {  }
const overlays = {  }
const colorpacks = {  }
const skins = {  }

const Pack = {
    widgets,
    components,
    overlays,
    colorpacks,
    skins,
    Button,
    Main
}

export default Pack

export {
    widgets,
    components,
    overlays,
    colorpacks,
    skins,
    Button,
    Main
}
