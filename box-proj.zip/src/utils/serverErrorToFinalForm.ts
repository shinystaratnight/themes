/**
 * Function to set final form error from server response with error
 */
export function serverErrorToFinalForm(serverError: any) {
  if (!serverError || !serverError.length) {
    return {};
  }
  let result: any = {};
  serverError.forEach((error: any) => {
    result[error.property] = Object.keys(error.constraints)
      .map(k => error.constraints[k])
      .join(', ');
  });
  return result;
}
