import { FormState } from 'final-form';

// Trigger handle, only when active field has been changed
// similar to onBlur action.
// Requires 'active' field to be tracked
export function changedOnBlur(handler: (state: FormState<{}>) => void) {
  let lastActive: string | undefined;
  return (state: FormState<{}>) => {
    if (lastActive && state.active !== lastActive) {
      handler(state);
    }
    lastActive = state.active;
  };
}
