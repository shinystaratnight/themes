// Is it built or locally served?
export const isProd = () => {
  return process.env.NODE_ENV === 'production';
};

// Is it limited for closed beta mode
export function isLimited(
  profile: { verified: boolean } | null
) {
  return isProd() && profile && !profile.verified;
}
