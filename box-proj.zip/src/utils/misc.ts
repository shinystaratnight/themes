import Axios from 'axios';
import { get } from 'lodash';

// ?page=welcome => { page: 'welcome' }
/**
 * Function to parse hashString
 */
export const parseHashBangArgs = (hashString?: string): any | undefined => {
  if (!hashString) return;

  const vars: any = {};
  const hashes = hashString.replace('?', '').split('&');

  for (const value of hashes) {
    const hash = value.split('=');

    if (hash.length > 1) {
      vars[hash[0]] = hash[1];
    } else {
      vars[hash[0]] = null;
    }
  }

  return vars;
};

/**
 * Interface for submit error
 */
interface ISubmitError {
  children: any[];
  constraints?: { [prop: string]: string };
  property: string;
  target: any;
}

/**
 * Function to parse submit errors
 */
export const submitErrorsParser = (errosList?: ISubmitError[]) => {
  const errors: any = {};

  if (Array.isArray(errosList)) {
    errosList.forEach(errorItem => {
      if (!errorItem.constraints) return;

      const constraints = Object.keys(errorItem.constraints).map(
        key => errorItem.constraints && errorItem.constraints[key]
      );

      errors[errorItem.property] = constraints;
    });
  }

  return errors;
};

/**
 * Function to get Youtube link id
 */
export const getYoutubeVideoId = (url: string) => {
  var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  var match = url.match(regExp);

  if (match && match[2].length == 11) {
    return match[2];
  }
};

/**
 * Function to fetch get Vimeo link id
 */
export const getVimeoVideoId = async (url: string) => {
  const { data } = await Axios.get(
    `https://vimeo.com/api/oembed.json?url=${url}`
  );

  return data.video_id;
};

/**
 * Function to get ember video url
 */
export const getEmbedVideoUrl = async (url: string) => {
  const youtubeId = getYoutubeVideoId(url);

  if (youtubeId) {
    return `https://www.youtube.com/embed/${youtubeId}`;
  }

  const vimeoId = await getVimeoVideoId(url);

  if (vimeoId) {
    return `https://player.vimeo.com/video/${vimeoId}?title=0&byline=0&portrait=0`;
  }
};

/**
 * Function to get error information from server error
 */
export const getErrorMessgae = (error: Error): string => {
  return get(error, ['response', 'data', 'message']) || 'Error';
};

export const getStandardUrl = (url: string) => {
  if (url.startsWith('http://') || url.startsWith('https://')) {
    return url;
  }
  return 'http://' + url;
};

/**
 * Function to check is touch device
 */
export function isTouchDevice() {
  return 'ontouchstart' in window;
}

export const getInitialName = (firstName: string, lastName: string): string => {
  var initialName = '';
  if (!firstName && !lastName) {
    initialName = '';
  } else if ((firstName && !lastName) || (!firstName && lastName)) {
    var name = firstName + lastName;
    var initials = name.match(/\b\w/g) || [];
    initialName = ((initials.shift() || '') + '.').toUpperCase();
  } else {
    var name = firstName + ' ' + lastName;
    var initials = name.match(/\b\w/g) || [];
    initialName = (
      (initials.shift() || '') +
      '. ' +
      (initials.pop() || '') +
      '.'
    ).toUpperCase();
  }

  return initialName;
};

export const uuid4 = () => {
  let d = new Date().getTime();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = (d + Math.random() * 16) % 16 | 0;
    d = Math.floor(d / 16);
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
};

export const isNull = (value: any) => {
  try {
    return value === null;
  } catch (e) {
    return false;
  }
};
