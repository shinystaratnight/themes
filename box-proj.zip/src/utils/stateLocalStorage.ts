import { BoxData, CardData } from "../dummy/data";

/**
 * Variable state name
 */
const STATE_VAR_NAME = 'state';
const STATE_BOX_NAME = 'box';
const STATE_SHIPPING_DATE_NAME = 'shipping_date';
const STATE_CARD_NAME = 'card';
const STATE_CART_NAME = 'cart';
const STATE_DONATIONS_NAME = 'donations';
const STATE_PROFILE_NAME = "profile";
const STATE_STEP_NAME = 'step';
const STATE_SIZE_NAME = 'size';

/**
 * Function to get state from localStorage
 */
export function loadState(): any {
  try {
    const serializedState = localStorage.getItem(STATE_VAR_NAME);
    if (serializedState) {
      return JSON.parse(serializedState);
    }
  } catch (e) {
    console.error(e);
  }
}

/**
 * Function to save state to localStorage
 */
export function saveState(state: any) {
  localStorage.setItem(STATE_VAR_NAME, JSON.stringify(state));
}

/**
 * Function to get box item from localStorage
 */
export function loadBoxState(): any {
  try {
    const boxState = localStorage.getItem(STATE_BOX_NAME);
    if (boxState) {
      return JSON.parse(boxState);
    }
  } catch (e) {
    console.error(e);
  }
  return BoxData[0];
}

/**
 * Function to save box state to localStorage
 * @param state 
 */
export function saveBoxState(state: any) {
  localStorage.setItem(STATE_BOX_NAME, JSON.stringify(state));
}

/**
 * Function to get cart items from localStorage
 */
export function loadCartItemsState(): any {
  try {
    const cartState = localStorage.getItem(STATE_CART_NAME);
    if (cartState) {
      return JSON.parse(cartState);
    }
  } catch (e) {
    console.error(e);
  }
  return [];
}

/**
 * Function to save cart items state to localStorage
 * @param state 
 */
export function saveCartItemsState(state: any) {
  localStorage.setItem(STATE_CART_NAME, JSON.stringify(state));
}

/**
 * Function to get step from localStorage
 */
export function loadStepState(): any {
  try {
    const stepState = localStorage.getItem(STATE_STEP_NAME);
    if (stepState) {
      return stepState;
    }
  } catch (e) {
    console.error(e);
  }
  return 'step1';
}

/**
 * Function to save step state to localStorage
 * @param state 
 */
export function saveStepState(state: any) {
  localStorage.setItem(STATE_STEP_NAME, state);
}

/**
 * Function to get box size from localStorage
 */
export function loadBoxSizeState(): any {
  try {
    const boxSizeState = localStorage.getItem(STATE_SIZE_NAME);
    if (boxSizeState) {
      return boxSizeState;
    }
  } catch (e) {
    console.error(e);
  }
  return 'MINI';
}

/**
 * Function to save box size state to localStorage
 * @param state 
 */
export function saveBoxSizeState(state: any) {
  localStorage.setItem(STATE_SIZE_NAME, state);
}

/**
 * Function to get shipping date from localStorage
 */
export function loadShippingDateState(): any {
  try {
    const shippingDateState = localStorage.getItem(STATE_SHIPPING_DATE_NAME);
    if (shippingDateState) {
      return shippingDateState;
    }
  } catch (e) {
    console.error(e);
  }
  return '';
}

/**
 * Function to save shipping date state to localStorage
 * @param state
 */
export function saveShippingDateState(state: any) {
  localStorage.setItem(STATE_SHIPPING_DATE_NAME, state);
}

/**
 * Function to clear all data in the localStorage
 * @param
 */
export function clearDataFromStorage() {
  localStorage.clear();
}


/**
 * Function to get selected card item from localStorage
 */
export function loadCardState(): any {
  try {
    const cardState = localStorage.getItem(STATE_CARD_NAME);
    if (cardState) {
      return JSON.parse(cardState);
    }
  } catch (e) {
    console.error(e);
  }
  return CardData[0];
}

/**
 * Function to save card item state to localStorage
 * @param state
 */
export function saveCardState(state: any) {
  localStorage.setItem(STATE_CARD_NAME, JSON.stringify(state));
}

/**
 * Function to get donation items from localStorage
 */
export function loadDonationItemsState(): any {
  try {
    const donationState = localStorage.getItem(STATE_DONATIONS_NAME);
    if (donationState) {
      return JSON.parse(donationState);
    }
  } catch (e) {
    console.error(e);
  }
  return [];
}

/**
 * Function to save donation items state to localStorage
 * @param state
 */
export function saveDonationItemsState(state: any) {
  localStorage.setItem(STATE_DONATIONS_NAME, JSON.stringify(state));
}

/**
 * Function to get profile from localStorage
 */
export function loadProfileState(): any {
  try {
    const profileState = localStorage.getItem(STATE_PROFILE_NAME);
    if (profileState) {
      return JSON.parse(profileState);
    }
  } catch (e) {
    console.error(e);
  }
  return {};
}

/**
 * Function to save profile state to localStorage
 * @param state
 */
export function saveProfileState(state: any) {
  localStorage.setItem(STATE_PROFILE_NAME, JSON.stringify(state));
}
