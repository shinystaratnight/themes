import {
  AuthAction,
  AuthActionType,
  AuthByEmailAction,
  AuthByGoogleAction,
  resetAuth,
  setAuthError,
  setAuthLoading,
  setAuthToken
} from "../actions";
import {
  AuthLogoutAction,
  AuthSetTokenAction,
  ChangePasswordAction,
  RecoverPasswordAction,
  RegisterByEmailAction,
  RegisterBySocialAction,
  RequestVerifyEmailAction,
  UpdateAuthProfileAction,
  setInitialized,
  setSocialProfile,
  CancelAccountAction,
  logout
} from "./../actions/auth.action";

import { call, put, select, takeEvery } from "redux-saga/effects";
import { rejectWith, resolveWith } from "./thunk.helper";

import { IState } from "../reducers";
import { UserProfile } from "../types/profile";
import { api } from "../services";
import { nop } from "../actions/_base.action";
import { push as pushUrl } from "connected-react-router";
import { routes } from "../routes";
import { serverErrorToFinalForm } from "../utils/serverErrorToFinalForm";
import { getErrorMessgae } from "../utils/misc";
import { setBearerToken } from "../services/api";

const DEFAULT_RESPONSE = {
  data: {
    statusCode: 0,
    message: "Unknown server error"
  }
};

function handle<T extends AuthAction>(
  type: AuthActionType,
  handler: (action: T) => void
) {
  return takeEvery(type, handler);
}

// ------------- LOGIN -------------
function* loginByEmailHandler(action: AuthByEmailAction) {
  yield put(resetAuth({}));
  yield put(setAuthLoading({ loading: true }));

  try {
    const { data } = yield call(api.rawPost, "/auth/signin", action.payload);
    yield put(
      resolveWith(
        action.meta,
        setAuthToken({
          authToken: data.access_token,
          profile: data.profile,
          passwordInited: data.passwordInited
        })
      )
    );
    yield put(
      pushUrl(routes.home())
    );
  } catch (e) {
    if (e.response && e.response.data && e.response.data.statusCode == 401) {
      yield put(
        rejectWith(
          action.meta,
          setAuthError({ email: e.response.data.message })
        )
      );
    } else {
      yield put(
        rejectWith(
          action.meta,
          setAuthError({
            email: `Server error ${
              (e.response || DEFAULT_RESPONSE).data.statusCode
            }`
          })
        )
      );
    }
  }
  yield put(setAuthLoading({ loading: false }));
}

function* loginByGoogleHandler(action: AuthByGoogleAction) {
  yield put(resetAuth({}));
  yield put(setAuthLoading({ loading: true }));
  try {
    const { data } = yield call(api.rawPost, "/auth/signin/social", {
      token: action.payload.accessToken,
      type: "google"
    });
    const { access_token: authToken, profile, passwordInited } = data;
    yield put(setAuthToken({ authToken, profile, passwordInited }));
    yield put(
      pushUrl(routes.home())
    );
  } catch (e) {
    if (e.response && e.response.data && e.response.data.statusCode == 401) {
      yield put(setSocialProfile(action.payload));
      yield put(rejectWith(action.meta, setAuthError({ SIGNUP: "SIGNUP" })));
    } else {
      yield put(
        rejectWith(
          action.meta,
          setAuthError({
            email: `Server error ${
              (e.response || DEFAULT_RESPONSE).data.statusCode
            }`
          })
        )
      );
    }
  }
  yield put(setAuthLoading({ loading: false }));
}

// ----------------- Logout -----------------

function* logoutHandler(action: AuthLogoutAction) {
  try {
    yield call(api.post, "/auth/signout", {});
  } catch (error) {}
  yield put(resetAuth({}));
  yield put(pushUrl("/"));
}

// ----------------- Register ---------------

function* registerByEmailHandler(action: RegisterByEmailAction) {
  yield put(resetAuth({}));
  yield put(setAuthLoading({ loading: true }));
  try {
    const { data } = yield call(api.post, "/signup", action.payload);
    yield put(
      resolveWith(
        action.meta,
        setAuthToken({
          authToken: data.access_token,
          profile: data.profile,
          passwordInited: true
        })
      )
    );
  } catch (e) {
    if (e.response && e.response.data && e.response.status == 400) {
      let error = e.response.data;
      if (e.response.data.message === "Invalid beta code") {
        error = [
          {
            property: "invitationCode",
            constraints: { length: e.response.data.message }
          }
        ];
      }
      yield put(
        rejectWith(action.meta, setAuthError(serverErrorToFinalForm(error)))
      );
    } else {
      yield put(
        rejectWith(
          action.meta,
          setAuthError({
            email: `Server error ${
              (e.response || DEFAULT_RESPONSE).data.statusCode
            }`
          })
        )
      );
    }
  }
  yield put(setAuthLoading({ loading: false }));
}


function* registerBySocialHandler(
  action: RegisterBySocialAction
) {
  yield put(resetAuth({}));
  yield put(setAuthLoading({ loading: true }));
  try {
    const { data } = yield call(
      api.rawPost,
      "/signup/social",
      action.payload
    );
    yield put(
      resolveWith(
        action.meta,
        setAuthToken({
          authToken: data.access_token,
          profile: data.profile,
          passwordInited: true
        })
      )
    );
  } catch (e) {
    if (e.response && e.response.data && e.response.data.statusCode == 401) {
      yield put(
        rejectWith(
          action.meta,
          setAuthError({ firstName: e.response.data.message })
        )
      );
    } else {
      yield put(
        rejectWith(
          action.meta,
          setAuthError({
            firstName: `Server error ${
              (e.response || DEFAULT_RESPONSE).data.statusCode
            }`
          })
        )
      );
    }
  }
  yield put(setAuthLoading({ loading: false }));
}

function* recoverPasswordHandler(action: RecoverPasswordAction) {
  yield put(resetAuth({}));
  yield put(setAuthLoading({ loading: true }));
  try {
    const { data } = yield call(
      api.post,
      "/account/request-change-password",
      action.payload
    );
    yield put(resolveWith(action.meta, nop({ message: data.message })));
  } catch (e) {
    console.error(e.response);
    yield put(
      rejectWith(
        action.meta,
        setAuthError({
          email: `Server error ${
            (e.response || DEFAULT_RESPONSE).data.statusCode
          }`
        })
      )
    );
  }
  yield put(setAuthLoading({ loading: false }));
}

function* changePasswordHandler(action: ChangePasswordAction) {
  yield put(setAuthLoading({ loading: true }));
  try {
    const { data } = yield call(
      api.post,
      "/account/change-password",
      action.payload
    );
    yield put(
      resolveWith(
        action.meta,
        setAuthToken({
          authToken: data.access_token,
          profile: data.profile,
          passwordInited: true
        })
      )
    );
    const profile = yield select<IState>(s => s.auth.profile);
    yield put(resolveWith(action.meta, pushUrl(routes.home())));
  } catch (e) {
    if (e.response && e.response.data && e.response.data.statusCode == 400) {
      yield put(rejectWith(action.meta, nop({ expired: "you bet" })));
    } else {
      yield put(
        rejectWith(
          action.meta,
          nop({
            email: `Server error ${
              (e.response || DEFAULT_RESPONSE).data.statusCode
            }`
          })
        )
      );
    }
  }
  yield put(setAuthLoading({ loading: false }));
}

function* requestVerifyEmailHandler(action: RequestVerifyEmailAction) {
  try {
    yield call(api.post, "/account/request-email-verification", action.payload);
  } catch (e) {
    console.error(e);
  }
}

function setTokenHandler(action: AuthSetTokenAction) {
  try {
    setBearerToken(action.payload.authToken);
  } catch (e) {
    console.error(e);
  }
}

function* updateProfileHandler(action: UpdateAuthProfileAction) {
  const auth = yield select<IState>(state => state.auth);
  if (auth.authenticated) {
    // Update auth profile
    try {
      const { data } = yield call(
        api.get,
        "/user/profile",
        action.payload
      );
      // yield put(resolveWith(action.meta, setProfile({ profile: data })));
    } catch (e) {
      console.error(e);
    }
    yield put(setInitialized({ initialized: true }));
  } else {
    yield put(setInitialized({ initialized: true }));
  }
}

export const getProfile = (state: IState) => state.auth.profile;

function* cancelAccount(action: CancelAccountAction) {
  try {
    const profile = yield select(getProfile);
    const userId = profile.id;
    yield call(api.delete, `/user/${userId}`);
    yield put(logout({}));
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

export default function* authSaga() {
  yield handle("AUTH_SET_TOKEN", setTokenHandler);
  // login
  yield handle("AUTH_LOGIN_BY_EMAIL", loginByEmailHandler);
  yield handle("AUTH_LOGIN_BY_GOOGLE", loginByGoogleHandler);
  // register
  yield handle("AUTH_REGISTER_BY_EMAIL", registerByEmailHandler);
  yield handle("AUTH_REGISTER_BY_SOCIAL", registerBySocialHandler);
  // logout
  yield handle("AUTH_LOGOUT", logoutHandler);
  // recover password
  yield handle("AUTH_RECOVER_PASSWORD", recoverPasswordHandler);
  // change password
  yield handle("AUTH_CHANGE_PASSWORD", changePasswordHandler);
  // request verify email
  yield handle("AUTH_REQUEST_VERIFY_EMAIL", requestVerifyEmailHandler);
  // update profile
  yield handle("AUTH_UPDATE_PROFILE", updateProfileHandler);

  yield handle("CANCEL_ACCOUNT", cancelAccount);
}
