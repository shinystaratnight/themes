import {
  RemoveProductFromBoxAction,
  LocalAction,
  LocalActionType,
  SetStepAction,
  setCartItems,
  AddProductToBoxAction,
  ChooseBoxAction,
  SetBoxSizeAction,
  ChooseCardAction,
  RemoveDonationItemAction,
  AddDonationItemAction,
  setDonationItems,
  SetProfileAction, SetShippingDateAction
} from "../actions";

import { call, put, select, takeEvery } from "redux-saga/effects";
import { rejectWith, resolveWith } from "./thunk.helper";

import { IState } from "../reducers";
import { UserProfile } from "../types/profile";
import { api } from "../services";
import { nop } from "../actions/_base.action";
import { push as pushUrl } from "connected-react-router";
import { routes } from "../routes";
import { serverErrorToFinalForm } from "../utils/serverErrorToFinalForm";
import { getErrorMessgae } from "../utils/misc";
import { setBearerToken } from "../services/api";
import { CartItem, Product } from "../types/product";
import {
  saveBoxSizeState,
  saveBoxState,
  saveCardState,
  saveCartItemsState, saveDonationItemsState, saveProfileState, saveShippingDateState,
  saveStepState
} from "../utils/stateLocalStorage";

const DEFAULT_RESPONSE = {
  data: {
    statusCode: 0,
    message: "Unknown server error"
  }
};

function handle<T extends LocalAction>(
  type: LocalActionType,
  handler: (action: T) => void
) {
  return takeEvery(type, handler);
}

export const getCartItems = (state: IState) => state.local.cart;

function* addProductToBoxHandler(action: AddProductToBoxAction) {
  try {
    let cartItems = yield select(getCartItems);
    let isMatch = false;
    for (let i in cartItems ) {
      if (cartItems[i].product['product_id'] == action.payload.product['product_id']) {
        cartItems[i].count = cartItems[i].count + 1;
        isMatch = true;
        break;
      }
    }

    if (!isMatch) {
      cartItems.push({ product: action.payload.product, count: 1 });
    }
    
    // Save updated cart items into local storage
    yield call(saveCartItemsState, cartItems);
    
    // Call another action
    yield put(setCartItems({ cartItems }));
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* removeProductFromBoxHandler(action: RemoveProductFromBoxAction) {
  try {
    let cartItems = yield select(getCartItems);
    for (let i in cartItems ) {
      if (cartItems[i].product['product_id'] == action.payload.product['product_id']) {
        if (cartItems[i].count > 1) {
          cartItems[i].count = cartItems[i].count - 1;
        } else {
          cartItems.splice(i, 1);
        }
        break;
      }
    }

    // Save updated cart items into local storage
    yield call(saveCartItemsState, cartItems);

    // Call another action
    yield put(setCartItems({ cartItems }));
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* chooseBoxHandler(action: ChooseBoxAction) {
  try {
    yield call(saveBoxState, action.payload.box);
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* chooseCardHandler(action: ChooseCardAction) {
  try {
    yield call(saveCardState, action.payload.card);
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* setStepHandler(action: SetStepAction) {
  try {
    yield call(saveStepState, action.payload.step);
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* setProfileHandler(action: SetProfileAction) {
  try {
    console.log('saga is calling');
    yield call(saveProfileState, action.payload.profile);
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* setBoxSizeHandler(action: SetBoxSizeAction) {
  try {
    yield call(saveBoxSizeState, action.payload.size);
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* setShippingDateHandler(action: SetShippingDateAction) {
  try {
    yield call(saveShippingDateState, action.payload.date);
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

export const getDonationItems = (state: IState) => state.local.donations;

function* addDonationItemHandler(action: AddDonationItemAction) {
  try {
    let donationItems = yield select(getDonationItems);
    let isMatch = false;
    for (let i = 0; i < donationItems.length; i++ ) {
      if (donationItems[i].id == action.payload.item.id) {
        isMatch = true;
        break;
      }
    }

    if (!isMatch) {
      donationItems.push(action.payload.item);
    }

    // Save updated donation items into local storage
    yield call(saveDonationItemsState, donationItems);

    // Call another action
    yield put(setDonationItems({ items: donationItems }));
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

function* removeDonationItemHandler(action: RemoveDonationItemAction) {
  try {
    let donationItems = yield select(getDonationItems);
    let isMatch = false;
    for (let i = 0; i < donationItems.length; i++ ) {
      if (donationItems[i].id === action.payload.item.id) {
          donationItems.splice(i, 1);
          isMatch = true;
          break;
      }
    }

    // Save updated donation items into local storage
    yield call(saveDonationItemsState, donationItems);

    // Call another action
    yield put(setDonationItems({ items: donationItems }));
  } catch (e) {
    const error = getErrorMessgae(e);
    console.warn(error);
  }
}

export default function* localSaga() {
  yield handle("LOCAL_ADD_PRODUCT_TO_BOX", addProductToBoxHandler);
  yield handle("LOCAL_REMOVE_PRODUCT_FROM_BOX", removeProductFromBoxHandler);
  yield handle("LOCAL_CHOOSE_BOX", chooseBoxHandler);
  yield handle("LOCAL_CHOOSE_CARD", chooseCardHandler);
  yield handle("LOCAL_SET_BOXSIZE", setBoxSizeHandler);
  yield handle("LOCAL_SET_SHIPPING_DATE", setShippingDateHandler);
  yield handle("LOCAL_SET_PROFILE", setProfileHandler);
  yield handle("LOCAL_SET_STEP", setStepHandler);
  yield handle("LOCAL_ADD_DONATION_ITEM", addDonationItemHandler);
  yield handle("LOCAL_REMOVE_DONATION_ITEM", removeDonationItemHandler);
}
