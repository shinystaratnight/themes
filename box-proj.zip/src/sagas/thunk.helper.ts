/**
 * wrap action to resolve saga
 * yield put(resolveWith(action.meta, anyAction()));
 */
export function resolveWith(meta: any, action: any): any {
  return {
    ...action,
    meta
  };
}

/**
 * wrap action to reject saga
 * yield put(rejectWith(action.meta, errorAction()));
 */
export function rejectWith(meta: any, action: any): any {
  return {
    ...action,
    error: true,
    meta
  };
}

/**
 * helper for dispatching an action handled by redux-saga returns promise
 *
 * wrap an action with the asThunk in a mapDispatchToProps
 * const mapDispatchToProps = { youAction: asThunk(youAction) };
 */
export function asThunk<T>(f: (payload: T) => any) {
  return function(payload: T) {
    return {
      ...f(payload),
      meta: {
        thunk: true
      }
    };
  };
}
