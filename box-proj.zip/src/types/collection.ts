// Collection item
export interface Collection {
  collection_id: string;
  title: string;
}
