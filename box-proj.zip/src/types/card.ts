// Card items
export interface Card {
  id: number;
  title: string;
  image: string;
  unit_symbol: string;
  min_unit: number;
  price: string;
}

export interface DonationCard {
  id: number;
  title: string;
  link: string;
  image: string;
  note: string;
}
