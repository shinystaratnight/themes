// Box items
export interface Box {
  id: number;
  images: string[];
  title: string;
  min_unit: number;
  price: number;
}
