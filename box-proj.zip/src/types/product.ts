// Product item
export interface Product {
  product_id: string;
  collection_id: string;
  title: string;
  prod_image: string;
  brand_image: string;
  short_desc: string;
  price: number;
  color: string;
}

export interface CartItem {
  product: Product;
  count: number;
}
