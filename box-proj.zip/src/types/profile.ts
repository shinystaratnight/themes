// User profile
export interface UserProfile {
  firstName: string;
  lastName: string;
  address: string;
  apartment: string;
  city: string;
  state: string;
  zipCode: string;
  email: string;
  phoneNumber: string;
}
