import * as React from 'react';
import * as Sentry from '@sentry/browser';

import { AuthState, IState } from './reducers';

import AppCrash from './components/AppCrash/AppCrash';
import { ConnectedRouter } from 'connected-react-router';
import { History } from 'history';
import { connect } from 'react-redux';
import { routing } from './routes';
import { updateAuthProfile } from './actions';

interface IAppProps {
  // own props
  history: History;
  // state map
  auth: AuthState;
  // dispatch map
  updateAuthProfile: typeof updateAuthProfile;
}

interface IAppState {
  hasError: boolean;
}

class App extends React.PureComponent<IAppProps, IAppState> {
  state = {
    hasError: false
  };

  componentDidMount() {
    this.props.updateAuthProfile({});
  }

  // Will catch all own & children errors
  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    if (process.env.REACT_APP_SENTRY_DSN) {
      Sentry.addBreadcrumb({
        category: 'componentStack',
        message: errorInfo.componentStack
      });
      Sentry.captureException(error);
    }
    this.setState({ hasError: true });
  }

  recoverFromCrash = () => {
    this.setState({ hasError: false });
    // Force app reload
    window.location.replace(process.env.REACT_APP_PUBLIC_URL || '/');
  };

  render() {
    const { history } = this.props;
    const { hasError } = this.state;
    return (
      <React.Fragment>
        { hasError ? (
          <AppCrash onGoHome={this.recoverFromCrash} />
        ) : (
          <ConnectedRouter history={history}>
            <React.Fragment>
              {routing}
            </React.Fragment>
          </ConnectedRouter>
        )}
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state: IState) => ({
  auth: state.auth
});
const mapDispatchToProps = {
  updateAuthProfile
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
