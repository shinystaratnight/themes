import * as React from 'react';
import { connect } from 'react-redux';

import { ReactComponent as GiftLogo } from '../../assets/images/ic_gift_logo_md.svg';
import { MediaQuery, Button } from '../../uikit';
import { Cart } from '../Cart';
import css from './Header.module.scss';
import { setStep } from '../../actions';
import { IState } from '../../reducers';

/**
 * Header component props interface
 */
interface Props {
  step?: string;
  setStep: typeof setStep;
}

/**
 * display header section of page
 */
const Header: React.FunctionComponent<Props> = props => {
  const { step, setStep } = props;
  return (
    <div className={css.container}>
      <div className={css.leftSide}>
        <div className={css.logoWrapper}>
          <GiftLogo className={css.logo} onClick={() => { setStep({ step: 'step1' });}} />
        </div>
      </div> 

      <div className={css.rightSide}>
        {/* { step !== 'step5' && <Cart className={css.nav} /> } */}
        <Button className={css.button} style="plain" onClick={() => {
            if (step === 'step5') {
                setStep({ step: 'step4' });
            } else if (step === 'step4') {
                setStep({ step: 'step3' });
            } else if (step === 'step3') {
                setStep({ step: 'step2' });
            } else {
                setStep({ step: 'step1' });
            }
        }}>
          { step === 'step2' ? '< BACK TO STEP 1' : step === 'step3' ? '< BACK TO STEP 2'
              : step === 'step4' ? '< BACK TO STEP 3' : step === 'step5' ? '< BACK TO INFORMATION' : 'GET IN TOUCH' }
        </Button>
      </div>
    </div>
  );
};

const mapStateToProps = (state: IState) => ({

})

const mapDispatchToProps = {
  setStep
}

export default connect(mapStateToProps, mapDispatchToProps)(Header);
