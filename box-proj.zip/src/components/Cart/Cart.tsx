import * as React from "react";

import Dropdown, { DropdownItem } from "../../uikit/Dropdown/Dropdown";

import { ReactComponent as CartIcon } from "../../assets/images/ic_cart.svg";
import { IState } from "../../reducers";
import cn from "classnames";
import { connect } from "react-redux";
import css from "./Cart.module.scss";
import { logout } from "../../actions";
import { push } from "connected-react-router";
import { routes } from "../../routes";

/**
 * Cart component props interface
 */
interface CartProps {
  className?: string;
  push: typeof push;
  logout: typeof logout;
  contentPosition?: "top";
}

/**
 * display cart section for authenticated users
 */
const Cart: React.FunctionComponent<CartProps> = React.memo(
  props => {
    const { className, contentPosition, push, logout } = props;
    const items: DropdownItem[] = [
      {
        id: "settings",
        title: "Settings",
        action: () => push(routes.home())
      },
      {
        id: "logout",
        title: "Logout",
        action: () => logout({})
      }
    ];

    return (
      <div className={cn(css.nav, className)}>
        <Dropdown
          items={items}
          contentPosition={contentPosition}
          className={css.dropdown}
        >
          {({ isOpen }) => (
            <div className={css.container}>
              <CartIcon className={css.cartIcon} />
              <span className={css.cartBrand}>{items.length}</span>
            </div>
          )}
        </Dropdown>
      </div>
    );
  }
);

const mapStateToProps = (state: IState) => ({
  reducedProfile: state.auth.profile
});
export default connect(mapStateToProps, { push, logout })(Cart);
