import PreloadingAnimation from '../../assets/images/preloader/GG_Icon2.gif';
import React from 'react';
import css from './AppLoading.module.scss';

/**
 * App loading function
 */
export const AppLoading = () => (
  <div className={css.container}>
    <img src={PreloadingAnimation} />
  </div>
);
