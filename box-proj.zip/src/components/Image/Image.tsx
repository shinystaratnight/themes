import React, { useState } from 'react';

/**
 * Image component props interface
 */
interface ImageProps {
  errorImage?: string;
}

/**
 * component for displaying image
 */
export const Image = React.memo(function({
  src,
  errorImage,
  ...props
}: React.DetailedHTMLProps<
  React.ImgHTMLAttributes<HTMLImageElement>,
  HTMLImageElement
> &
  ImageProps) {
  const [source, setSource] = useState<string | undefined>(undefined);
  const [error, setError] = useState(false);
  const onError = () => setError(true);
  // implement getDerivedStateFromProps for FP
  if (src !== source) {
    setSource(src);
    setError(false);
  }
  
  return (
    <img
      src={source && !error ? source : errorImage}
      onError={onError}
      {...props}
    />
  );
});
