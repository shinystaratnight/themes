import * as React from 'react';
import cn from 'classnames';

import { Link } from '../../uikit';
import { ReactComponent as GiftLogo } from '../../assets/images/ic_gift_logo_bg.svg';
import css from './Footer.module.scss';
import { Image } from '../Image';
import { IState } from '../../reducers';
import { connect } from 'react-redux';

import { ReactComponent as EmailIcon } from '../../assets/images/ic_email.svg';
import { ReactComponent as InstagramIcon } from '../../assets/images/ic_instagram.svg';
import { ReactComponent as FacebookIcon } from '../../assets/images/ic_facebook.svg';
import { ReactComponent as PinterestIcon } from '../../assets/images/ic_pinterest.svg';
import { ReactComponent as TwitterIcon } from '../../assets/images/ic_twitter.svg';
import { ReactComponent as LinkedinIcon } from '../../assets/images/ic_linkedin.svg';

/**
 *  Footer component props interface
 */
interface IFooterProps {
  step?: string;
}

/**
 * Footer component
 */
const Footer: React.FunctionComponent<IFooterProps> = props => {
  const {
    step = "step1"
  } = props;
  
  const showBanner = true;
  const showLogo = step !== 'step4';
  return (
    <div className={cn(css.footer)}>
      { showBanner && 
      <div className={cn(css.footerContainer, css[step + '_banner_bg'], css.bannerSection)}></div>
      }
      { showLogo && 
      <div className={cn(css.footerContainer, css.logoSection)}>
        <GiftLogo className={css.footerLogo} />
      </div>
      }
      { step !== 'step4' &&
        <div className={cn(css.footerContainer, css.bordered)}>
          <div className={css.col}>
            Powered by 
            <Link linkStyle="regular" target="_blank" to={process.env.REACT_APP_GIFTS_FORWARD_URL || '#'}
                  className={css.linkLeftMargin}>Gifts for Good</Link>
          </div>
          <div className={css.col}>
            <Link linkStyle="regular" target="_blank" to={process.env.REACT_APP_GIFTS_FORWARD_TERMS_URL || '#'} 
                  className={cn(css.linkRightMargin, css.lightText)}>Terms</Link> | 
            <Link linkStyle="regular" target="_blank" to={process.env.REACT_APP_GIFTS_FORWARD_PRIVACY_URL || '#'} 
                  className={cn(css.linkLeftMargin, css.lightText)}>Privacy</Link>
          </div>
        </div>
      }
      { step === 'step4' && 
        <div className={cn(css.footerContainer, css.bordered, css.compoundFooter)}>
          <div className={cn(css.col, css.flex_3, css.logo_col)}>
            <GiftLogo />
            <Link linkStyle="regular" to='mailto:hello@giftsforgood.com'>hello@giftsforgood.com</Link>
            <Link linkStyle="regular" to='tel:(877)%20554-1550'>(877) 554-1550</Link>
          </div>
          <div className={cn(css.row, css.flex_5)}>
            <div className={cn(css.col, css.flex_1)}>
              <h4>ABOUT</h4>
              <ul>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/our-impact'>Our Impact</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/about'>Our Story</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/our-ceo'>Our CEO</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/press-media'>Press & Media</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/request-a-catalog'>Request a Catalog</Link></li>
              </ul>
            </div>
            <div className={cn(css.col, css.flex_1)}>
              <h4>HELP</h4>
              <ul>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/contact'>Contact</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/contact'>Customer Service</Link></li>
              </ul>
            </div>
            <div className={cn(css.col, css.flex_1)}>
              <h4>GET INVOLVED</h4>
              <ul>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/careers'>Careers</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/partner-with-us'>Partner With Us</Link></li>
                <li><Link linkStyle="regular" target="_blank" to='https://www.giftsforgood.com/pages/rep-program'>Rep Program</Link></li>
              </ul>
            </div>
          </div>
          <div className={cn(css.col, css.flex_3, css.contact_col)}>
            <h4>CONNECT WITH US</h4>
            <div className={css.contact_row}>
              <input type="text" placeholder="Enter your email" />
              <EmailIcon />
            </div>
            <div className={css.social_row}>
              <Link linkStyle="regular" target="_blank" to='https://www.instagram.com/giftsforgoodhq/'><InstagramIcon /></Link>
              <Link linkStyle="regular" target="_blank" to='https://www.facebook.com/giftsforgoodhq'><FacebookIcon /></Link>
              <Link linkStyle="regular" target="_blank" to='https://www.pinterest.com/GiftsForGoodHQ'><PinterestIcon /></Link>
              <Link linkStyle="regular" target="_blank" to='https://twitter.com/GiftsForGoodhq'><TwitterIcon /></Link>
              <Link linkStyle="regular" target="_blank" to='https://www.linkedin.com/company/17947311/'><LinkedinIcon /></Link>
            </div>
          </div>
        </div>
      }
      
    </div>
  );
};

const mapStateToProps = (state: IState) => ({
  step: state.local.step,
})

export default connect(mapStateToProps)(Footer);
