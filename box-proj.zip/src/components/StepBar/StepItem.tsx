import * as React from 'react';
import { connect } from 'react-redux';
import cn from 'classnames';

import css from './StepBar.module.scss';
import { IState } from '../../reducers';
import { setStep } from '../../actions';

/**
 * StepItem component props interface
 */
interface IStepItemProps {
  global_step?: string;
  my_step: string;
  disp_title: string;
  disp_note: string;
  setStep: typeof setStep;
}

/**
 * StepItem component
 */
const StepItem: React.FunctionComponent<IStepItemProps> = props => {
  const { global_step, my_step, disp_title, disp_note, setStep } = props;
  
  return (
    <div className={css['col-3']}>
      <div className={cn(css.step_item, global_step === my_step ? css.step_active : '')} 
            onClick={() => setStep({ step: my_step })}>
        <div>
          <h4>{disp_title}</h4>
          <p>{disp_note}</p>
        </div>
      </div>
    </div>
  );
};


const mapStateToProps = (state: IState) => {
  return {
    global_step: state.local.step
  };
};

const mapDispatchToProps = {
  setStep
};

export default connect(mapStateToProps, mapDispatchToProps)(StepItem);
