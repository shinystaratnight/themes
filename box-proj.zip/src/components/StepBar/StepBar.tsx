import * as React from 'react';
import { connect } from 'react-redux';
import cn from 'classnames';

import css from './StepBar.module.scss';
import { IState } from '../../reducers';
import StepItem from './StepItem';

/**
 * Header component props interface
 */
interface Props {
  step?: string;
}

/**
 * display header section of page
 */
const StepBar: React.FunctionComponent<Props> = props => {
  const { step } = props;
  const addtional_css = step + '_label_over';

  return (
    <div className={css.container}>
      <section className={css.step_area}>
        <div className={css.container_fluid}>
          <div className={css.step_label_bg}>
            <div className={cn(css.step_label_over, css[addtional_css])}></div>
          </div>
          <div className={css.row}>
            <StepItem disp_title="STEP 1" disp_note="Packaging" my_step="step1" />
            <StepItem disp_title="STEP 2" disp_note="Items" my_step="step2" />
            <StepItem disp_title="STEP 3" disp_note="Card" my_step="step3" />
            <StepItem disp_title="INFORMATION" disp_note="" my_step="step4" />
            <StepItem disp_title="SHIP DATE" disp_note="" my_step="step5" />
          </div>
        </div>
      </section>
    </div>
  );
};


const mapStateToProps = (state: IState) => {
  return {
    step: state.local.step
  };
};

export default connect(mapStateToProps)(StepBar);
