import { Button, Panel } from '../../uikit';
import React, { FunctionComponent } from 'react';

import { ReactComponent as GiftLogo } from '../../assets/images/ic_gift_logo_bg.svg';
import css from './AppCrash.module.scss';

/**
 * AppCrash props interface
 */
interface AppCrashProps {
  onGoHome: () => void;
}

/**
 * App crash display component
 */
const AppCrash: FunctionComponent<AppCrashProps> = React.memo(function({
  onGoHome
}) {
  return (
    <div className={css.wrapper}>
      <Panel className={css.panel}>
        <GiftLogo className={css.icon} />
        <span className={css.title}>Opps! Something went wrong</span>
        <p className={css.text}>
          We're working on the problem, and appreciate your patience.
        </p>
        <Button className={css.button} style="plain" onClick={onGoHome}>
          Home page
        </Button>
      </Panel>
    </div>
  );
});

export default AppCrash;
