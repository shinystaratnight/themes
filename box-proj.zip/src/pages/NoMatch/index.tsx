import React, { FunctionComponent } from 'react';

import { Button } from '../../uikit';
import { Redirect } from 'react-router';
import css from './nomatch.module.scss';
import { routes } from '../../routes';
import { ReactComponent as GiftLogo } from '../../assets/images/ic_gift_logo_bg.svg';

interface INoMatchProps {
  title?: string;
  description?: string;
}

/**
 * NoMatch page for 404 error
 */

const NoMatch: FunctionComponent<INoMatchProps> = React.memo(props => {
  const [homeRedirectAllowed, allowRedirect] = React.useState(false);
  const handleRedirectToHome = () => {
    allowRedirect(true);
  };
  const {
    title = 'Oh, snap, 404 error!',
    description = 'It seems that page you’re looking for is blocked or doesn’t exist. Please try again'
  } = props;

  if (homeRedirectAllowed) {
    return <Redirect to={routes.home()} />;
  }

  return (
    <div className={css.container}>
      <div className={css.noMatchContainer}>
        <GiftLogo className={css.icon} />
        <h2 className={css.title}>{title}</h2>
        <p className={css.description}>{description}</p>
        <Button
          className={css.button}
          style="bordered"
          onClick={handleRedirectToHome}
        >
          Home Page
        </Button>
      </div>
    </div>
  );
});

export default NoMatch;
