import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './information.module.scss';

/**
 * InformationTitle component props interface
 */
interface IInformationTitleProps {
  auth: AuthState;
}

/**
 * InformationTitle component
 */
const InformationTitle: React.FunctionComponent<IInformationTitleProps> = props => {
  return (
    <div className={css.shipping_title_area}>
      <h3 className={css.page_title}>Please provide <i>your</i> details</h3>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(InformationTitle);
