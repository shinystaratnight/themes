import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import InformationTitle from './information-title';
import InformationContent from './information-content';

/**
 * Information component props interface
 */
interface IInformationProps {
  auth: AuthState;
}

/**
 * Information Component
 */
const Information: React.FunctionComponent<IInformationProps> = props => {
  return (
    <div>
      <InformationTitle />
      <InformationContent />
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(Information);
