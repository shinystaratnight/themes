import * as React from 'react';
import { connect } from 'react-redux';

import {IState, LocalState} from '../../reducers';
import css from './information.module.scss';
import { Button } from '../../uikit';
import {setProfile, setStep} from '../../actions';
import { Image } from '../../components/Image';
import { ReactComponent as HeartIcon } from '../../assets/images/ic_heart.svg';
import {ProdData} from "../../dummy/data";

/**
 * InformationContent component props interface
 */
interface IInformationContentProps {
  localData: LocalState;
  setProfile: typeof setProfile;
  setStep: typeof setStep;
}

/**
 * InformationContent component
 */
class InformationContent extends React.Component<IInformationContentProps> {
  private _input_first_name: any = React.createRef();
  private _input_last_name: any = React.createRef();
  private _input_address: any = React.createRef();
  private _input_apartment: any = React.createRef();
  private _input_city: any = React.createRef();
  private _input_state: any = React.createRef();
  private _input_zip_code: any = React.createRef();
  private _input_email: any = React.createRef();
  private _input_phone: any = React.createRef();

  constructor(props: IInformationContentProps) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // @ts-ignore
  handleSubmit() {
    const profile = {
      firstName: this._input_first_name.current.value,
      lastName: this._input_last_name.current.value,
      address: this._input_address.current.value,
      apartment: this._input_apartment.current.value,
      city: this._input_city.current.value,
      state: this._input_state.current.value,
      zipCode: this._input_zip_code.current.value,
      email: this._input_email.current.value,
      phoneNumber: this._input_phone.current.value,
    }
    console.log(profile);
    this.props.setProfile({ profile });
    this.props.setStep({ step: 'step5' });
  }

  render() {
    const { localData } = this.props;
    console.log(localData.profile);

    return (
      <div className={css.shipping_content_area}>
        <div className={css.main_content}>
          <div className={css.shipping_prod_section}>
            <Image alt='Box item image' src={ProdData[0].prod_image} className={css.prod_image} onClick={() => {}} />
            <span className={css.prod_title}>Don Javier Handcrafted Briefcase</span>
            <span className={css.prod_support_note}>
            <span>Your Gift <i>for</i> Good supporting</span>
            <HeartIcon />
          </span>
          </div>
          <div className={css.shipping_input_section}>
            <form>
              <div className={css.row}>
                <div className={css.field}>
                  <span className={css.input_label}>FIRST NAME</span>
                  <input type="text" className={css.input_field} ref={ this._input_first_name } defaultValue={localData.profile.firstName} />
                </div>
                <div className={css.field}>
                  <span className={css.input_label}>LAST NAME</span>
                  <input type="text" className={css.input_field} ref={ this._input_last_name } defaultValue={localData.profile.lastName} />
                </div>
              </div>
              <div className={css.divider}></div>
              <div className={css.row}>
                <div className={css.field}>
                  <span className={css.input_label}>ADDRESS</span>
                  <input type="text" className={css.input_field} ref={ this._input_address } defaultValue={localData.profile.address} />
                </div>
                <div className={css.field}>
                  <span className={css.input_label}>SUITE / APARTMENT</span>
                  <input type="text" className={css.input_field} ref={ this._input_apartment } defaultValue={localData.profile.apartment} />
                </div>
              </div>
              <div className={css.row}>
                <div className={css.field}>
                  <span className={css.input_label}>CITY</span>
                  <input type="text" className={css.input_field} ref={ this._input_city } defaultValue={localData.profile.city} />
                </div>
                <div className={css.field}>
                  <span className={css.input_label}>STATE</span>
                  <input type="text" className={css.input_field} ref={ this._input_state } defaultValue={localData.profile.state} />
                </div>
                <div className={css.field}>
                  <span className={css.input_label}>ZIP CODE</span>
                  <input type="text" className={css.input_field} ref={ this._input_zip_code } defaultValue={localData.profile.zipCode} />
                </div>
              </div>
              <div className={css.divider}></div>
              <div className={css.row}>
                <div className={css.field}>
                  <span className={css.input_label}>EMAIL ADDRESS</span>
                  <input type="text" className={css.input_field} ref={ this._input_email } defaultValue={localData.profile.email} />
                </div>
                <div className={css.field}>
                  <span className={css.input_label}>PHONE NUMBER</span>
                  <input type="text" className={css.input_field} ref={ this._input_phone } defaultValue={localData.profile.phoneNumber} />
                </div>
              </div>
            </form>

            <div className={css.row}>
              <Button className={css.button} style="plain" onClick={this.handleSubmit}>
                CONFIRM
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }
};

const mapStateToProps = (state: IState) => {
  return {
    localData: state.local
  };
};

const mapDispatchToProps = {
  setProfile,
  setStep
}

export default connect(mapStateToProps, mapDispatchToProps)(InformationContent);
