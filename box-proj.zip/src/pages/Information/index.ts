export { default as Information } from './information';
