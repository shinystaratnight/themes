export { default as Thanks } from './thanks';
