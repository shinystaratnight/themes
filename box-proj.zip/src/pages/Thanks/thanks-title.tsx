import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './thanks.module.scss';
import { ReactComponent as ThanksIcon } from '../../assets/images/ic_thanks.svg';

/**
 * ThanksTitle component props interface
 */
interface IThanksTitleProps {
  auth: AuthState;
}

/**
 * ThanksTitle component
 */
const ThanksTitle: React.FunctionComponent<IThanksTitleProps> = props => {
  return (
    <div className={css.thanks_title_area}>
      <ThanksIcon className={css.title_logo} />
      <h3 className={css.page_title}>Thank you <i>for</i> doing good!</h3>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ThanksTitle);
