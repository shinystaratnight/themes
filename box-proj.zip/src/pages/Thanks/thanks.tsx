import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './thanks.module.scss';
import ThanksTitle from './thanks-title';
import ThanksContent from './thanks-content';

/**
 * Thanks component props interface
 */
interface IThanksProps {
  auth: AuthState;
}

/**
 * Thanks component
 */
const Thanks: React.FunctionComponent<IThanksProps> = props => {
  return (
    <div>
      <ThanksTitle />
      <ThanksContent />
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(Thanks);
