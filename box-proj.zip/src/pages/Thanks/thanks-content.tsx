import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './thanks.module.scss';

/**
 * ThanksContent component props interface
 */
interface IThanksContentProps {
  auth: AuthState;
}

/**
 * ThanksContent component
 */
const ThanksContent: React.FunctionComponent<IThanksContentProps> = props => {
  return (
    <div className={css.thanks_content_area}>
      <h3>Your inquiry has been made.</h3>
      <p>Our gifting concierge will email you soon to schedule a time to review your gift(s) together. <br/>
      In the meantime, learn more about our story and mission by <b>watching our feature on the TODAY Show!</b></p>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ThanksContent);
