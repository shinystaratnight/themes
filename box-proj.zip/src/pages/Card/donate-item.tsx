import * as React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import {IState, LocalState} from '../../reducers';
import { Image } from '../../components/Image';
import { ReactComponent as CheckIcon } from '../../assets/images/ic_check_sm.svg';
import css from './card.module.scss';
import {addDonationItem, removeDonationItem} from "../../actions";
import {DonationCard} from "../../types";

/**
 * DonateItem component props interface
 */
interface IDonateItemProps {
  item: DonationCard;
  localData: LocalState;
  addDonationItem: typeof addDonationItem;
  removeDonationItem: typeof removeDonationItem;
}

/**
 * DonateItem component
 */
const DonateItem: React.FunctionComponent<IDonateItemProps> = props => {
  const { item, localData, addDonationItem, removeDonationItem } = props;
  const isActive = localData.donations.find(value => value.id === item.id);
  return (
    <div className={cn(css.donate_item, isActive ? css.active : '')}>
        <Image alt='Donate item image' src={item.image} className={css.donate_item_image}
               onClick={() => { isActive ? removeDonationItem({ item }) : addDonationItem({ item }); }} />
        <CheckIcon className={css.donate_item_check_icon} />
        <div className={css.donate_item_bottom_section}>
          <h4 className={css.donate_item_title}>{item.title}</h4>
          <h6 className={css.donate_item_note}>{item.note}</h6>
          <div className={css.donate_item_link}>
            <a href={item.link} target="_blank">LEARN MORE</a>
          </div>
        </div>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    localData: state.local
  };
};

const mapDispatchToProps = {
    addDonationItem,
    removeDonationItem
}

export default connect(mapStateToProps, mapDispatchToProps)(DonateItem);
