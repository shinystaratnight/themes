import * as React from 'react';
import { connect } from 'react-redux';

import { IState } from '../../reducers';
import css from './card.module.scss';
import DonateItem from './donate-item';
import { Button } from '../../uikit';
import { setStep } from '../../actions';
import { DonateData } from "../../dummy/data";

/**
 * DonateContent component props interface
 */
interface IDonateContentProps {
  setStep: typeof setStep;
}

/**
 * DonateContent component
 */
const DonateContent: React.FunctionComponent<IDonateContentProps> = props => {

  return (
    <div className={css.donate_content_area}>
      <div className={css.donate_item_row}>
        {
          DonateData.map((value, index) => {
            return <DonateItem key={index} item={value} />
          })
        }
      </div>
      
      <Button className={css.button} style="plain" onClick={() => {
          props.setStep({ step: 'step4' });
      }}>
        NEXT STEP
      </Button>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {

  };
};

const mapDispatchToProps = {
  setStep
}

export default connect(mapStateToProps, mapDispatchToProps)(DonateContent);
