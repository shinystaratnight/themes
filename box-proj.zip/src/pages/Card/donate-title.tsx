import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './card.module.scss';

/**
 * DonateTitle component props interface
 */
interface IDonateTitleProps {
  auth: AuthState;
}

/**
 * DonateTitle component
 */
const DonateTitle: React.FunctionComponent<IDonateTitleProps> = props => {
  return (
    <div className={css.donate_title_area}>
      <h3 className={css.page_title}>Would <i>you</i> like to add an In Your Honor Donation Card?</h3>
        <p className={css.page_note}>Our signature <a href="https://www.giftsforgood.com/collections/donation-honor-cards" target="_blank">In Your Honor Donation Cards</a> are $2 - $3 including a tangible donation.
      They measure 6” x 4” and are printed on luxe 32 pt paper with a black seam. 
      Choose from a range of causes including planting a tree in someone’s honor, to providing a meal to an American child in need.</p>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(DonateTitle);
