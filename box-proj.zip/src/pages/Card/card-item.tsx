import * as React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import { Image } from '../../components/Image';
import { ReactComponent as CheckIcon } from '../../assets/images/ic_check.svg';
import css from './card.module.scss';

/**
 * CardItem component props interface
 */
interface ICardItemProps {
  active: boolean;
  title: string;
  note: string;
  image: string;
  onSelectCard: () => void;
}

/**
 * CardItem component
 */
const CardItem: React.FunctionComponent<ICardItemProps> = props => {
  const { active, title, note, image, onSelectCard } = props;
  return (
    <div className={cn(css.card_item, active ? css.active : '')}>
      <Image alt='Card item image' src={image} className={css.card_item_image} onClick={() => onSelectCard()} />
      <CheckIcon className={css.card_item_check_icon} />
      <h4 className={css.card_item_title}>{title}</h4>
      <h6 className={css.card_item_note}>{note}</h6>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(CardItem);
