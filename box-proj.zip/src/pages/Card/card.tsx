import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './card.module.scss';
import CardTitle from './card-title';
import CardContent from './card-content';
import DonateTitle from './donate-title';
import DonateContent from './donate-content';

/**
 * Home component props interface
 */
interface ICardProps {
  auth: AuthState;
}

/**
 * Card component
 */
const Card: React.FunctionComponent<ICardProps> = props => {
  const [activePage, setActivePage] = React.useState<string>('card');
  return (
    <div>
    { activePage === 'card' && 
    <div>
      <CardTitle />
      <CardContent onClick={() => setActivePage('donate')} />
    </div>
    }
    { activePage === 'donate' && 
    <div>
      <DonateTitle />
      <DonateContent />
    </div>
    }
    </div>
    
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(Card);
