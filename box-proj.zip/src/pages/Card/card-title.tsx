import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './card.module.scss';

/**
 * CardTitle component props interface
 */
interface ICardTitleProps {
  auth: AuthState;
}

/**
 * CardTitle component
 */
const CardTitle: React.FunctionComponent<ICardTitleProps> = props => {
  return (
    <div className={css.card_title_area}>
      <h3 className={css.page_title}>CHOOSE <i>your</i> COLLATERAL</h3>
      <p className={css.page_note}>Want thoughtful branding?<br/> Ship us your own branded card and/or sticker, or let us design and print them for you.</p>
      <p className={css.page_note}>Our stickers and cards are printed at the our print shop operated by Goodwill Southern California (so they do good, too!)</p>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(CardTitle);
