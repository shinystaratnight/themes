import * as React from 'react';
import { connect } from 'react-redux';

import { IState, LocalState } from '../../reducers';
import css from './card.module.scss';
import CardItem from './card-item';
import { Button, Link } from '../../uikit';
import { Checkbox } from '../../uikit/Checkbox';
import { ReactComponent as DownloadIcon } from '../../assets/images/ic_download.svg';
import { CardData } from '../../dummy/data';
import {chooseCard} from "../../actions";

/**
 * CardContent component props interface
 */
interface ICardContentProps {
  localData: LocalState;
  chooseCard: typeof chooseCard;
  onClick: () => void;
}

/**
 * CardContent component
 */
const CardContent: React.FunctionComponent<ICardContentProps> = props => {

  const { localData, chooseCard } = props;
  const [checked, setChecked] = React.useState<boolean>(false);
  
  return (
    <div className={css.card_content_area}>
      <div className={css.card_item_row}>
          {
              CardData.map((item, index) => {
                  return (
                      <CardItem key={'card-item-' + index} active={ localData.card.id === item.id } title={item['title']}
                                note={'Starting at ' + item['min_unit'] + ' ' + item['unit_symbol'] + ' ($' + item['price'] + ' each)'}
                                image={item['image']} onSelectCard={() => { chooseCard({ card: item }); }} />
                  );
              })
          }
      </div>

      <div className={css.checkbox_row}>
        <Checkbox text="Click here if you’d like to ship us your own card and sticker for inclusion in your gift boxes." 
                  checked={checked} onClick={() => setChecked(!checked)} />
        <Link linkStyle="regular" target="_blank" to='#' className={css.download}><DownloadIcon />Download Templates</Link>
      </div>
      
      <Button className={css.button} style="plain" onClick={props.onClick}>
        CONFIRM SELECTION
      </Button>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    localData: state.local
  };
};

const mapDispatchToProps = {
    chooseCard
}

export default connect(mapStateToProps, mapDispatchToProps)(CardContent);
