import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState, IState } from '../../reducers';
import ShippingDateTitle from './shippingdate-title';
import ShippingDateContent from './shippingdate-content';

/**
 * ShippingDate component props interface
 */
interface IShippingDateProps {
  auth: AuthState;
}

/**
 * ShippingDate component
 */
const ShippingDate: React.FunctionComponent<IShippingDateProps> = props => {
  return (
    <div>
      <ShippingDateTitle />
      <ShippingDateContent />
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ShippingDate);
