import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState, IState } from '../../reducers';
import css from './shippingdate.module.scss';

/**
 * ShippingDateTitle component props interface
 */
interface IShippingDateTitleProps {
  auth: AuthState;
}

/**
 * ShippingDateTitle component
 */
const ShippingDateTitle: React.FunctionComponent<IShippingDateTitleProps> = props => {
  return (
    <div className={css.shipping_title_area}>
      <h3 className={css.page_title}>Please input Shipping Date</h3>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ShippingDateTitle);
