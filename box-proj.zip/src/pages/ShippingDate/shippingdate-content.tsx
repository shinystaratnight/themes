import * as React from 'react';
import { connect } from 'react-redux';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import moment from "moment";

import {AuthState, IState, LocalState} from '../../reducers';
import css from './shippingdate.module.scss';
import { Button } from '../../uikit';
import {clearData, setShippingDate, setStep} from '../../actions';

/**
 * ShippingDateContent component props interface
 */
interface IShippingDateContentProps {
  localData: LocalState;
  setStep: typeof setStep;
  clearData: typeof clearData;
  setShippingDate: typeof setShippingDate;
}

/**
 * ShippingDateContent component
 */
class ShippingDateContent extends React.Component<IShippingDateContentProps> {
  state = {
    // date: moment(this.props.localData.shippingDate).toDate()
    date: new Date()
  }

  onChange = (date: any) => this.setState({ date })

  render() {
    const chosenDate = this.state.date;
    return (
      <div className={css.shipping_content_area}>
        <div className={css.main_content}>
          <div className={css.shipping_input_section}>
            <div className={css.row}>
              <form>
                <div className={css.input}>
                  <input type="text" value={moment(chosenDate).format('dddd DD MMMM yyyy')} readOnly />
                </div>

                <Calendar
                  onChange={this.onChange}
                  value={this.state.date}
                />
              </form>
            </div>
            <div className={css.row}>
              <Button className={css.button} style="plain" onClick={() => {
                this.props.setShippingDate({ date: moment(this.state.date).format('MM/DD/yyyy') })
                this.props.clearData({});
                this.props.setStep({ step: 'step6' });
              }}>
                CONFIRM
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state: IState) => {
  return {
    localData: state.local
  };
};

const mapDispatchToProps = {
  clearData,
  setStep,
  setShippingDate
}

export default connect(mapStateToProps, mapDispatchToProps)(ShippingDateContent);
