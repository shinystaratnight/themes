import * as React from 'react';
import Dropdown from 'react-dropdown'
import 'react-dropdown/style.css'
import css from './items.module.scss';

/**
 * FilterItem component props interface
 */
interface IFilterItemProps {
  options: any[];
  placeholder: string;
  selectedValue: any;
  onChange: (value: any) => void;
}

/**
 * FilterItem component
 */
const FilterItem: React.FunctionComponent<IFilterItemProps> = props => {
  const { options, placeholder, selectedValue, onChange } = props;
  return (
    <Dropdown options={options} onChange={onChange} value={selectedValue} placeholder={placeholder}
                    className={css.filter_dropdown} arrowClassName={css['Dropdown-arrow']}
                    controlClassName={css['Dropdown-control']} placeholderClassName={css['Dropdown-placeholder']}
                    menuClassName={css['Dropdown-menu']} />
  );
};

export default FilterItem;
