import * as React from 'react';
import { connect } from 'react-redux';

import { IState } from '../../reducers';
import { Image } from '../../components/Image';
import { ReactComponent as RemoveIcon } from '../../assets/images/ic_remove.svg';
import css from './items.module.scss';
import { Product } from '../../types/product';

/**
 * ProductImageItem component props interface
 */
interface IProductImageItemProps {
  image: string;
  showRemove?: boolean;
  product?: Product;
  onRemove: (product: Product) => void;
}

/**
 * ProductImageItem component
 */
const ProductImageItem: React.FunctionComponent<IProductImageItemProps> =
  ({ image, product = null, showRemove = true, onRemove }) => {
    return (
      <div className={css.prod_image_item}>
        <Image alt='Product image' className={css.prod_image} src={image} />
        {
          showRemove && product && <RemoveIcon onClick={() => onRemove(product)} />
        }
      </div>
    );
  };

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ProductImageItem);
