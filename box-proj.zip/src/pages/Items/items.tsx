import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './packaging.module.scss';
import ItemsTitle from './items-title';
import ItemsContent from './items-content';

/**
 * Items component props interface
 */
interface IItemsProps {
  auth: AuthState;
}

/**
 * Items component
 */
const Items: React.FunctionComponent<IItemsProps> = props => {
  return (
    <div>
      <ItemsTitle />
      <ItemsContent />
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(Items);
