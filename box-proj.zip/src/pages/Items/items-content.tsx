import * as React from 'react';
import { connect } from 'react-redux';
import cn from 'classnames';
import NotificationAlert from 'react-notification-alert';

import 'bootstrap/dist/css/bootstrap.css';
import "react-notification-alert/dist/animate.css";

import { IState, LocalState } from '../../reducers';
import ProductItem from './prod-item';
import ProductImageItem from './prod-image-item';

import css from './items.module.scss';
import { Button } from '../../uikit';
import { Checkbox } from '../../uikit/Checkbox';
import { addProductToBox, removeProductFromBox, setBoxSize, setStep } from '../../actions';
import { BoxSizeData, CollectionData, ColorOptions, SortOptions } from '../../dummy/data';
import FilterItem from './sort-item';
import { localapi } from '../../services';
import { Product } from '../../types/product';

/**
 * ItemsContent component props interface
 */
interface IItemsContentProps {
  localState: LocalState;
  setStep: typeof setStep;
  addToBox: typeof addProductToBox;
  removeFromBox: typeof removeProductFromBox;
  setBoxSize: typeof setBoxSize;
}

/**
 * ItemsContent component
 */
const ItemsContent: React.FunctionComponent<IItemsContentProps> = props => {

  const { localState, addToBox, removeFromBox, setBoxSize, setStep } = props;

  // Collection filter optiions
  const collectionOptions = CollectionData.map(collection => {
    return { value: collection['collection_id'], label: collection['title'] };
  });

  const [collectionOption, setCollectionOption] = React.useState<{ value: string, label: string }>(collectionOptions[0]);
  const [colorOption, setColorOption] = React.useState<{ value: string, label: string }>(ColorOptions[0]);
  const [sortOption, setSortOption] = React.useState<{ value: string, label: string }>(SortOptions[0]);

  const [filteredProducts, setFilteredProducts] =
    React.useState<Product[]>(localapi.filterProducts(collectionOption.value, colorOption.value, sortOption.value, 0, 20));

  // Calculate sub total prices
  let subTotal = 0.0;
  for (const i in localState.cart) {
    subTotal += localState.cart[i].product.price * localState.cart[i].count;
  }

  // Notification bar variables
  const notificationRef = React.useRef();
  const notificationOptions = {
      place: 'tc',
      message: (
          <div>New product has been added to the box.</div>
      ),
      type: "success",
      icon: "now-ui-icons ui-1_bell-53",
      autoDismiss: 7,
  }

  const summary_section =
    (
      <div className={css.box_summary_section}>
        <span className={css.summary_title}>Your Box Summary</span>
        <div className={css.summary_content}>
          <div className={css.box_summary}>
            <div className={css.prod_images}>
              <ProductImageItem image={localState.box.images[0]} showRemove={false} onRemove={() => { }} />
              {
                localState.cart.map((cartItem, index) =>
                  <ProductImageItem key={index} product={cartItem.product} image={cartItem.product.prod_image}
                    onRemove={(product) => {
                        removeFromBox({ product })
                    }} />
                )
              }
            </div>
            <div className={css.check_row}>
              <span className={css.check_label}>Box Size: </span>
              {
                BoxSizeData.map((size, index) =>
                  <Checkbox key={index} text={size} className={css.check} checked={localState.boxSize === size} onClick={() => setBoxSize({ size })} />
                )
              }
            </div>
            <div className={css.check_note}>
              The size is selected automatically depending on the amount of selected gifts.
          </div>
          </div>
          <div className={css.prod_summary}>
            <div className={css.prod_list}>
              {
                localState.cart.map((cartItem, index) => {
                  return (
                    <div key={index} className={css.prod_item}>
                      <span className={css.prod_quantity}>{cartItem.count}</span>
                      <span className={css.prod_title}>{cartItem.product.title}</span>
                      <span className={css.prod_price}>$ {cartItem.product.price}</span>
                    </div>
                  );
                })
              }
              <div className={css.subtotal_item}>
                <span className={css.subtotal_label}>Box Subtotal:</span>
                <span className={css.subtotal_price}>$ {subTotal}</span>
              </div>
            </div>
            <Button className={cn(css.button)} style="plain" onClick={() => { setStep({ step: 'step3' }) }}>COMPLETE THE BOX</Button>
          </div>
        </div>
      </div>
    );

  return (
    <div className={css.items_content_area}>
      <div className={css.show_on_desktop}>{summary_section}</div>
      <div className={css.filter_section}>
        <span className={css.filter_title}>CLASSIFY THE GOODS</span>
        <div className={css.filter_row}>
          <FilterItem selectedValue={collectionOption} options={collectionOptions} placeholder="Select Collection"
            onChange={(value) => {
              setCollectionOption(value);
              setFilteredProducts(localapi.filterProducts(value.value, colorOption.value, sortOption.value, 0, 20));
            }} />
          {/*<FilterItem selectedValue={colorOption} options={ColorOptions} placeholder="Color"*/}
          {/*  onChange={(value) => {*/}
          {/*    setColorOption(value);*/}
          {/*    setFilteredProducts(localapi.filterProducts(collectionOption.value, value.value, sortOption.value, 0, 20));*/}
          {/*  }} />*/}
          <FilterItem selectedValue={sortOption} options={SortOptions} placeholder="Sort by Options"
            onChange={(value) => {
              setSortOption(value);
              setFilteredProducts(localapi.filterProducts(collectionOption.value, colorOption.value, value.value, 0, 20));
            }} />
        </div>
      </div>

      <NotificationAlert ref={notificationRef} />

      <div className={css.prod_items_section}>
        {filteredProducts.map((product, index) => {
          return <ProductItem key={index} product={product} onAddToBox={(product) => {
              // @ts-ignore
              notificationRef.current.notificationAlert(notificationOptions);
              addToBox({ product });
          }} />
        })}
      </div>
      <Button className={cn(css.button, css.show_more)} style="plain" onClick={() => { }}>SHOW MORE</Button>

      <div className={css.show_on_mobile}>{summary_section}</div>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    localState: state.local
  };
};

const mapDispatchToProps = {
  setStep,
  addToBox: addProductToBox,
  removeFromBox: removeProductFromBox,
  setBoxSize,
}

export default connect(mapStateToProps, mapDispatchToProps)(ItemsContent);
