import * as React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';

import { IState } from '../../reducers';
import { Image } from '../../components/Image';
import css from './items.module.scss';
import { Button } from '../../uikit';
import { Product } from '../../types/product';
import Modal from "react-modal";

/**
 * ProductItem component props interface
 */
interface IProductItemProps {
  product: Product;
  onAddToBox: (product: Product) => void;
}

const customStyles = {
  content : {
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)'
  }
};

/**
 * ProductItem component
 */
const ProductItem: React.FunctionComponent<IProductItemProps> = props => {
  const { product, onAddToBox } = props;
  const [show, setShow] = React.useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <div className={css.prod_item}>
        <div className={css.inner}>
          <div className={css.prod_image_section}>
            <Image alt='Prod item image' src={product.prod_image} className={css.prod_item_image} />
            <div className={css.mask}>
              <Button className={cn(css.button, css.border_button)} style="plain" onClick={ handleShow }>QUICK VIEW</Button>
            </div>
          </div>

          <div className={css.prod_info_section}>
            <h4 className={css.prod_item_title}>{product.title}</h4>
            <div className={css.prod_item_note}>
              <Image alt='Brand image' src={product.brand_image} className={css.brand_item_image} />
              <h6 style={{marginBottom: 0}}>{product.short_desc}</h6>
            </div>
            <Button className={css.button} style="plain" onClick={() => { onAddToBox(product) }}>ADD TO BOX</Button>
          </div>
        </div>
      </div>


      <Modal
          isOpen={show}
          onRequestClose={handleClose}
          style={customStyles}
          contentLabel="Example Modal"
      >
        <div className={css.modal_inner}>
          <button className={css.modal_close_btn} onClick={handleClose}>&times;</button>
          <div className={css.prod_image_section}>
            <Image alt='Prod item image' src={product.prod_image} className={css.prod_item_image} />
          </div>
          <div className={css.prod_info_section}>
            <h2 className={css.prod_title}>{product.title}</h2>
            <div className={css.prod_item_note}>
              <Image alt='Brand image' src={product.brand_image} className={css.brand_item_image} />
              <h6 style={{marginBottom: 0}}>{product.short_desc}</h6>
            </div>
            <p>
              These bath bombs from Old Whaling Co. are carefully mixed in-house by hand. They are loaded with epsom salts and oils for a lovely, relaxing soak that will cleanse, moisturize and refresh. They fizz + color the bath water. Great for everyone of all ages! Made specifically for one bath. Caution: oils will make tub slippery. Wipe out tub after use for easiest cleanup.
            </p>
            <p>
              The Oatmeal Milk + Honey fragrance is warm and almondy. Made with oats, the bath bomb is perfect for a soothing and relaxing bath.
            </p>
          </div>
        </div>
      </Modal>
    </>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ProductItem);
