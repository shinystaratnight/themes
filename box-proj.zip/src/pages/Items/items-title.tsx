import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './items.module.scss';

/**
 * ItemsTitle component props interface
 */
interface IItemsTitleProps {
  auth: AuthState;
}

/**
 * ItemsTitle component
 */
const ItemsTitle: React.FunctionComponent<IItemsTitleProps> = props => {
  return (
    <div className={css.items_title_area}>
      <h3 className={css.page_title}>CHOOSE <i>your</i> ITEMS</h3>
      <p className={css.page_note}>We’ve curated a list of premium goods that help people and the planet. 
      Select from the items below and fill up your box.</p> 
      <p className={css.page_note}>Each gift box will come with a story card explaining the charitable cause behind the products.</p>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(ItemsTitle);
