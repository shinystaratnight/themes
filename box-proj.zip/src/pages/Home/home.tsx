import * as React from 'react';
import { connect } from 'react-redux';

import { IState } from '../../reducers';
import { Header } from '../../components/Header';
import { Footer } from '../../components/Footer';
import { StepBar } from '../../components/StepBar';
import { Packaging } from '../Packaging';
import { Items } from '../Items';
import { Card } from '../Card';
import { Information } from '../Information';
import { ShippingDate } from '../ShippingDate';
import { Thanks } from '../Thanks';

/**
 * Home component props interface
 */
interface IHomeProps {
  step?: string;
}

/**
 * Home component
 * redirect user to specified for user type page
 */
const Home: React.FunctionComponent<IHomeProps> = props => {
  const { step } = props;

  return (
    <div>
      <Header step={props.step} />
      { step !== 'step6' && <StepBar /> }
      { step === 'step1' && <Packaging /> }
      { step === 'step2' && <Items /> }
      { step === 'step3' && <Card /> }
      { step === 'step4' && <Information /> }
      { step === 'step5' && <ShippingDate /> }
      { step === 'step6' && <Thanks /> }
      <Footer />
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    step: state.local.step
  };
};

export default connect(mapStateToProps)(Home);
