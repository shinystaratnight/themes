import * as React from 'react';
import { connect } from 'react-redux';

import { AuthState } from '../../reducers/auth.reducer';
import { IState } from '../../reducers';
import css from './packaging.module.scss';
import PackagingTitle from './packaging-title';
import PackagingContent from './packaging-content';

/**
 * Home component props interface
 */
interface IPackagingProps {
  auth: AuthState;
}

/**
 * Packaging component
 * redirect to specified step page
 */
const Packaging: React.FunctionComponent<IPackagingProps> = props => {
  return (
    <div>
      <PackagingTitle />
      <PackagingContent />
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(Packaging);
