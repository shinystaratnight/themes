import * as React from 'react';
import cn from 'classnames';
import { connect } from 'react-redux';

import { IState, LocalState } from '../../reducers';
import css from './packaging.module.scss';
import { Button } from '../../uikit';
import BoxItem from './box-item';
import { chooseBox, setStep } from '../../actions';
import { BoxData } from '../../dummy/data';

/**
 * PackagingContent component props interface
 */
interface IPackagingContentProps {
  localData: LocalState;
  setStep: typeof setStep;
  chooseBox: typeof chooseBox;
}

/**
 * PackagingContent component
 */
const PackagingContent: React.FunctionComponent<IPackagingContentProps> = props => {

  return (
    <div className={css.packaging_content_area}>
      <div className={css.box_item_row}>
        {
          BoxData.map((item_data, index) => {
            return <BoxItem key={index} chosen={ props.localData.box.id === item_data.id } title={item_data['title']}
              note={'(Starting at ' + item_data['min_unit'] + ' units)'}
              images={item_data['images']} onSelectBox={() => props.chooseBox({ box: item_data })} />
          })
        }
      </div>
      <Button className={css.button} style="plain" onClick={() => props.setStep({ step: 'step2' })}>
        CONFIRM SELECTION
      </Button>
    </div>
  );
};

const mapStateToProps = (state: IState) => {
  return {
    localData: state.local
  };
};

const mapDispatchToProps = {
  setStep,
  chooseBox
};

export default connect(mapStateToProps, mapDispatchToProps)(PackagingContent);
