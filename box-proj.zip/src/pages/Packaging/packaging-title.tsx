import * as React from 'react';
import {connect} from 'react-redux';

import {AuthState, IState} from '../../reducers';
import css from './packaging.module.scss';

/**
 * PackagingTitle component props interface
 */
interface IPackagingTitleProps {
    auth: AuthState;
}

/**
 * PackagingTitle component
 */
const PackagingTitle: React.FunctionComponent<IPackagingTitleProps> = props => {
    return (
        <div className={css.packaging_title_area}>
            <h3 className={css.page_title}>CHOOSE <i>your</i> BOX TYPE</h3>
            <p className={css.page_note}>For orders of <strong>25 units or more</strong>, you can send a meaningful
                custom gift box in 3 simple steps.</p>
            <p className={css.page_note}>Our gift boxes are handmade by artisans in India from repurposed organic cotton
                t-shirts
                and assembled by individuals with disabilities at Goodwill Southern California.</p>
        </div>
    );
};

const mapStateToProps = (state: IState) => {
    return {
        auth: state.auth
    };
};

export default connect(mapStateToProps)(PackagingTitle);
