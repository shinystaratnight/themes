import * as React from 'react';
import cn from 'classnames';
import {connect} from 'react-redux';
import {Fade, Slide} from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'

import {IState} from '../../reducers';
import {Image} from '../../components/Image';
import {ReactComponent as CheckIcon} from '../../assets/images/ic_check.svg';
import css from './packaging.module.scss';

/**
 * BoxItem component props interface
 */
interface IBoxItemProps {
    chosen: boolean;
    title: string;
    note: string;
    images: string[];
    onSelectBox: () => void;
}

/**
 * BoxItem component
 */
const BoxItem: React.FunctionComponent<IBoxItemProps> = props => {
    const {chosen, title, note, images, onSelectBox} = props;
    const slideRef = React.useRef();

    const back = () => {
        // @ts-ignore
        slideRef.current.goBack();
    }

    const next = () => {
        // @ts-ignore
        slideRef.current.goNext();
    }

    return (
        <div className={cn(css.box_item, chosen ? css.active : '')}>
            {/*<Image alt='Box item image' src={image} onClick={() => onSelectBox()} />*/}
            <div className="slide-container" onClick={() => onSelectBox()}>
                <Slide ref={slideRef} autoplay={false} indicators={true} arrows={false} transitionDuration="300">
                    {
                        images.map((image, index) => {
                            return (
                                <div key={'carousel-' + index} className="each-slide">
                                    <div style={{'backgroundImage': `url(${image})`}} className={css.box_item_image}>
                                    </div>
                                </div>
                            );
                        })
                    }
                </Slide>
            </div>
            <div className={css.carousel_btn_section}>
                <button className={cn(css.carousel_btn, css.prev_btn)} onClick={back}>
                    <svg width="14" height="14" viewBox="0 0 24 24">
                        <path d="M16.67 0l2.83 2.829-9.339 9.175 9.339 9.167-2.83 2.829-12.17-11.996z"></path>
                    </svg>
                </button>
                <button className={cn(css.carousel_btn, css.next_btn)} onClick={next}>
                    <svg width="14" height="14" viewBox="0 0 24 24">
                        <path d="M5 3l3.057-3 11.943 12-11.943 12-3.057-3 9-9z"></path>
                    </svg>
                </button>
            </div>
            <CheckIcon className={css.box_item_check_icon}/>
            <h4 className={css.box_item_title}>{title}</h4>
            <h6 className={css.box_item_note}>{note}</h6>
        </div>
    );
};

const mapStateToProps = (state: IState) => {
    return {
        auth: state.auth
    };
};

export default connect(mapStateToProps)(BoxItem);
