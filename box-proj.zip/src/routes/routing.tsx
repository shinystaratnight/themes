import * as React from 'react';

import { Route, Switch } from 'react-router';
import { routes } from './routes';

import Home from '../pages/Home/home';
import NoMatch from '../pages/NoMatch';

export { routes } from './routes';

export const full_routing = (
  <Switch>
    <Route exact path={routes.home()} component={Home} />
    
    <Route render={() => <NoMatch />} />
  </Switch>
);

export const routing = full_routing;
