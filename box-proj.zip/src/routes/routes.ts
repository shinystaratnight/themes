export const routes = {
  home: () => "/",
  login: () => "/login",
  signUp: () => "/sign-up",
};
