import { Redirect, Route, RouteProps } from 'react-router-dom';

import { AuthState } from '../reducers/auth.reducer';
import { IState } from '../reducers';
import React from 'react';
import { connect } from 'react-redux';
import { isLimited } from '../utils/isProd';
import { routes } from './routes';

interface IPrivateRouteOwnProps {
  component?: any;
}

interface IPrivateRouteStoreProps {
  auth: AuthState;
}

type IPrivateRouteProps = RouteProps &
  IPrivateRouteOwnProps &
  IPrivateRouteStoreProps;

class PrivateRoute<
  T extends IPrivateRouteProps = IPrivateRouteProps
  > extends React.Component<T, any> {
  render() {
    const { auth, component: Component, ...rest } = this.props;

    return (
      <Route
        {...rest}
        render={props =>
          !!auth.profile ? (
            <Redirect to={routes.login()} />
          ) : (
              <Redirect to={routes.login()} />
            )
        }
      />
    );
  }
}

const mapStateToProps = (state: IState) => {
  return {
    auth: state.auth
  };
};

export default connect(mapStateToProps)(PrivateRoute);
