import React, { useState } from 'react';

import { Omit } from '../../utils/types';
import cn from 'classnames';
import css from './Highlightable.module.scss';

/**
 * Interface for highlitable element properties
 * @extends React.HTMLAttributes
 * @callback toggleHover
 * @callback togglePressed
 */
interface HighlightableProps extends React.HTMLAttributes<HTMLSpanElement> {
  children: any;
  hover?: boolean;
  cssHover?: boolean;
  pressed?: boolean;
  toggleHover?: (hover: boolean) => void;
  togglePressed?: (pressed: boolean) => void;
  classNameMix?: string;
}

/**
 * Component for highlitable element
 */
export const Highlightable: React.FunctionComponent<HighlightableProps> = ({
  children,
  hover,
  pressed,
  toggleHover,
  togglePressed,
  classNameMix,
  cssHover,
  ...rest
}) => (
    <span
      {...rest}
      onMouseEnter={() => toggleHover && toggleHover(true)}
      onMouseLeave={() => toggleHover && toggleHover(false)}
      onMouseDown={() => togglePressed && togglePressed(true)}
      onMouseUp={() => togglePressed && togglePressed(false)}
      className={cn(
        css.highlightable,
        {
          [css.hover]: hover,
          [css.pressed]: pressed,
          [css.cssHover]: cssHover
        },
        classNameMix
      )}
    >
      <span className={css.text}>{children}</span>
    </span>
  );

/**
 * Type for highlitable element with hover properties
 */
type HighlightableWithHoverProps = Omit<
  HighlightableProps,
  'hover' | 'toggleHover'
>;

/**
 * Component for highlitable element with hover
 */
export const HighlightableWithHover: React.FunctionComponent<
  HighlightableWithHoverProps
> = props => {
  const [hover, setHover] = useState(false);
  return <Highlightable hover={hover} toggleHover={setHover} {...props} />;
};
