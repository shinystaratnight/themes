import * as React from 'react';
import * as css from './logo.module.scss';

import { Link } from 'react-router-dom';
import cn from 'classnames';
import { routes } from '../../routes';
// import { ReactComponent as logo } from '../../assets/images/logo.gif';

/**
 * Type for available size
 */
type AvailableLogoSize = '190' | '215' | '270' | '280' | '313';

/**
 * Interface for logo properties
 */
interface ILogoProps {
  className?: string;
  size: AvailableLogoSize;
}

/**
 * Function to set logo url
 */
function logoUrl(suffix: string): string {
  return process.env.REACT_APP_PUBLIC_URL + `/assets/images/ic_gift_logo_${suffix}.png`;
}

function gifLogoUrl(): string {
  return process.env.REACT_APP_PUBLIC_URL + `/assets/images/logo.gif`;
}

/**
 * Component for logo
 */
export const Logo: React.FunctionComponent<ILogoProps> = ({
  className,
  size
}) => (
    // <Link to={routes.profile()}>
    <a href={process.env.REACT_APP_SITE_URL}>
      <img
        className={cn(css.logo, className)}
        alt="Box logo"
        src={logoUrl('md')}
        width={size}
      />
    </a>
    //</Link>
  );
