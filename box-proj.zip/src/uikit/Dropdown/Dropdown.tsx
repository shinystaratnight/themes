import * as React from 'react';

import cn from 'classnames';
import css from './Dropdown.module.scss';
import useOnClickOutside from 'use-onclickoutside';

/**
 * Interface for dropdown item properties
 * @callback action
 */
export interface DropdownItem {
  id: string;
  title: string;
  action: (data?: any) => void;
}

/**
 * Interface for dropdown properties
 * @callback action
 */
interface DropdownProps {
  items: DropdownItem[];
  contentPosition?: 'center' | 'end' | 'top';
  data?: any;
  className?: string;
  children: ({ isOpen }: { isOpen: boolean }) => React.ReactNode;
}

/**
 * Component for dropdown
 */
const Dropdown: React.FunctionComponent<DropdownProps> = React.memo(props => {
  const { items, contentPosition, data, children, className } = props;
  const [isOpen, toogle] = React.useState(false);
  const ref = React.useRef(null);
  const open = () => toogle(true);
  const close = () => toogle(false);

  /**
   * Function to handle user click
   * @event MouseEvent
   */
  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    event.stopPropagation();

    if (isOpen) {
      close();
    } else {
      open();
    }
  };

  useOnClickOutside(ref, close);

  const dropdownClassName = cn(css.dropdown, {
    [css.isOpen]: isOpen,
    [contentPosition && css[contentPosition]]: contentPosition
  }, 'dropdown');

  return (
    <div className={cn(css.dropdownWrapper, className, 'dropdown-wrapper')} ref={ref}>
      <div className={css.content} onClick={handleClick}>
        {children({ isOpen })}
      </div>
      <div className={dropdownClassName}>
        <div className={cn(css.dropdownInner, 'dropdown-inner')}>
          {items.map(item => {
            const handleClick = (event: React.MouseEvent<HTMLElement>) => {
              event.stopPropagation();
              item.action(data);
              close();
            };
            return (
              <div className={css.item} key={item.id} onClick={handleClick}>
                {item.title}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
});

export default Dropdown;
