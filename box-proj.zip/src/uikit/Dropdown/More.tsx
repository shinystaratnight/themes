import * as React from 'react';

import Dropdown, { DropdownItem } from './Dropdown';

import { ReactComponent as MoreIcon } from '../../assets/images/ic_more.svg';
import cn from 'classnames';
import css from './More.module.scss';

/**
 * Interface for more element properties
 */
interface MoreProps {
  className?: string;
  items: DropdownItem[];
  data?: any;
  theme?: 'dark' | 'light';
}

/**
 * Component for more element
 */
const More: React.FunctionComponent<MoreProps> = React.memo(
  ({ data, items, className, theme }) => {
    return (
      <Dropdown
        items={items}
        contentPosition="end"
        data={data}
        className={className}
      >
        {({ isOpen }) => (
          <div className={css.more}>
            <div
              className={cn(css.dots, theme && css[theme], {
                [css.isOpen]: isOpen
              })}
            >
              <MoreIcon />
            </div>
          </div>
        )}
      </Dropdown>
    );
  }
);

export default More;
