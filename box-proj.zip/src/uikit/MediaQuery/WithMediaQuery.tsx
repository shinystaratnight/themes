import { Omit } from '../../utils/types';
import React from 'react';

export type MediaType = 'phone' | 'tablet' | 'desktop';

/**
 * Interface for with media query properties
 */
export interface WithMediaQueryProps {
  media: MediaType;
}

/**
 * Component for with media query
 */
export function withMediaQuery<P extends WithMediaQueryProps>(
  Component: React.ComponentType<P>
): React.ComponentClass<Omit<P, keyof WithMediaQueryProps>> {
  return class extends React.Component<Omit<P, keyof WithMediaQueryProps>> {
    state: {
      media: MediaType;
    } = {
      media: 'desktop'
    };

    //
    // Warning for maintainers: Keep in sync with _media.scss
    //
    queryPhone = window.matchMedia('(max-width: 767px)');
    queryTablet = window.matchMedia(
      '(min-width: 768px) and (max-width: 1022px)'
    );
    queryDesktop = window.matchMedia('(min-width: 1023px)');

    /**
     * Function to subscribe to changes media query
     */
    subscribeMediaChanges() {
      this.queryPhone.addListener(this.handleChange);
      this.queryTablet.addListener(this.handleChange);
      this.queryDesktop.addListener(this.handleChange);
      this.handleChange();
    }

    /**
     * Function to unsubscribe to changes media query
     */
    unsubscribeMediaChanges() {
      this.queryPhone.removeListener(this.handleChange);
      this.queryTablet.removeListener(this.handleChange);
      this.queryDesktop.removeListener(this.handleChange);
    }

    componentDidMount() {
      this.subscribeMediaChanges();
    }

    componentWillUnmount() {
      this.unsubscribeMediaChanges();
    }

    /**
     * Function to handle changes query
     */
    handleChange = () => {
      const media = this.queryPhone.matches
        ? 'phone'
        : this.queryTablet.matches
        ? 'tablet'
        : 'desktop';
      this.setState({
        media
      });
    };

    render() {
      // Sometimes, TS sux
      const UntypeComponent = Component as any;
      return <UntypeComponent media={this.state.media} {...this.props} />;
    }
  };
}
