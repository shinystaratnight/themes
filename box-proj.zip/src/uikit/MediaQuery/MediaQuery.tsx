import React from 'react';
import cn from 'classnames';
import css from './MediaQuery.module.scss';

/**
 * Interface for media query properties
 */
interface MediaQueryProps {
  query:
    | 'mobile'
    | 'tablet'
    | 'desktop'
    | 'mobileAndTablet'
    | 'tabletAndDesktop'
    | 'mobileAndDesktop'
    | 'fromMobileToSmallDesktop'
    | 'largeDesktop'
    | 'followersPopupSmallestResolution';
  block?: boolean;
  className?: string;
  children: any;
}

/**
 * Component for media query
 */
export function MediaQuery(props: MediaQueryProps) {
  const { query, block, className, children } = props;
  const mediaClass = cn(className, css[query]);
  return block ? (
    <div className={mediaClass}>{children}</div>
  ) : (
    <span className={mediaClass}>{children}</span>
  );
}
