import * as React from 'react';
import * as css from './BaseField.module.scss';

import { FieldRenderProps } from 'react-final-form';
import { ReactComponent as IconRemove } from '../../assets/images/ic_close.svg';
import cn from 'classnames';

/**
 * base field component through which the other fields will be rendered
 */

interface IBaseFieldProps extends FieldRenderProps<HTMLInputElement> {
  label?: string | JSX.Element;
  className?: string;
  description?: string;
  note?: string;
  help?: string;
  topHelp?: string;
  type?: string;
  renderField: (hasError?: boolean) => any;
  requiredmark?: boolean;
  onRemove?: () => void;
}

const BaseField: React.FunctionComponent<IBaseFieldProps> = props => {
  const {
    meta: { error, submitError, touched, dirtySinceLastSubmit },
    label,
    className,
    description,
    note,
    help,
    topHelp,
    renderField,
    requiredmark,
    onRemove
  } = props;

  const hasError =
    (error && touched) || (!dirtySinceLastSubmit && submitError && touched);

  return (
    <div className={className}>
      <div className={css.header}>
        {label && (
          <label className={cn(css.label, requiredmark && css.requiredmark)}>
            {label}
          </label>
        )}
        {description && <p className={css.description}>{description}</p>}
        {note && <p className={css.note}>{note}</p>}
        {topHelp && <p className={css.help} >{topHelp}</p>}
      </div>
      <div className={css.control}>
        {renderField(hasError)}
        {onRemove && (
          <div className={css.remove} onClick={onRemove}>
            <IconRemove />
          </div>
        )}
      </div>
      {hasError && <p className={css.error}>{error || submitError}</p>}
      {help && !hasError && <p className={css.help}>{help}</p>}
    </div>
  );
};

export default BaseField;
