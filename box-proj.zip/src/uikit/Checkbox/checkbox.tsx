import * as React from 'react';

import cn from 'classnames';
import css from './checkbox.module.scss';

/**
 * Interface for checkbox properties
 */
interface ICheckboxProps {
  className?: string;
  checked?: boolean;
  text?: string;
  [otherProp: string]: any;
  onClick: () => void;
}

/**
 * Component for checkbox
 */
const Checkbox = (props: ICheckboxProps) => {
  const { className, checked, text, onClick, ...rest } = props;
  
  return (
    <div className={cn(css.checkbox, className, checked && css.checked)} onClick={onClick}>
      <input type="checkbox" checked={checked} {...rest} readOnly />
      <span className={css.text}>{text}</span>
    </div>
  );
};

export default Checkbox;
