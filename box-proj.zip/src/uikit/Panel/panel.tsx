import * as React from 'react';
import * as css from './panel.module.scss';

import cn from 'classnames';

/**
 * Interface for panel properties
 */
interface IPanelProps {
  children: any;
  className?: string;
  emptyState?: boolean;
}

/**
 * Component for panel
 */
export const Panel: React.FunctionComponent<IPanelProps> = ({
  children,
  className,
  emptyState
}) => (
  <div
    className={cn(css.panel, className, {
      [css.emptyState]: emptyState
    })}
  >
    {children}
  </div>
);
