import * as React from "react";
import * as css from "./link.module.scss";

import { ReactComponent as Arrow } from "../../assets/images/arrow-right.svg";
import { Highlightable } from "../Highlightable";
import cn from "classnames";

/**
 * Interface for button like properties
 * @callback onClick
 */
interface ILikeLinkProps {
  className?: string;
  linkStyle:
    | "regular"
    | "button-like"
    | "secondary-button-like"
    | "footer-link"
    | "label-link";
  arrow?: boolean;
  arrowBack?: boolean;
  onClick?: () => void;
  highlightableClassNameMix?: string;
  fixPressed?: boolean;
}

/**
 * Component for button like link
 */
export const LikeLink: React.FunctionComponent<ILikeLinkProps> = ({
  className,
  linkStyle,
  children,
  arrow,
  arrowBack,
  onClick,
  highlightableClassNameMix,
  fixPressed
}) => {
  const [hover, setHover] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);

  return (
    <span
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => {
        setHover(false);
        setPressed(false);
      }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      className={cn(className, {
        [css.linkRegular]: linkStyle === "regular",
        [css.linkSecondaryButtonLike]: linkStyle === "secondary-button-like",
        [css.linkButtonLike]: linkStyle === "button-like"
      })}
      onClick={onClick}
    >
      {arrowBack && <Arrow className={css.linkArrowBack} />}
      {(linkStyle === "button-like" || linkStyle === "regular") && (
        <span className={css.title}>{children}</span>
      )}
      {linkStyle === "secondary-button-like" && (
        <Highlightable
          hover={hover}
          pressed={pressed || fixPressed}
          classNameMix={cn(highlightableClassNameMix, css.linkHighlightable)}
        >
          {children}
        </Highlightable>
      )}
      {linkStyle === "footer-link" && (
        <span className={css.linkFooter}>{children}</span>
      )}
      {arrow && <Arrow className={css.linkArrow} />}
    </span>
  );
};
