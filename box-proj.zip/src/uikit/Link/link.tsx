import * as React from 'react';
import * as css from './link.module.scss';

import {
  NavLinkProps,
  NavLink as ReactLink,
  RouteComponentProps
} from 'react-router-dom';

import { ReactComponent as Arrow } from '../../assets/images/arrow-right.svg';
import { Highlightable } from '../Highlightable';
import cn from 'classnames';
import { withRouter } from 'react-router-dom';

// "Exclude" doesn't wotk with "extends" yet. Style renamed to linkStyle
// https://github.com/Microsoft/TypeScript/issues/24791
/**
 * Interface for link properties
 * @extends NavLinkProps
 */
interface ILinkProps extends NavLinkProps {
  className?: string;
  highlightableClassNameMix?: string;
  linkStyle: 'regular' | 'button-like' | 'secondary-button-like' | 'link3' | 'label';
  arrow?: boolean;
}

/**
 * Function to check url string
 */
function isUrl(url: string): boolean {
  return (
    url.startsWith('http://') ||
    url.startsWith('https://') ||
    url.startsWith('mailto:')
  );
}

/**
 * Type outerable link properties
 */
type IOuterableLinkProps = {
  to: string | { [key: string]: any };
  [key: string]: any;
};

/**
 * Component for outerable link
 */
export const OuterableLink = ({ to, ...rest }: IOuterableLinkProps) =>
  typeof to === 'string' && isUrl(to) ? (
    <a href={to} {...rest} />
  ) : (
      <ReactLink to={to} {...rest} />
    );

/**
 * Component for optional outerable link
 */
export const OptionalOuterLink: React.FunctionComponent<
  React.DetailedHTMLProps<
    React.AnchorHTMLAttributes<HTMLAnchorElement>,
    HTMLAnchorElement
  >
> = ({ href, children, ...rest }) =>
    href ? (
      <a href={href} {...rest}>
        {children}
      </a>
    ) : (
        <React.Fragment> {children} </React.Fragment>
      );

/**
 * Component for optional link
 */
export const OptionalLink: React.FunctionComponent<NavLinkProps> = ({
  to,
  children,
  ...rest
}) =>
  to ? (
    <ReactLink to={to} {...rest}>
      {children}
    </ReactLink>
  ) : (
      <React.Fragment> {children} </React.Fragment>
    );

/**
 * Component for link
 */
export const Link = withRouter<ILinkProps & RouteComponentProps, React.ComponentType<ILinkProps & RouteComponentProps>>(
  ({
    history,
    location,
    match,
    staticContext,
    className,
    highlightableClassNameMix,
    linkStyle,
    children,
    arrow,
    ...rest
  }) => {
    const [hover, setHover] = React.useState(false);
    const [pressed, setPressed] = React.useState(false);
    const isLinkActive = match.path === rest.to;
    return (
      <OuterableLink
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => {
          setHover(false);
          setPressed(false);
        }}
        onMouseDown={() => setPressed(true)}
        onMouseUp={() => setPressed(false)}
        className={cn(
          {
            [css.linkRegular]: linkStyle === 'regular',
            [css.linkButtonLike]: linkStyle === 'button-like',
            [css.linkSecondaryButtonLike]:
              linkStyle === 'secondary-button-like',
            [css.link3]: linkStyle === 'link3',
            [css.linkLabel]: linkStyle === 'label',
            [css.withArrow]: arrow
          },
          className
        )}
        {...rest}
      >
        <React.Fragment>
          {(linkStyle === 'button-like' ||
            linkStyle === 'regular' ||
            linkStyle === 'link3' ||
            linkStyle === 'label') && (
              <span className={css.title}>{children}</span>
            )}
          {linkStyle === 'secondary-button-like' && (
            <Highlightable
              hover={hover}
              pressed={pressed || isLinkActive}
              classNameMix={highlightableClassNameMix}
            >
              {children}
            </Highlightable>
          )}
          {arrow && <Arrow className={css.linkArrow} />}
        </React.Fragment>
      </OuterableLink>
    );
  }
);
