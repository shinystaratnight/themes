import * as React from 'react';

import stepCss from './Step.module.scss';

/**
 * Interface for form section properties
 */
interface IFormSectionProps {
  children?: any;
  title: string;
  largeTitle?: boolean;
  subtitle?: string;
  note?: string;
}

/**
 * Component for from section
 */
export const FormSection: React.FunctionComponent<
  IFormSectionProps
> = props => {
  const { children, title, largeTitle, subtitle, note } = props;

  return (
    <div className={stepCss.section}>
      <div className={stepCss.sectionHead}>
        {title && <div className={largeTitle ? stepCss.sectionLargeTitle : stepCss.sectionTitle}>{title}</div>}
        {subtitle && <div className={stepCss.sectionSubtitle}>{subtitle}</div>}
        {note && <div className={stepCss.sectionNote}>{note}</div>}
      </div>
      {children}
    </div>
  );
};
