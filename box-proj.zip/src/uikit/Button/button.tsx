import * as React from "react";
import * as css from "./button.module.scss";

import { Highlightable } from "../Highlightable/Highlightable";
import { MediaQuery } from "../MediaQuery";
import cn from "classnames";
import { isTouchDevice } from "../../utils/misc";

/**
 * Interface for button properties
 * @callback onClick
 */
interface IButtonProps {
  style:
    | "plain"
    | "bordered"
    | "secondary"
    | "text-button"
    | "iconed"
    | "label-border"
    | "primary-border"
    | "creator-border"
    | "employer-border"
    | "hover-border"
    | "add-button"
    | "label-border-primary"
    | "creator-follow"
    | "label-link";
  className?: string;
  disabled?: boolean;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  form?: string;
  icon?: React.ReactNode;
  iconActive?: React.ReactNode;
  activeByDefault?: boolean;
}

/**
 * Component for button
 */
export const Button: React.FunctionComponent<IButtonProps> = ({
  className,
  style,
  children,
  disabled,
  onClick,
  icon,
  iconActive,
  activeByDefault,
  ...props
}) => {
  const [hover, setHover] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const hasIcon = !!(icon || iconActive);
  return (
    <button
      disabled={disabled}
      className={cn(
        css.button,
        css[style],
        {
          [css.hasIcon]: hasIcon,
          [css.disabled]: disabled,
          [css.pressed]: pressed || activeByDefault
        },
        className
      )}
      onMouseEnter={() => {
        if (!isTouchDevice()) {
          setHover(true);
        }
      }}
      onMouseLeave={() => {
        setHover(false);
        setPressed(false);
      }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onTouchStart={() => {
        setPressed(true);
      }}
      onTouchEnd={() => {
        setPressed(false);
      }}
      {...props}
      onClick={onClick}
    >
      {!hover && !pressed && icon}
      {(hover || pressed) && iconActive}
      {style === "plain" || style === "secondary" ? (
        hasIcon ? (
          <MediaQuery query="tabletAndDesktop">
            <Highlightable hover={hover} pressed={pressed}>
              {children}
            </Highlightable>
          </MediaQuery>
        ) : (
          <Highlightable hover={hover} pressed={pressed}>
            {children}
          </Highlightable>
        )
      ) : (
        children
      )}
    </button>
  );
};
