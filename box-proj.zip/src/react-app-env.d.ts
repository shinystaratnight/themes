declare module '*.module.scss' {
  const styles: any;
  export = styles;
}

declare module '*.module.css' {
  const styles: any;
  export = styles;
}

declare module '*.svg';
declare module '*.png';
declare module '*.jpg';
declare module '*.gif';

declare module '*.json' {
  const value: any;
  export default value;
}

declare module 'jss-preset-default';
declare module 'react-jss/*';
declare module 'string-template';
declare module 'thumbnail-youtube-vimeo';
declare module 'object-to-formdata';
declare module 'react-on-scroll';
declare module 'macy';
declare module 'react-id-swiper';
declare module 'storybook-react-router';
declare module 'final-form-focus';
declare module 'lottie-web';
// Outdated typings in @types
declare module 'react-infinite-scroller';
declare module 'body-scroll-lock';

declare module 'jquery';
declare module 'bootstrap';
declare module 'reactstrap';
declare module 'react-slideshow-image';
declare module 'react-notification-alert';
declare module 'input-moment';
declare module 'react-calendar';

/// <reference types="react-scripts" />
