import {
  BaseAction,
  generateAction,
  generateSimpleAction
} from "./_base.action";

import { UserProfile } from "../types/profile";

// Auth by Email

export interface IAuthByEmailPayload {
  email: string;
  password: string;
}

export type AuthByEmailAction = BaseAction<
  "AUTH_LOGIN_BY_EMAIL",
  IAuthByEmailPayload
>;

export const loginByEmail = generateAction<
  "AUTH_LOGIN_BY_EMAIL",
  IAuthByEmailPayload
>("AUTH_LOGIN_BY_EMAIL");

// Auth by Google
export interface ISocialProfile {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  name?: string;
  imageUrl?: string;
}
export interface IAuthByGooglePayload {
  accessToken: string;
  profile: ISocialProfile;
}
export type AuthByGoogleAction = BaseAction<
  "AUTH_LOGIN_BY_GOOGLE",
  IAuthByGooglePayload
>;
export const loginByGoogle = generateAction<
  "AUTH_LOGIN_BY_GOOGLE",
  IAuthByGooglePayload
>("AUTH_LOGIN_BY_GOOGLE");

// Set auth error
export interface IAuthErrorPayload {
  [fieldName: string]: string | null;
}

export type AuthErrorAction = BaseAction<"AUTH_ERROR", IAuthErrorPayload>;

export const setAuthError = generateAction<"AUTH_ERROR", IAuthErrorPayload>(
  "AUTH_ERROR"
);

// Reset auth

export interface IAuthResetPayload {}
export type AuthResetAction = BaseAction<"AUTH_RESET", IAuthResetPayload>;
export const resetAuth = generateAction<"AUTH_RESET", IAuthResetPayload>(
  "AUTH_RESET"
);

// Set auth token

export interface IAuthSetTokenPayload {
  authToken: string;
  profile: UserProfile;
  passwordInited: boolean;
}

export type AuthSetTokenAction = BaseAction<
  "AUTH_SET_TOKEN",
  IAuthSetTokenPayload
>;

export const setAuthToken = generateAction<
  "AUTH_SET_TOKEN",
  IAuthSetTokenPayload
>("AUTH_SET_TOKEN");

// Set auth loading
export interface IAuthSetLoadingPayload {
  loading: boolean;
}
export type AuthSetLoadingAction = BaseAction<
  "AUTH_SET_LOADING",
  IAuthSetLoadingPayload
>;
export const setAuthLoading = generateAction<
  "AUTH_SET_LOADING",
  IAuthSetLoadingPayload
>("AUTH_SET_LOADING");

// Set social profile
export interface IAuthSetSocialProfilePayload {
  accessToken: string;
  profile: ISocialProfile;
}
export type AuthSetSocialProfileAction = BaseAction<
  "AUTH_SET_SOCIAL_PROFILE",
  IAuthSetLoadingPayload
>;
export const setSocialProfile = generateAction<
  "AUTH_SET_SOCIAL_PROFILE",
  IAuthSetSocialProfilePayload | null
>("AUTH_SET_SOCIAL_PROFILE");

// Logout
export interface IAuthLogoutPayload {}
export type AuthLogoutAction = BaseAction<"AUTH_LOGOUT", IAuthLogoutPayload>;
export const logout = generateAction<"AUTH_LOGOUT", IAuthLogoutPayload>(
  "AUTH_LOGOUT"
);

// Register Creator by Email

export interface IRegisterByEmailPayload {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

export type RegisterByEmailAction = BaseAction<
  "AUTH_REGISTER_BY_EMAIL",
  IRegisterByEmailPayload
>;

export const registerByEmail = generateAction<
  "AUTH_REGISTER_BY_EMAIL",
  IRegisterByEmailPayload
>("AUTH_REGISTER_BY_EMAIL");

// Register Creator by Google

export interface IRegisterBySocialPayload {
  token: string;
  type: "google";
  firstName: string;
  lastName: string;
}

export type RegisterBySocialAction = BaseAction<
  "AUTH_REGISTER_BY_SOCIAL",
  IRegisterBySocialPayload
>;

export const registerBySocial = generateAction<
  "AUTH_REGISTER_BY_SOCIAL",
  IRegisterBySocialPayload
>("AUTH_REGISTER_BY_SOCIAL");

// ----- CancelCreatorAction
export type CancelAccountAction = BaseAction<"CANCEL_ACCOUNT">;
export const cancelAccount = generateSimpleAction<"CANCEL_ACCOUNT">(
  "CANCEL_ACCOUNT"
);

// Recover password

export interface IRecoverPasswordPayload {
  email: string;
}

export type RecoverPasswordAction = BaseAction<
  "AUTH_RECOVER_PASSWORD",
  IRecoverPasswordPayload
>;

export const recoverPassword = generateAction<
  "AUTH_RECOVER_PASSWORD",
  IRecoverPasswordPayload
>("AUTH_RECOVER_PASSWORD");

// Change password

export interface IChangePasswordPayload {
  password: string;
  code: string;
}

export type ChangePasswordAction = BaseAction<
  "AUTH_CHANGE_PASSWORD",
  IChangePasswordPayload
>;

export const changePassword = generateAction<
  "AUTH_CHANGE_PASSWORD",
  IChangePasswordPayload
>("AUTH_CHANGE_PASSWORD");

// Request verify email

export interface IRequestVerifyEmailPayload {}
export type RequestVerifyEmailAction = BaseAction<
  "AUTH_REQUEST_VERIFY_EMAIL",
  IRequestVerifyEmailPayload
>;
export const requestVerifyEmail = generateAction<
  "AUTH_REQUEST_VERIFY_EMAIL",
  IRequestVerifyEmailPayload
>("AUTH_REQUEST_VERIFY_EMAIL");

// Update auth profile

export interface IUpdateAuthProfilePayload {}
export type UpdateAuthProfileAction = BaseAction<
  "AUTH_UPDATE_PROFILE",
  IUpdateAuthProfilePayload
>;
export const updateAuthProfile = generateAction<
  "AUTH_UPDATE_PROFILE",
  IUpdateAuthProfilePayload
>("AUTH_UPDATE_PROFILE");

// Set "initialized" field
export interface IAuthSetInitializedPayload {
  initialized: boolean;
}
export type AuthSetInitializedAction = BaseAction<
  "AUTH_SET_INITIALIZED",
  IAuthSetInitializedPayload
>;
export const setInitialized = generateAction<
  "AUTH_SET_INITIALIZED",
  IAuthSetInitializedPayload
>("AUTH_SET_INITIALIZED");

// Summarize

export type AuthActionType =
  | "AUTH_CHANGE_PASSWORD"
  | "AUTH_ERROR"
  | "AUTH_LOGIN_BY_EMAIL"
  | "AUTH_LOGIN_BY_GOOGLE"
  | "AUTH_LOGOUT"
  | "AUTH_RECOVER_PASSWORD"
  | "AUTH_REGISTER_BY_EMAIL"
  | "AUTH_REGISTER_BY_SOCIAL"
  | "AUTH_REQUEST_VERIFY_EMAIL"
  | "AUTH_RESET"
  | "AUTH_SET_INITIALIZED"
  | "AUTH_SET_LOADING"
  | "AUTH_SET_SOCIAL_PROFILE"
  | "AUTH_SET_TOKEN"
  | "AUTH_UPDATE_PROFILE"
  | "CANCEL_ACCOUNT";

export type AuthAction =
  | AuthByEmailAction
  | AuthByGoogleAction
  | AuthErrorAction
  | AuthLogoutAction
  | AuthResetAction
  | AuthSetInitializedAction
  | AuthSetLoadingAction
  | AuthSetSocialProfileAction
  | AuthSetTokenAction
  | ChangePasswordAction
  | RecoverPasswordAction
  | RegisterByEmailAction
  | RegisterBySocialAction
  | RequestVerifyEmailAction
  | UpdateAuthProfileAction
  | CancelAccountAction;
