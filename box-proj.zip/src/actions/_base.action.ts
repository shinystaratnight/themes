export interface BaseAction<Type, Payload = any> {
  type: Type;
  payload: Payload;
  meta?: any;
}

/**
 * generate action for redux
 * @param type - action type
 */
export function generateAction<Type, Payload>(
  type: Type
): (payload: Payload) => BaseAction<Type, Payload> {
  return function(payload: Payload) {
    return {
      type,
      payload
    };
  };
}

/**
 * generate action without payload
 * @param type - action type
 */
export function generateSimpleAction<Type>(type: Type): () => BaseAction<Type> {
  return function() {
    return {
      type,
      payload: {}
    };
  };
}

// "Do nothing" action
// Can be useful for resolving sagas
export const nop = generateAction<'NOP_ACTION', any>('NOP_ACTION');
