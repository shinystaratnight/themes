import { BaseAction, generateAction } from './_base.action';

// Show email verification results

export interface ISetEmailVerificationResultsPayload {
  emailVerified: boolean;
}
export type SetEmailVerificationResultsAction = BaseAction<
  'UI_SET_EMAIL_VERIFICATION_RESULTS',
  ISetEmailVerificationResultsPayload
>;
export const setEmailVerificationResults = generateAction<
  'UI_SET_EMAIL_VERIFICATION_RESULTS',
  ISetEmailVerificationResultsPayload
>('UI_SET_EMAIL_VERIFICATION_RESULTS');

// Show email verification results

export interface IResetEmailVerificationResultsPayload {}
export type ResetEmailVerificationResultsAction = BaseAction<
  'UI_RESET_EMAIL_VERIFICATION_RESULTS',
  IResetEmailVerificationResultsPayload
>;
export const resetEmailVerificationResults = generateAction<
  'UI_RESET_EMAIL_VERIFICATION_RESULTS',
  IResetEmailVerificationResultsPayload
>('UI_RESET_EMAIL_VERIFICATION_RESULTS');

export interface IGlobalSearchRequestAddPayload {
  by: string;
  request: string;
}
export type GlobalSearchRequestAddAction = BaseAction<
  'UI_ADD_GLOBAL_SEARCH_REQUEST_ADD',
  IGlobalSearchRequestAddPayload
>;
export const globalSearchRequestAdd = generateAction<
  'UI_ADD_GLOBAL_SEARCH_REQUEST_ADD',
  IGlobalSearchRequestAddPayload
>('UI_ADD_GLOBAL_SEARCH_REQUEST_ADD');

// ----- SetCurrentSearchRequestAction
export type SetCurrentSearchRequestAction = BaseAction<
  'UI_SET_CURRENT_SEARCH_REQUEST',
  IGlobalSearchRequestAddPayload
>;
export const setCurrentSearchRequest = generateAction<
  'UI_SET_CURRENT_SEARCH_REQUEST',
  IGlobalSearchRequestAddPayload
>('UI_SET_CURRENT_SEARCH_REQUEST');

// ----- SetSearchBarState
export type SetSearchBarStateAction = BaseAction<
  'UI_SET_SEARCH_BAR_STATE',
  IGlobalSearchRequestAddPayload
>;
export const setSearchBarState = generateAction<
  'UI_SET_SEARCH_BAR_STATE',
  IGlobalSearchRequestAddPayload
>('UI_SET_SEARCH_BAR_STATE');

// -----
export type UiAction =
  | SetEmailVerificationResultsAction
  | ResetEmailVerificationResultsAction
  | GlobalSearchRequestAddAction
  | SetCurrentSearchRequestAction
  | SetSearchBarStateAction;
