import { BaseAction, generateAction } from './_base.action';
import {Box, Card, CartItem, DonationCard, Product, UserProfile} from "../types";

// Set step action
export interface ISetStepPayload {
  step: string;
}
export type SetStepAction = BaseAction<
  'LOCAL_SET_STEP',
  ISetStepPayload
>;
export const setStep = generateAction<
  'LOCAL_SET_STEP',
  ISetStepPayload
>('LOCAL_SET_STEP');

// Set box size action
export interface ISetBoxSizePayload {
  size: string;
}
export type SetBoxSizeAction = BaseAction<
  'LOCAL_SET_BOXSIZE',
  ISetBoxSizePayload
>;
export const setBoxSize = generateAction<
  'LOCAL_SET_BOXSIZE',
  ISetBoxSizePayload
>('LOCAL_SET_BOXSIZE');

// Choose box action
export interface IChooseBoxPayload {
  box: Box
}
export type ChooseBoxAction = BaseAction<
  'LOCAL_CHOOSE_BOX',
  IChooseBoxPayload
>;
export const chooseBox = generateAction<
  'LOCAL_CHOOSE_BOX',
  IChooseBoxPayload
>('LOCAL_CHOOSE_BOX');

// Choose card action
export interface IChooseCardPayload {
  card: Card
}
export type ChooseCardAction = BaseAction<
    'LOCAL_CHOOSE_CARD',
    IChooseCardPayload
    >;
export const chooseCard = generateAction<
    'LOCAL_CHOOSE_CARD',
    IChooseCardPayload
    >('LOCAL_CHOOSE_CARD');

// Set cart items action
export interface ISetCartItemsPayload {
  cartItems: CartItem[];
}
export type SetCartItemsAction = BaseAction<
  'LOCAL_SET_CART_ITEMS',
  ISetCartItemsPayload
>;
export const setCartItems = generateAction<
  'LOCAL_SET_CART_ITEMS',
  ISetCartItemsPayload
>('LOCAL_SET_CART_ITEMS');

// Add product to box action
export interface IAddProductToBoxPayload {
  product: Product;
}
export type AddProductToBoxAction = BaseAction<
  'LOCAL_ADD_PRODUCT_TO_BOX',
  IAddProductToBoxPayload
>;
export const addProductToBox = generateAction<
  'LOCAL_ADD_PRODUCT_TO_BOX',
  IAddProductToBoxPayload
>('LOCAL_ADD_PRODUCT_TO_BOX');

// Remove product from box action
export interface IRemoveProductFromBoxPayload {
  product: Product;
}
export type RemoveProductFromBoxAction = BaseAction<
  'LOCAL_REMOVE_PRODUCT_FROM_BOX',
  IRemoveProductFromBoxPayload
>;
export const removeProductFromBox = generateAction<
  'LOCAL_REMOVE_PRODUCT_FROM_BOX',
  IRemoveProductFromBoxPayload
>('LOCAL_REMOVE_PRODUCT_FROM_BOX');

// Add donation item action
export interface IAddDonationItemPayload {
  item: DonationCard;
}
export type AddDonationItemAction = BaseAction<
    'LOCAL_ADD_DONATION_ITEM',
    IAddDonationItemPayload
    >;
export const addDonationItem = generateAction<
    'LOCAL_ADD_DONATION_ITEM',
    IAddDonationItemPayload
    >('LOCAL_ADD_DONATION_ITEM');

// Remove donation item action
export interface IRemoveDonationItemPayload {
  item: DonationCard;
}
export type RemoveDonationItemAction = BaseAction<
    'LOCAL_REMOVE_DONATION_ITEM',
    IRemoveDonationItemPayload
    >;
export const removeDonationItem = generateAction<
    'LOCAL_REMOVE_DONATION_ITEM',
    IRemoveDonationItemPayload
    >('LOCAL_REMOVE_DONATION_ITEM');

// Set donation items action
export interface ISetDonationItemsPayload {
  items: DonationCard[];
}
export type SetDonationItemsAction = BaseAction<
    'LOCAL_SET_DONATION_ITEMS',
    ISetDonationItemsPayload
    >;
export const setDonationItems = generateAction<
    'LOCAL_SET_DONATION_ITEMS',
    ISetDonationItemsPayload
    >('LOCAL_SET_DONATION_ITEMS');

// Set user information action
export interface ISetProfilePayload {
  profile: UserProfile;
}
export type SetProfileAction = BaseAction<
  'LOCAL_SET_PROFILE',
  ISetProfilePayload
  >;
export const setProfile = generateAction<
  'LOCAL_SET_PROFILE',
  ISetProfilePayload
  >('LOCAL_SET_PROFILE');

// Set shipping date action
export interface ISetShippingDatePayload {
  date: string;
}
export type SetShippingDateAction = BaseAction<
  'LOCAL_SET_SHIPPING_DATE',
  ISetShippingDatePayload
  >;
export const setShippingDate = generateAction<
  'LOCAL_SET_SHIPPING_DATE',
  ISetShippingDatePayload
  >('LOCAL_SET_SHIPPING_DATE');

// Clear data action
export interface IClearDataPayload {}
export type ClearDataAction = BaseAction<
    'LOCAL_CLEAR_DATA',
    IClearDataPayload
    >;
export const clearData = generateAction<
    'LOCAL_CLEAR_DATA',
    IClearDataPayload
    >('LOCAL_CLEAR_DATA');

// -----
export type LocalActionType =
  | "LOCAL_SET_STEP"
  | "LOCAL_CHOOSE_BOX"
  | "LOCAL_CHOOSE_CARD"
  | "LOCAL_SET_BOXSIZE"
  | "LOCAL_SET_CART_ITEMS"
  | "LOCAL_ADD_PRODUCT_TO_BOX"
  | "LOCAL_REMOVE_PRODUCT_FROM_BOX"
  | "LOCAL_ADD_DONATION_ITEM"
  | "LOCAL_REMOVE_DONATION_ITEM"
  | "LOCAL_SET_DONATION_ITEMS"
  | "LOCAL_SET_PROFILE"
  | "LOCAL_SET_SHIPPING_DATE"
  | "LOCAL_CLEAR_DATA";

export type LocalAction =
  | SetStepAction
  | ChooseBoxAction
  | ChooseCardAction
  | SetBoxSizeAction
  | SetCartItemsAction
  | AddProductToBoxAction
  | RemoveProductFromBoxAction
  | AddDonationItemAction
  | RemoveDonationItemAction
  | SetDonationItemsAction
  | SetProfileAction
  | SetShippingDateAction
  | ClearDataAction;
