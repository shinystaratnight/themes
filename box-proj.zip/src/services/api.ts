import axios, { AxiosInstance } from 'axios';

import { AnyAction } from 'redux';
import { Dispatch } from 'react';
import { resetAuth } from '../actions';

let authToken: string | null = null;
let instance: AxiosInstance = generateAxiosInstance();
let dispatchHook: Dispatch<AnyAction> | null = null;

/**
 * Function to create Axios instance
 */
function generateAxiosInstance(): AxiosInstance {
  return axios.create({
    baseURL: process.env.REACT_APP_API_URL,
    headers: {
      Authorization: `Bearer ${authToken}`,
      'Content-type': 'application/json'
    }
  });
}

/**
 * Function to set auth token
 * @param token Auth token
 */
export function setBearerToken(token: string | null) {
  authToken = token;
  instance = generateAxiosInstance();
}

/**
 * Function to dispatch hooks
 */
export function setDispatchHook(dispatch: Dispatch<AnyAction>) {
  dispatchHook = dispatch;
}

/**
 * Function to handle errors with auth
 * @param e Auth Error
 */
function authErrorHandler(e: any) {
  if (e.response && e.response.data && e.response.data.statusCode == 401) {
    if (dispatchHook) {
      dispatchHook(resetAuth({}));
    }
    return Promise.reject(e);
  } else {
    return Promise.reject(e);
  }
}

/**
 * Function to implement GET method with auth information
 */
export function get<T = any>(url: string) {
  return instance.get<T>(url).catch(authErrorHandler);
}

/**
 * Function to implement POST method with auth information
 */
export function post(url: string, data: any) {
  return instance.post(url, data).catch(authErrorHandler);
}

/**
 * Function to implement PATCH method with auth information
 */
export function patch<T = any>(url: string, data: any) {
  return instance.patch<T>(url, data).catch(authErrorHandler);
}

/**
 * Function to implement PUT method with auth information
 */
export function put(url: string, data: any) {
  return instance.put(url, data).catch(authErrorHandler);
}

/**
 * Function to implement DELETE method with auth information
 */
export function del(url: string, data?: any) {
  return instance.delete(url, { data }).catch(authErrorHandler);
}

/**
 * Function to implement GET method without auth information
 */
export function rawGet(url: string) {
  return instance.get(url);
}

/**
 * Function to implement POST method without auth information
 */
export function rawPost(url: string, data: any) {
  return instance.post(url, data);
}

/**
 * Function to implement PUT method without auth information
 */
export function rawPut(url: string, data: any) {
  return instance.put(url, data);
}

/**
 * Function to implement DELETE method without auth information
 */
export function rawDel(url: string) {
  return instance.delete(url);
}

/**
 * Summary of HTTP Methods for RESTful APIs
 */
export const api = {
  get,
  post,
  patch,
  put,
  delete: del,
  rawGet,
  rawPost,
  rawPut,
  rawDelete: rawDel
};
