import immutable from "object-path-immutable";

import { CollectionData, ProdData } from '../dummy/data';

/**
 * Function to filter products from dummy data
 * @param collectionId 
 * @param color 
 * @param sortKey 
 * @param offset 
 * @param limit 
 */
export function filterProducts(collectionId: string, color: string, sortKey: string, offset: number, limit: number) {
  const productsInCollection = ProdData.filter(
    product => product.collection_id === collectionId && (!color || product.color === color));
  if (sortKey === 'Price (Low to High)') {
    productsInCollection.sort(function(product1, product2) { return product1.price - product2.price; });
  } else if (sortKey === 'Price (High to Low)') {
    productsInCollection.sort(function(product1, product2) { return product2.price - product1.price; });
  } else if (sortKey === 'Name (Asscending)') {
    productsInCollection.sort(function(product1, product2) { return product1.title.localeCompare(product2.title); });
  } else if (sortKey === 'Name (Descending)') {
    productsInCollection.sort(function(product1, product2) { return product2.title.localeCompare(product1.title); });
  }
  
  return productsInCollection.slice(offset, offset + limit);
}

/**
 * Summary of Methods for Local Api
 */
export const localapi = {
  filterProducts
};
