import { UiAction, IGlobalSearchRequestAddPayload } from '../actions';
import immutable from 'object-path-immutable';

export interface UiState {
  showEmailVerificationPopup: boolean;
  emailVerified: boolean;
  globalSearchRequests: IGlobalSearchRequestAddPayload[];
  currentSearchRequests: IGlobalSearchRequestAddPayload | null;
  searchBarState: IGlobalSearchRequestAddPayload;
}

const initialState: UiState = {
  showEmailVerificationPopup: false,
  emailVerified: false,
  globalSearchRequests: [],
  currentSearchRequests: null,
  searchBarState: { by: 'title', request: '' }
};

export function uiReducer(state: UiState = initialState, action: UiAction) {
  switch (action.type) {
    case 'UI_SET_SEARCH_BAR_STATE':
      return immutable(state)
        .set('searchBarState', action.payload)
        .value();

    default:
      return state;
  }
}
