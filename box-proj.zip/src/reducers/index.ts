import { AuthState, authReducer } from './auth.reducer';
import { RouterState, connectRouter } from 'connected-react-router';
import { UiState, uiReducer } from './ui.reducer';

import { History } from 'history';
import { combineReducers } from 'redux';
import { reducer as thunkReducer } from 'redux-saga-thunk';
import { LocalState, localReducer } from './local.reducer';

const rootReducer = (history: History) =>
  combineReducers({
    thunk: thunkReducer,
    router: connectRouter(history),
    auth: authReducer,
    ui: uiReducer,
    local: localReducer
  });

export interface IState {
  router: RouterState;
  auth: AuthState;
  ui: UiState;
  local: LocalState;
}

export default rootReducer;
export * from './auth.reducer';
export * from './ui.reducer';
export * from './local.reducer';
