import { AuthAction, IAuthSetSocialProfilePayload } from "../actions";

import { UserProfile } from "../types/profile";
import immutable from "object-path-immutable";
import { saveState } from "../utils/stateLocalStorage";

/**
 * initialized - true if we have reduced profile in the store
 * authenticated - true if user is authorized
 * googleAccount - accessToken from for google auth
 */
export interface AuthState {
  initialized: boolean;
  authenticated: boolean;
  authToken: string | null;
  googleAccount: IAuthSetSocialProfilePayload | null;
  error: string | null;
  profile: UserProfile | null;
  loading: boolean;
  passwordInited: boolean | true;
}

const initialState: AuthState = {
  initialized: false,
  authenticated: false,
  authToken: null,
  error: null,
  profile: null,
  loading: false,
  googleAccount: null,
  passwordInited: true
};

/**
 * authorization reducer
 */
export function authReducer(
  state: AuthState = initialState,
  action: AuthAction
) {
  switch (action.type) {
    case "AUTH_RESET":
      const resetState = immutable(state)
        .set("authenticated", false)
        .set("authToken", null)
        .set("error", null)
        .set("profile", null)
        .set("loading", false)
        .set("passwordInited", true)
        .set("googleAccount", null)
        .value();
      saveState({ auth: resetState });
      return resetState;

    case "AUTH_SET_LOADING":
      return immutable(state)
        .set("loading", action.payload.loading)
        .value();

    case "AUTH_SET_INITIALIZED":
      return immutable(state)
        .set("initialized", action.payload.initialized)
        .value();

    case "AUTH_SET_TOKEN":
      if (!action.payload.authToken || !action.payload.profile) {
        throw new Error("Invalid authentication state");
      }
      const newState = immutable(state)
        .set("authenticated", true)
        .set("authToken", action.payload.authToken)
        .set("profile", action.payload.profile)
        .set("error", null)
        .set("passwordInited", action.payload.passwordInited)
        .value();
      saveState({ auth: newState });
      return newState;

    case "AUTH_SET_SOCIAL_PROFILE":
      return immutable(state)
        .set("googleAccount", action.payload)
        .value();

    case "AUTH_ERROR":
      return immutable(state)
        .set("error", action.payload)
        .value();

    default:
      return state;
  }
}
