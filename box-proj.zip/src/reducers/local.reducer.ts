import { LocalAction } from '../actions';
import immutable from 'object-path-immutable';
import {Box, Card, CartItem, DonationCard, UserProfile} from '../types';
import { BoxData } from '../dummy/data';
import {
  loadBoxState,
  loadBoxSizeState,
  loadCartItemsState,
  loadStepState,
  clearDataFromStorage, loadCardState, loadDonationItemsState, loadProfileState, loadShippingDateState
} from '../utils/stateLocalStorage';

export interface LocalState {
  step: string;
  box: Box;
  cart: CartItem[];
  boxSize: string;
  card: Card;
  donations: DonationCard[];
  profile: UserProfile;
  shippingDate: string;
}

const initialState: LocalState = {
  step: loadStepState(),
  box: loadBoxState(),
  cart: loadCartItemsState(),
  boxSize: loadBoxSizeState(),
  card: loadCardState(),
  donations: loadDonationItemsState(),
  profile: loadProfileState(),
  shippingDate: loadShippingDateState(),
};

export function localReducer(state: LocalState = initialState, action: LocalAction) {

  switch (action.type) {
    case 'LOCAL_SET_STEP':
      return immutable(state)
        .set('step', action.payload.step)
        .value();

    case 'LOCAL_SET_BOXSIZE':
      return immutable(state)
        .set('boxSize', action.payload.size)
        .value();

    case 'LOCAL_CHOOSE_BOX':
      return immutable(state)
        .set('box', action.payload.box)
        .value();

    case 'LOCAL_SET_CART_ITEMS':
      return immutable(state)
        .set('cart', action.payload.cartItems)
        .value();

    case 'LOCAL_CHOOSE_CARD':
      return immutable(state)
          .set('card', action.payload.card)
          .value();

    case 'LOCAL_SET_DONATION_ITEMS':
      return immutable(state)
          .set('donations', action.payload.items)
          .value();

    case 'LOCAL_SET_PROFILE':
      return immutable(state)
        .set('profile', action.payload.profile)
        .value();

    case 'LOCAL_SET_SHIPPING_DATE':
      return immutable(state)
        .set('shippingDate', action.payload.date)
        .value();

    case 'LOCAL_CLEAR_DATA':
      clearDataFromStorage();
      return immutable(state)
          .set('cart', [])
          .set('profile', {})
          .set('box', BoxData[0])
          .set('boxSize', 'MINI')
          .set('donations', [])
          .set('shippingDate', '')
          .value();

    default:
      return state;
  }
}
