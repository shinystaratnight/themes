import 'bulma/css/bulma.css';
import './styles/index.scss';

import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as Sentry from '@sentry/browser';

import { applyMiddleware, compose, createStore } from 'redux';
import { Provider } from 'react-redux';
import createSagaMiddleware from 'redux-saga';
import { middleware as thunkMiddleware } from 'redux-saga-thunk';
import { routerMiddleware } from 'connected-react-router';
import ReactGA from 'react-ga';
import { createBrowserHistory } from 'history';

import { setBearerToken, setDispatchHook } from './services/api';

import App from './App';
import { loadState } from './utils/stateLocalStorage';
import rootReducer from './reducers';
import rootSaga from './sagas';

// create the saga middleware
const sagaMiddleware = createSagaMiddleware();

const history = createBrowserHistory({
  basename: process.env.REACT_APP_PUBLIC_URL
});

const composeEnhancer: typeof compose =
  (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const persistedState = loadState();
if (persistedState && persistedState.auth && persistedState.auth.authToken) {
  Object.assign(persistedState.auth, { initialized: false, loading: false });
  setBearerToken(persistedState.auth.authToken);
}

const store = createStore(
  rootReducer(history),
  persistedState,
  composeEnhancer(
    applyMiddleware(routerMiddleware(history), thunkMiddleware, sagaMiddleware)
  )
);

setDispatchHook(store.dispatch);

// then run the saga
sagaMiddleware.run(rootSaga);

const render = () => {
  ReactDOM.render(
    <Provider store={store}>
      <App history={history} />
    </Provider>,
    document.getElementById('root') as HTMLElement
  );
};

process.env.REACT_APP_SENTRY_DSN &&
  Sentry.init({
    dsn: process.env.REACT_APP_SENTRY_DSN,
    environment: process.env.REACT_APP_ENV_NAME,
    attachStacktrace: true
  });

process.env.REACT_APP_GOOGLE_ANALYTICS &&
  ReactGA.initialize(process.env.REACT_APP_GOOGLE_ANALYTICS);

render();

if (module.hot) {
  module.hot.accept('./App', () => {
    render();
  });
}
