import React from "react";
import { Link } from "react-router-dom";
// import { Row, Col, Card } from 'react-bootstrap';
import Header3 from "../layout/header3";

function Demo() {
    return (
        <>
            <Header3 />

            <div class="demo section-padding page-section" id="demo">
                <div class="container">
                    <div class="row py-lg-5 justify-content-center">
                        <div class="col-xl-7">
                            <div class="section-heading text-center">
                                <h2>Dashboard</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="demo_img">
                                <div class="row">
                                    <div class="col-xl-6 col-6">
                                        <a
                                            href="https://demo.themefisher.com/tradio_react/"
                                            target="_blank"
                                        >
                                            <div class="img-wrap">
                                                <img
                                                    src={require("../../images/demo/dashboard/dark/landing.jpg")}
                                                    alt=""
                                                    class="img-fluid"
                                                />
                                            </div>
                                            <h4>Dark</h4>
                                        </a>
                                    </div>
                                    <div class="col-xl-6 col-6">
                                        <Link to={"./"} target="_blank">
                                            <div class="img-wrap light">
                                                <img
                                                    src={require("../../images/demo/dashboard/light/landing.jpg")}
                                                    alt=""
                                                    class="img-fluid"
                                                />
                                            </div>
                                            <h4>Light</h4>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Demo;
