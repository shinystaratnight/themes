module.exports = {
  publicPath:
    process.env.NODE_ENV === "production" ? "/metronic8/vue/demo2/" : "/",
};
